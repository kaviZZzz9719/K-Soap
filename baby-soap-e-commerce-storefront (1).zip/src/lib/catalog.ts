import { and, asc, desc, eq, gte, ilike, inArray, lte, or, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { collections, productImages, products, reviews } from "@/db/schema";

export type CatalogProduct = {
  id: number;
  slug: string;
  name: string;
  subtitle: string;
  collectionId: number;
  collectionSlug: string;
  collectionName: string;
  priceCents: number;
  compareAtCents: number | null;
  scent: string;
  ageRange: string;
  concerns: string[];
  badge: string | null;
  summary: string;
  description: string;
  ingredients: string;
  ritual: string;
  weightGrams: number;
  stock: number;
  rating: string;
  reviewCount: number;
  featured: boolean;
  position: number;
  variants: import("@/db/schema").ProductVariant[];
  images: { url: string; alt: string }[];
};

export type ProductFilters = {
  q?: string;
  collection?: string[];
  concerns?: string[];
  scent?: string[];
  minPriceCents?: number;
  maxPriceCents?: number;
  sort?: "featured" | "price-asc" | "price-desc" | "rating" | "newest";
  limit?: number;
  offset?: number;
};

function mapProduct(row: Record<string, unknown>, images: { url: string; alt: string }[]): CatalogProduct {
  return { ...(row as unknown as Omit<CatalogProduct, "images">), images };
}

async function loadImages(productIds: number[]) {
  if (productIds.length === 0) return new Map<number, { url: string; alt: string }[]>();
  const rows = await db
    .select({
      productId: productImages.productId,
      url: productImages.url,
      alt: productImages.alt,
      position: productImages.position,
    })
    .from(productImages)
    .where(inArray(productImages.productId, productIds))
    .orderBy(asc(productImages.position));

  const grouped = new Map<number, { url: string; alt: string }[]>();
  for (const row of rows) {
    const list = grouped.get(row.productId) ?? [];
    list.push({ url: row.url, alt: row.alt });
    grouped.set(row.productId, list);
  }
  return grouped;
}

export async function getCollections() {
  return db.select().from(collections).orderBy(asc(collections.position));
}

export async function getCollectionBySlug(slug: string) {
  const rows = await db.select().from(collections).where(eq(collections.slug, slug)).limit(1);
  return rows[0] ?? null;
}

export async function searchProducts(filters: ProductFilters = {}) {
  const conditions = [];

  if (filters.q?.trim()) {
    const term = `%${filters.q.trim()}%`;
    conditions.push(
      or(
        ilike(products.name, term),
        ilike(products.subtitle, term),
        ilike(products.summary, term),
        ilike(products.scent, term),
      ),
    );
  }
  if (filters.collection?.length) {
    conditions.push(
      sql`${products.collectionId} IN (SELECT ${collections.id} FROM ${collections} WHERE ${inArray(
        collections.slug,
        filters.collection,
      )})`,
    );
  }
  if (filters.concerns?.length) {
    // Bind each concern individually: `ARRAY[$1, $2]::text[]` is unambiguous for Postgres.
    const concernArray = sql.join(
      filters.concerns.map((concern) => sql`${concern}`),
      sql`, `,
    );
    conditions.push(sql`${products.concerns} && ARRAY[${concernArray}]::text[]`);
  }
  if (filters.scent?.length) {
    conditions.push(inArray(products.scent, filters.scent));
  }
  if (typeof filters.minPriceCents === "number") {
    conditions.push(gte(products.priceCents, filters.minPriceCents));
  }
  if (typeof filters.maxPriceCents === "number") {
    conditions.push(lte(products.priceCents, filters.maxPriceCents));
  }

  const where = conditions.length ? and(...conditions) : undefined;

  const orderings: Record<string, SQL[]> = {
    featured: [desc(products.featured), asc(products.position)],
    "price-asc": [asc(products.priceCents)],
    "price-desc": [desc(products.priceCents)],
    rating: [desc(sql`${products.rating}::numeric`), desc(products.reviewCount)],
    newest: [desc(products.createdAt)],
  };
  const orderBy = orderings[filters.sort ?? "featured"] ?? orderings.featured;

  const base = db
    .select({
      product: products,
      collectionSlug: collections.slug,
      collectionName: collections.name,
    })
    .from(products)
    .innerJoin(collections, eq(products.collectionId, collections.id))
    .where(where)
    .orderBy(...orderBy);

  const rows =
    typeof filters.limit === "number"
      ? await base.limit(filters.limit).offset(filters.offset ?? 0)
      : await base;

  const totalRows = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(products)
    .innerJoin(collections, eq(products.collectionId, collections.id))
    .where(where);

  const imagesByProduct = await loadImages(rows.map((row) => row.product.id));

  const mapped = rows.map((row) =>
    mapProduct(
      {
        ...row.product,
        collectionSlug: row.collectionSlug,
        collectionName: row.collectionName,
      } as unknown as Record<string, unknown>,
      imagesByProduct.get(row.product.id) ?? [],
    ),
  );

  return { products: mapped, total: totalRows[0]?.count ?? 0 };
}

export async function getProductBySlug(slug: string) {
  const rows = await db
    .select({
      product: products,
      collectionSlug: collections.slug,
      collectionName: collections.name,
      collectionAccent: collections.accent,
    })
    .from(products)
    .innerJoin(collections, eq(products.collectionId, collections.id))
    .where(eq(products.slug, slug))
    .limit(1);

  const row = rows[0];
  if (!row) return null;

  const imagesByProduct = await loadImages([row.product.id]);

  return {
    product: mapProduct(
      {
        ...row.product,
        collectionSlug: row.collectionSlug,
        collectionName: row.collectionName,
      } as unknown as Record<string, unknown>,
      imagesByProduct.get(row.product.id) ?? [],
    ),
    collectionAccent: row.collectionAccent,
  };
}

export async function getProductReviews(slug: string) {
  const rows = await db
    .select({
      id: reviews.id,
      authorName: reviews.authorName,
      authorLocation: reviews.authorLocation,
      rating: reviews.rating,
      title: reviews.title,
      body: reviews.body,
      verified: reviews.verified,
      helpfulCount: reviews.helpfulCount,
      createdAt: reviews.createdAt,
    })
    .from(reviews)
    .innerJoin(products, eq(reviews.productId, products.id))
    .where(eq(products.slug, slug))
    .orderBy(desc(reviews.helpfulCount), desc(reviews.createdAt));

  return rows;
}

export async function getAllSlugs() {
  return db.select({ slug: products.slug }).from(products).orderBy(asc(products.position));
}

export async function getFacets() {
  const [collectionRows, concernRows, scentRows, priceRows] = await Promise.all([
    db
      .select({ slug: collections.slug, name: collections.name })
      .from(collections)
      .orderBy(asc(collections.position)),
    db.select({ concerns: products.concerns }).from(products),
    db.select({ scent: products.scent }).from(products).orderBy(asc(products.scent)),
    db.select({ min: sql<number>`min(${products.priceCents})::int`, max: sql<number>`max(${products.priceCents})::int` }).from(products),
  ]);

  const concernCounts = new Map<string, number>();
  for (const row of concernRows) {
    for (const concern of row.concerns ?? []) {
      concernCounts.set(concern, (concernCounts.get(concern) ?? 0) + 1);
    }
  }

  return {
    collections: collectionRows,
    concerns: [...concernCounts.entries()]
      .map(([value, count]) => ({ value, count }))
      .sort((a, b) => a.value.localeCompare(b.value)),
    scents: [...new Set(scentRows.map((row) => row.scent))].sort(),
    price: { min: priceRows[0]?.min ?? 0, max: priceRows[0]?.max ?? 5000 },
  };
}

export async function getStoreStats() {
  const [productRow, reviewRow] = await Promise.all([
    db
      .select({
        count: sql<number>`count(*)::int`,
        average: sql<string>`coalesce(round(avg(${products.rating}::numeric), 2), '0')`,
      })
      .from(products),
    db
      .select({
        count: sql<number>`count(*)::int`,
        average: sql<string>`coalesce(round(avg(${reviews.rating}::numeric), 2), '0')`,
      })
      .from(reviews),
  ]);

  return {
    productCount: productRow[0]?.count ?? 0,
    averageRating: productRow[0]?.average ?? "0",
    reviewCount: reviewRow[0]?.count ?? 0,
    averageReviewRating: reviewRow[0]?.average ?? "0",
  };
}
