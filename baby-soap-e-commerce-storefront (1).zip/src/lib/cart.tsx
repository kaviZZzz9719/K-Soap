"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { CartLine } from "@/lib/cart-types";

const STORAGE_KEY = "kavi.cart.v2";

type CartContextValue = {
  lines: CartLine[];
  hydrated: boolean;
  isOpen: boolean;
  count: number;
  subtotalCents: number;
  savingsCents: number;
  toast: { id: number; message: string; image?: string } | null;
  openCart: () => void;
  closeCart: () => void;
  addLine: (line: Omit<CartLine, "key">, opts?: { open?: boolean; announce?: string }) => void;
  updateQuantity: (key: string, quantity: number) => void;
  removeLine: (key: string) => void;
  clearCart: () => void;
  dismissToast: () => void;
};

const CartContext = createContext<CartContextValue | null>(null);

export function makeLineKey(productId: number, variantId: string) {
  return `${productId}:${variantId}`;
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [toast, setToast] = useState<CartContextValue["toast"]>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as CartLine[];
        if (Array.isArray(parsed)) {
          // eslint-disable-next-line react-hooks/set-state-in-effect -- one-time rehydration of the persisted bag
          setLines(parsed.filter((line) => line && typeof line.slug === "string" && line.quantity > 0));
        }
      }
    } catch {
      // Corrupt storage should never break the storefront.
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(lines));
    } catch {
      // Storage may be unavailable (private mode); cart still works in memory.
    }
  }, [lines, hydrated]);

  useEffect(() => {
    if (!isOpen) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setIsOpen(false);
    };
    document.addEventListener("keydown", onKey);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = previous;
    };
  }, [isOpen]);

  const showToast = useCallback((message: string, image?: string) => {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast({ id: Date.now(), message, image });
    toastTimer.current = setTimeout(() => setToast(null), 3600);
  }, []);

  const addLine = useCallback<CartContextValue["addLine"]>(
    (line, opts) => {
      const key = makeLineKey(line.productId, line.variantId);
      setLines((current) => {
        const existing = current.find((item) => item.key === key);
        if (existing) {
          return current.map((item) =>
            item.key === key
              ? {
                  ...item,
                  quantity: Math.min(item.maxQuantity, item.quantity + line.quantity),
                  unitPriceCents: line.unitPriceCents,
                }
              : item,
          );
        }
        return [...current, { ...line, key }];
      });
      if (opts?.open !== false) setIsOpen(true);
      if (opts?.announce !== "") showToast(opts?.announce ?? `${line.name} added to your bag`);
    },
    [showToast],
  );

  const updateQuantity = useCallback((key: string, quantity: number) => {
    setLines((current) =>
      quantity <= 0
        ? current.filter((line) => line.key !== key)
        : current.map((line) =>
            line.key === key ? { ...line, quantity: Math.min(line.maxQuantity, quantity) } : line,
          ),
    );
  }, []);

  const removeLine = useCallback((key: string) => {
    setLines((current) => current.filter((line) => line.key !== key));
  }, []);

  const clearCart = useCallback(() => setLines([]), []);

  const { count, subtotalCents, savingsCents } = useMemo(() => {
    return lines.reduce(
      (acc, line) => {
        acc.count += line.quantity;
        acc.subtotalCents += line.unitPriceCents * line.quantity;
        if (line.compareAtCents && line.compareAtCents > line.unitPriceCents) {
          acc.savingsCents += (line.compareAtCents - line.unitPriceCents) * line.quantity;
        }
        return acc;
      },
      { count: 0, subtotalCents: 0, savingsCents: 0 },
    );
  }, [lines]);

  const value = useMemo<CartContextValue>(
    () => ({
      lines,
      hydrated,
      isOpen,
      count,
      subtotalCents,
      savingsCents,
      toast,
      openCart: () => setIsOpen(true),
      closeCart: () => setIsOpen(false),
      addLine,
      updateQuantity,
      removeLine,
      clearCart,
      dismissToast: () => setToast(null),
    }),
    [lines, hydrated, isOpen, count, subtotalCents, savingsCents, toast, addLine, updateQuantity, removeLine, clearCart],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error("useCart must be used inside <CartProvider>");
  return context;
}
