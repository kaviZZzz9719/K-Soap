export type CartLine = {
  key: string;
  productId: number;
  slug: string;
  name: string;
  subtitle: string;
  variantId: string;
  variantLabel: string;
  variantDetail: string;
  unitPriceCents: number;
  compareAtCents: number | null;
  quantity: number;
  image: string;
  maxQuantity: number;
};

export type ShippingMethod = "standard" | "express" | "overnight";

export const SHIPPING_METHODS: {
  id: ShippingMethod;
  label: string;
  detail: string;
  priceCents: number;
}[] = [
  { id: "standard", label: "Standard", detail: "3–5 business days · plastic-free", priceCents: 0 },
  { id: "express", label: "Express", detail: "2 business days", priceCents: 895 },
  { id: "overnight", label: "Overnight", detail: "Next business day by 8pm", priceCents: 1895 },
];

export const TAX_RATE = 0.0825;
export const FREE_SHIPPING_THRESHOLD_CENTS = 4500;

export const PROMOS: Record<string, { kind: "percent" | "shipping"; value: number; label: string }> = {
  WELCOME10: { kind: "percent", value: 10, label: "10% off your first order" },
  BABY15: { kind: "percent", value: 15, label: "15% off the nursery shelf" },
  FREESHIP: { kind: "shipping", value: 0, label: "Free express shipping" },
};

export function formatCents(cents: number, currency = "USD") {
  return new Intl.NumberFormat("en-US", { style: "currency", currency, maximumFractionDigits: 2 }).format(
    cents / 100,
  );
}

export function relativeDate(date: Date | string) {
  const then = typeof date === "string" ? new Date(date) : date;
  const diffDays = Math.round((Date.now() - then.getTime()) / 86_400_000);
  if (diffDays <= 0) return "Today";
  if (diffDays === 1) return "Yesterday";
  if (diffDays < 7) return `${diffDays} days ago`;
  if (diffDays < 31) return `${Math.round(diffDays / 7)} week${diffDays >= 14 ? "s" : ""} ago`;
  if (diffDays < 365) return `${Math.round(diffDays / 30)} month${diffDays >= 60 ? "s" : ""} ago`;
  return `${Math.round(diffDays / 365)} year${diffDays >= 730 ? "s" : ""} ago`;
}

export function formattedDate(date: Date | string) {
  const value = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat("en-US", { month: "long", day: "numeric", year: "numeric" }).format(value);
}
