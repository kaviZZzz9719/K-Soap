import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Suspense } from "react";
import { CatalogBrowser } from "@/components/CatalogBrowser";
import { Reveal } from "@/components/Reveal";
import { ArrowRightIcon } from "@/components/icons";
import { getCollectionBySlug, getCollections, getFacets } from "@/lib/catalog";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const collection = await getCollectionBySlug(slug).catch(() => null);
  if (!collection) return { title: "Collection not found" };
  return { title: collection.name, description: collection.tagline };
}

export default async function CollectionPage({ params }: Props) {
  const { slug } = await params;
  const [collection, facets, all] = await Promise.all([
    getCollectionBySlug(slug).catch(() => null),
    getFacets().catch(() => null),
    getCollections().catch(() => []),
  ]);

  if (!collection) notFound();

  const others = all.filter((item) => item.slug !== collection.slug);

  return (
    <>
      <section className="relative overflow-hidden border-b border-line">
        <div className="absolute inset-0 -z-10">
          <Image src={collection.image} alt="" fill sizes="100vw" className="object-cover opacity-25" priority />
          <div className="absolute inset-0 bg-gradient-to-r from-shell via-shell/85 to-shell/40" />
        </div>
        <div className="mx-auto max-w-[1400px] px-4 py-14 sm:px-6 lg:px-10 lg:py-20">
          <nav className="flex items-center gap-2 text-[0.72rem] text-ink-mute" aria-label="Breadcrumb">
            <Link href="/" className="transition hover:text-ink">
              Home
            </Link>
            <span>/</span>
            <Link href="/shop" className="transition hover:text-ink">
              Shop
            </Link>
            <span>/</span>
            <span className="text-ink-2">{collection.name}</span>
          </nav>
          <div className="mt-5 grid gap-8 lg:grid-cols-[1.1fr_0.9fr] lg:items-end">
            <div>
              <span
                className="inline-block rounded-full px-3 py-1 text-[0.62rem] font-semibold tracking-[0.2em] uppercase"
                style={{ backgroundColor: collection.accent, color: "#1d2a23" }}
              >
                Collection
              </span>
              <h1 className="mt-4 font-display text-[clamp(2.4rem,6vw,4.2rem)] leading-[0.98] font-semibold text-balance">
                {collection.name}
              </h1>
              <p className="mt-3 font-display text-[clamp(1.1rem,2.2vw,1.5rem)] italic text-ink-soft">
                {collection.tagline}
              </p>
            </div>
            <p className="max-w-xl text-[0.98rem] leading-relaxed text-ink-soft">{collection.description}</p>
          </div>
        </div>
      </section>

      <Suspense fallback={<div className="min-h-[50vh]" />}>
        <CatalogBrowser facets={facets} lockedCollection={collection.slug} heading={collection.name} />
      </Suspense>

      {others.length > 0 ? (
        <section className="mx-auto max-w-[1400px] px-4 pb-8 sm:px-6 lg:px-10">
          <Reveal className="border-t border-line pt-14">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <h2 className="font-display text-[clamp(1.6rem,3vw,2.2rem)] font-semibold">Keep browsing</h2>
              <Link
                href="/shop"
                className="group inline-flex items-center gap-2 text-[0.74rem] font-semibold tracking-[0.16em] text-ink uppercase"
              >
                <span className="underline-sweep">All products</span>
                <ArrowRightIcon className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
            <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {others.map((item, index) => (
                <Reveal key={item.slug} delay={index * 80}>
                  <Link
                    href={`/collections/${item.slug}`}
                    className="group relative block aspect-[5/4] overflow-hidden rounded-[22px] border border-line/70"
                  >
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      sizes="(min-width: 1024px) 24vw, 46vw"
                      className="object-cover transition-transform duration-[1000ms] group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-ink/75 to-transparent" />
                    <div className="absolute inset-x-0 bottom-0 p-5">
                      <h3 className="font-display text-[1.15rem] font-semibold text-paper">{item.name}</h3>
                      <p className="mt-1 line-clamp-1 text-[0.78rem] text-paper/75">{item.tagline}</p>
                    </div>
                  </Link>
                </Reveal>
              ))}
            </div>
          </Reveal>
        </section>
      ) : null}
    </>
  );
}
