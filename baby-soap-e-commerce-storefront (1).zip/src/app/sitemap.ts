import type { MetadataRoute } from "next";
import { getAllSlugs, getCollections } from "@/lib/catalog";

export const dynamic = "force-dynamic";

const BASE = "https://kavi.soap";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const now = new Date();
  const staticEntries: MetadataRoute.Sitemap = [
    { url: `${BASE}/`, lastModified: now, changeFrequency: "daily", priority: 1 },
    { url: `${BASE}/shop`, lastModified: now, changeFrequency: "daily", priority: 0.9 },
    { url: `${BASE}/story`, lastModified: now, changeFrequency: "monthly", priority: 0.7 },
  ];

  try {
    const [collections, productSlugs] = await Promise.all([getCollections(), getAllSlugs()]);
    return [
      ...staticEntries,
      ...collections.map((collection) => ({
        url: `${BASE}/collections/${collection.slug}`,
        lastModified: now,
        changeFrequency: "weekly" as const,
        priority: 0.8,
      })),
      ...productSlugs.map((product) => ({
        url: `${BASE}/product/${product.slug}`,
        lastModified: now,
        changeFrequency: "weekly" as const,
        priority: 0.8,
      })),
    ];
  } catch {
    return staticEntries;
  }
}
