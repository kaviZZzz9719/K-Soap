import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Fraunces, Manrope } from "next/font/google";
import { CartDrawer } from "@/components/CartDrawer";
import { CartToast } from "@/components/CartToast";
import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";
import { CartProvider } from "@/lib/cart";
import { getCollections } from "@/lib/catalog";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  display: "swap",
  axes: ["SOFT", "WONK"],
});

const manrope = Manrope({
  subsets: ["latin"],
  variable: "--font-manrope",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://kavi.soap"),
  title: {
    default: "kAvI · Soap for babies, made properly",
    template: "%s · kAvI",
  },
  description:
    "Cold-processed soap bars for newborns, toddlers and the whole bath. Fragrance-free, dermatologist-tested, cured six weeks in small batches in Vermont.",
  openGraph: {
    title: "kAvI · Soap for babies, made properly",
    description:
      "Gentle cold-processed bars for the first bath and every bath after. Free shipping over $45.",
    type: "website",
    siteName: "kAvI",
  },
};

export const dynamic = "force-dynamic";

export default async function RootLayout({ children }: { children: ReactNode }) {
  let collections: { slug: string; name: string; tagline: string; image: string }[] = [];
  try {
    const rows = await getCollections();
    collections = rows.map((row) => ({
      slug: row.slug,
      name: row.name,
      tagline: row.tagline,
      image: row.image,
    }));
  } catch {
    collections = [];
  }

  return (
    <html lang="en" className={`${fraunces.variable} ${manrope.variable}`}>
      <body className="min-h-screen bg-shell font-sans text-ink antialiased">
        <CartProvider>
          <a
            href="#main"
            className="sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-[100] focus:rounded-full focus:bg-ink focus:px-5 focus:py-3 focus:text-paper"
          >
            Skip to content
          </a>
          <Header collections={collections} />
          <main id="main">{children}</main>
          <Footer />
          <CartDrawer />
          <CartToast />
        </CartProvider>
      </body>
    </html>
  );
}
