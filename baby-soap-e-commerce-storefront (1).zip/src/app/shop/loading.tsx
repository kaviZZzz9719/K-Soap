export default function ShopLoading() {
  return (
    <div className="mx-auto max-w-[1400px] px-4 pb-24 sm:px-6 lg:px-10">
      <div className="pt-12">
        <div className="skeleton h-3 w-28 rounded-full" />
        <div className="skeleton mt-4 h-12 w-72 rounded-full" />
        <div className="skeleton mt-4 h-4 w-full max-w-xl rounded-full" />
      </div>
      <div className="mt-12 grid gap-8 lg:grid-cols-[260px_1fr] lg:gap-12">
        <div className="hidden flex-col gap-5 lg:flex">
          {Array.from({ length: 5 }).map((_, index) => (
            <div key={index} className="flex flex-col gap-2.5">
              <div className="skeleton h-2.5 w-20 rounded-full" />
              <div className="skeleton h-4 w-36 rounded-full" />
              <div className="skeleton h-4 w-32 rounded-full" />
              <div className="skeleton h-4 w-28 rounded-full" />
            </div>
          ))}
        </div>
        <div>
          <div className="skeleton h-12 w-full rounded-full" />
          <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-4">
            {Array.from({ length: 8 }).map((_, index) => (
              <div key={index} className="overflow-hidden rounded-[22px] border border-line/70 bg-paper">
                <div className="skeleton aspect-square w-full" />
                <div className="flex flex-col gap-2 p-5">
                  <div className="skeleton h-2.5 w-20 rounded-full" />
                  <div className="skeleton h-4 w-3/4 rounded-full" />
                  <div className="skeleton h-3 w-1/2 rounded-full" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
