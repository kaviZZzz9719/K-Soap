import { Suspense } from "react";
import { CatalogBrowser } from "@/components/CatalogBrowser";
import { getFacets } from "@/lib/catalog";

export const dynamic = "force-dynamic";
export const metadata = {
  title: "Shop all bars & sets",
  description:
    "Every kAvI cold-processed soap bar and gift set, filterable by collection, skin need, scent and price.",
};

export default async function ShopPage() {
  const facets = await getFacets().catch(() => null);

  return (
    <Suspense fallback={<div className="min-h-[60vh]" />}>
      <CatalogBrowser
        facets={facets}
        heading="The full shelf"
        subheading="Twelve cold-processed bars and sets, made in Vermont. Filter by skin need, scent or price — everything ships plastic-free, free over $45."
      />
    </Suspense>
  );
}
