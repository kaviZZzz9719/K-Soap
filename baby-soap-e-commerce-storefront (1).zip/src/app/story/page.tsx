import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { BarFinder } from "@/components/BarFinder";
import { Reveal } from "@/components/Reveal";
import { ArrowRightIcon, CheckIcon, LeafIcon, ShieldIcon, TruckIcon } from "@/components/icons";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Our story",
  description:
    "Why kAvI makes cold-processed soap for babies in a small Vermont shed — the ingredient index, shipping policy and bath FAQ.",
};

const STATS = [
  { value: "6", label: "weeks cured", detail: "before any bar is wrapped" },
  { value: "12", label: "products", detail: "no more than we can make well" },
  { value: "4.9", label: "average rating", detail: "across every parent review" },
  { value: "0", label: "plastic", detail: "in our packaging, ever" },
];

const TIMELINE = [
  {
    year: "2019",
    title: "A kitchen, a thermometer, a rashy newborn",
    body: "Kavita’s second daughter reacted to every 'gentle' wash on the shelf. The ingredient list was longer than the recipe, so we started pouring bars on the stove with six things in them.",
  },
  {
    year: "2021",
    title: "First dermatologist panel",
    body: "We paid for repeat-insult patch testing with an independent lab instead of trusting a marketing claim. Every bar since has passed the same protocol before it reaches the shelf.",
  },
  {
    year: "2023",
    title: "The shed on Mill Lane",
    body: "A converted timber shed with cedar curing racks, a 40-litre stainless pot and room for 900 bars a month. Small enough that we still know which batch each bar came from.",
  },
  {
    year: "2026",
    title: "Batch 42, and 1,240 parent reviews",
    body: "We still make the whole range ourselves, and we still read every review — including the three-star ones, especially the three-star ones.",
  },
];

const INGREDIENT_INDEX = [
  { name: "Colloidal oatmeal", use: "Soothes itch and redness", concentration: "4–5%", source: "Milled in Vermont" },
  { name: "Unrefined shea butter", use: "Barrier repair, slip", concentration: "8–30%", source: "Women’s co-op, Ghana" },
  { name: "Raw goat milk", use: "Gentle lactic acid, fat", concentration: "Full water phase", source: "Jersey herd, 12 miles away" },
  { name: "Calendula officinalis", use: "Rough patches, calming", concentration: "6-week infusion", source: "Grown in our own beds" },
  { name: "Lavandula angustifolia", use: "Bedtime wind-down", concentration: "0.3%", source: "Single farm, Provence" },
  { name: "Aloe barbadensis", use: "Cooling, heat rash", concentration: "12%", source: "Freeze-dried, Dominican Republic" },
  { name: "Cera alba (beeswax)", use: "Bar structure, humectant", concentration: "3%", source: "Apiary, Brattleboro" },
];

const NEVER_LIST = [
  "SLS / SLES",
  "Parabens",
  "Phthalates",
  "Synthetic fragrance",
  "Artificial dyes",
  "Palm oil",
  "Formaldehyde donors",
  "Mineral oil",
];

const FAQS = [
  {
    q: "Can I use a bar on a newborn?",
    a: "Yes, if it’s fragrance-free and pH-balanced — that’s exactly what First Light is made for. Newborns don’t need a daily bath; two or three a week with a plain bar and water in between is what most paediatric dermatologists recommend. Skip soap entirely on the first week unless your midwife advises otherwise.",
  },
  {
    q: "Is a bar actually cleaner than liquid wash?",
    a: "A cured bar is self-preserving at its own pH, which is why it needs far fewer preservatives than a bottle of water-based wash. Keep it draining between uses and it stays hygienic — don’t leave it sitting in a puddle.",
  },
  {
    q: "How long does one bar last?",
    a: "Roughly 60 baths for one baby with normal use, or about six to eight weeks in a family bathroom. That’s three times longer than the equivalent volume of liquid wash, and it costs about a fifth as much per bath.",
  },
  {
    q: "My baby has eczema. Which bar?",
    a: "Start with Oat & Calendula Comfort for the body and Chamomile Hush for the face. Use lukewarm water, keep baths under ten minutes, and apply your prescribed emollient within three minutes of towelling off. Soap is not a treatment for eczema — it just shouldn’t make it worse.",
  },
  {
    q: "Will it sting their eyes?",
    a: "Our bars are formulated to pH 5.5 and tested tear-free on adult panels, but no true soap is completely neutral in the eye. Lather in your hands rather than rubbing the bar on the face, and keep a dry cloth nearby.",
  },
  {
    q: "What if it doesn’t suit my baby?",
    a: "Email hello@kavi.soap within 60 days for a full refund. You don’t need to send the bar back — use it on your own hands, or gift it. We’d rather know it didn’t work than have it sitting in a drawer.",
  },
];

export default function StoryPage() {
  return (
    <>
      <section className="relative overflow-hidden border-b border-line">
        <div className="mx-auto grid max-w-[1400px] items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-[1fr_1fr] lg:gap-16 lg:px-10 lg:py-24">
          <div>
            <p className="text-[0.66rem] font-semibold tracking-[0.24em] text-sage-deep uppercase">
              Brattleboro, Vermont · est. 2019
            </p>
            <h1 className="mt-5 font-display text-[clamp(2.4rem,6vw,4.4rem)] leading-[0.98] font-semibold text-balance">
              The label was longer than the recipe.
            </h1>
            <p className="mt-6 max-w-xl text-[1.02rem] leading-relaxed text-ink-soft">
              kAvI began because our founder’s newborn reacted to every product marketed as gentle. So we went back to
              the six ingredients that actually clean skin without stripping it, and we made them slowly — the way soap
              was made before anyone needed a preservative system.
            </p>
            <p className="mt-4 max-w-xl text-[1.02rem] leading-relaxed text-ink-soft">
              Everything is still poured, cut, stamped and wrapped by four people in a timber shed. We publish the
              working concentration of every active on the front of the carton, because “with oatmeal” and “5% colloidal
              oatmeal” are not the same sentence.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Link
                href="/shop"
                className="group inline-flex items-center gap-2 rounded-full bg-ink px-7 py-4 text-[0.76rem] font-semibold tracking-[0.16em] text-paper uppercase transition hover:bg-sage-deep"
              >
                Shop the range
                <ArrowRightIcon className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <Link
                href="/story#quiz"
                className="inline-flex items-center rounded-full border border-ink/25 px-7 py-4 text-[0.76rem] font-semibold tracking-[0.16em] text-ink uppercase transition hover:border-ink hover:bg-paper"
              >
                Find your bar
              </Link>
            </div>
          </div>

          <Reveal className="relative">
            <div className="relative aspect-[4/5] overflow-hidden rounded-[32px] border border-line/70 shadow-[var(--shadow-lift)]">
              <Image
                src="https://images.pexels.com/photos/32196687/pexels-photo-32196687.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1000&h=1250"
                alt="A mother holding her baby in a sunlit room"
                fill
                priority
                sizes="(min-width: 1024px) 45vw, 92vw"
                className="object-cover"
              />
            </div>
            <figure className="absolute -bottom-8 -left-4 w-56 rounded-[20px] border border-line bg-paper p-5 shadow-[var(--shadow-soft)] sm:-left-8">
              <blockquote className="font-display text-[0.95rem] leading-snug italic text-ink-2">
                “If I wouldn’t put it on my own newborn, it doesn’t go in a box.”
              </blockquote>
              <figcaption className="mt-3 text-[0.72rem] font-semibold tracking-[0.14em] text-ink-mute uppercase">
                Kavita Iyer · Founder
              </figcaption>
            </figure>
          </Reveal>
        </div>
      </section>

      <section className="border-b border-line bg-shell-2/60">
        <div className="mx-auto grid max-w-[1400px] gap-6 px-4 py-12 sm:grid-cols-2 sm:px-6 lg:grid-cols-4 lg:px-10">
          {STATS.map((stat, index) => (
            <Reveal key={stat.label} delay={index * 80}>
              <div>
                <p className="font-display text-[3rem] leading-none font-semibold text-sage-deep">{stat.value}</p>
                <p className="mt-2 text-[0.86rem] font-semibold tracking-[0.1em] text-ink uppercase">{stat.label}</p>
                <p className="mt-1 text-[0.84rem] text-ink-soft">{stat.detail}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-4 py-20 sm:px-6 lg:px-10 lg:py-24">
        <Reveal className="max-w-2xl">
          <p className="text-[0.66rem] font-semibold tracking-[0.24em] text-sage-deep uppercase">Seven years, four people</p>
          <h2 className="mt-3 font-display text-[clamp(2rem,4.4vw,3rem)] leading-[1.04] font-semibold">
            How the shed came about
          </h2>
        </Reveal>
        <div className="mt-12 grid gap-8 lg:grid-cols-2 lg:gap-14">
          {TIMELINE.map((entry, index) => (
            <Reveal key={entry.year} delay={(index % 2) * 90}>
              <div className="flex gap-6 border-t border-line pt-6">
                <span className="font-display text-[1.6rem] leading-none font-semibold text-clay">{entry.year}</span>
                <div>
                  <h3 className="font-display text-[1.3rem] font-semibold text-ink">{entry.title}</h3>
                  <p className="mt-2.5 text-[0.92rem] leading-relaxed text-ink-soft">{entry.body}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section id="quiz" className="scroll-mt-24 border-y border-line bg-paper/60 py-20 lg:py-24">
        <div className="mx-auto grid max-w-[1400px] items-center gap-12 px-4 sm:px-6 lg:grid-cols-[0.85fr_1.15fr] lg:gap-16 lg:px-10">
          <Reveal>
            <p className="text-[0.66rem] font-semibold tracking-[0.24em] text-sage-deep uppercase">Three questions</p>
            <h2 className="mt-3 font-display text-[clamp(2rem,4.4vw,3rem)] leading-[1.04] font-semibold text-balance">
              Tell us about the bather.
            </h2>
            <p className="mt-5 max-w-md text-[0.98rem] leading-relaxed text-ink-soft">
              Age, skin behaviour and what you want bath time to smell like. We’ll point you at one bar — not a
              routine, not a bundle you don’t need.
            </p>
          </Reveal>
          <Reveal delay={100}>
            <BarFinder />
          </Reveal>
        </div>
      </section>

      <section id="ingredients" className="mx-auto max-w-[1400px] scroll-mt-24 px-4 py-20 sm:px-6 lg:px-10 lg:py-24">
        <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16">
          <Reveal>
            <p className="text-[0.66rem] font-semibold tracking-[0.24em] text-sage-deep uppercase">Ingredient index</p>
            <h2 className="mt-3 font-display text-[clamp(2rem,4.4vw,3rem)] leading-[1.04] font-semibold text-balance">
              What’s in it, how much, and where it came from.
            </h2>
            <p className="mt-5 text-[0.98rem] leading-relaxed text-ink-soft">
              Every kAvI bar is built from the same short list of saponified oils. The actives below are what make each
              bar different — and we print the working concentration on the carton.
            </p>
            <div className="mt-8 rounded-[22px] border border-line bg-paper p-6">
              <h3 className="flex items-center gap-2 text-[0.7rem] font-semibold tracking-[0.18em] text-ink-mute uppercase">
                <ShieldIcon className="h-4 w-4 text-clay" />
                Never in a kAvI bar
              </h3>
              <ul className="mt-4 grid grid-cols-2 gap-2">
                {NEVER_LIST.map((item) => (
                  <li key={item} className="flex items-center gap-2 text-[0.84rem] text-ink-2">
                    <span className="grid h-4 w-4 shrink-0 place-items-center rounded-full bg-clay/15 text-clay-deep">
                      <CheckIcon className="h-2.5 w-2.5" strokeWidth={3} />
                    </span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>

          <Reveal delay={90}>
            <div className="overflow-hidden rounded-[24px] border border-line bg-paper">
              <div className="hidden grid-cols-[1.3fr_1.2fr_0.8fr_1.2fr] gap-4 border-b border-line bg-shell-2/60 px-6 py-3.5 text-[0.66rem] font-semibold tracking-[0.16em] text-ink-mute uppercase sm:grid">
                <span>Ingredient</span>
                <span>What it does</span>
                <span>Amount</span>
                <span>Source</span>
              </div>
              <ul className="divide-y divide-line">
                {INGREDIENT_INDEX.map((row) => (
                  <li
                    key={row.name}
                    className="grid gap-1.5 px-6 py-4 transition-colors duration-300 hover:bg-shell/70 sm:grid-cols-[1.3fr_1.2fr_0.8fr_1.2fr] sm:gap-4"
                  >
                    <span className="font-display text-[1.02rem] font-semibold text-ink">{row.name}</span>
                    <span className="text-[0.86rem] text-ink-soft">{row.use}</span>
                    <span className="text-[0.82rem] font-semibold tracking-[0.06em] text-sage-deep">
                      {row.concentration}
                    </span>
                    <span className="text-[0.84rem] text-ink-mute">{row.source}</span>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        </div>
      </section>

      <section id="shipping" className="scroll-mt-24 border-y border-line bg-ink py-20 text-paper lg:py-24">
        <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-10">
          <Reveal className="max-w-2xl">
            <p className="text-[0.66rem] font-semibold tracking-[0.24em] text-sage uppercase">Shipping & returns</p>
            <h2 className="mt-3 font-display text-[clamp(2rem,4.4vw,3rem)] leading-[1.04] font-semibold text-balance">
              Paper only, and a promise that doesn’t expire in 14 days.
            </h2>
          </Reveal>
          <div className="mt-12 grid gap-5 md:grid-cols-3">
            {[
              {
                icon: TruckIcon,
                title: "Free over $45",
                body: "Standard delivery is 3–5 business days and free above $45. Express is $8.95, overnight $18.95. Everything ships within one business day of ordering, from Vermont.",
              },
              {
                icon: LeafIcon,
                title: "Plastic-free, carbon-neutral",
                body: "Bars are wrapped in unbleached paper, boxed in recycled board and sealed with paper tape. Offsets are calculated per parcel and purchased annually through verified reforestation projects.",
              },
              {
                icon: ShieldIcon,
                title: "60-day gentle-skin promise",
                body: "If a bar doesn’t suit your baby, email us within 60 days for a full refund. Keep the bar, gift it, use it on your own hands — we only ask that you tell us what happened.",
              },
            ].map((card, index) => (
              <Reveal key={card.title} delay={index * 90}>
                <div className="h-full rounded-[24px] border border-paper/12 bg-paper/6 p-7 transition-colors duration-500 hover:border-sage/50 hover:bg-paper/10">
                  <card.icon className="h-6 w-6 text-sage" />
                  <h3 className="mt-5 font-display text-[1.3rem] font-semibold">{card.title}</h3>
                  <p className="mt-3 text-[0.9rem] leading-relaxed text-paper/70">{card.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section id="faq" className="mx-auto max-w-[1000px] scroll-mt-24 px-4 py-20 sm:px-6 lg:px-10 lg:py-24">
        <Reveal>
          <p className="text-[0.66rem] font-semibold tracking-[0.24em] text-sage-deep uppercase">Bath FAQ</p>
          <h2 className="mt-3 font-display text-[clamp(2rem,4.4vw,3rem)] leading-[1.04] font-semibold">
            Questions we get every week
          </h2>
        </Reveal>
        <div className="mt-10 divide-y divide-line border-y border-line">
          {FAQS.map((faq, index) => (
            <details key={faq.q} className="group py-1">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-6 py-5 text-left">
                <span className="font-display text-[1.15rem] font-semibold text-ink transition-colors group-hover:text-sage-deep">
                  {faq.q}
                </span>
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full border border-line text-ink-soft transition-transform duration-300 group-open:rotate-45">
                  <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={1.8}>
                    <path d="M12 5v14M5 12h14" strokeLinecap="round" />
                  </svg>
                </span>
              </summary>
              <p className="max-w-3xl pb-6 text-[0.94rem] leading-relaxed text-ink-soft">{faq.a}</p>
            </details>
          ))}
        </div>
      </section>
    </>
  );
}
