export default function ProductLoading() {
  return (
    <div className="mx-auto max-w-[1400px] px-4 pt-8 pb-16 sm:px-6 lg:px-10">
      <div className="skeleton h-3 w-64 rounded-full" />
      <div className="mt-8 grid gap-10 lg:grid-cols-[1.05fr_1fr] lg:gap-16">
        <div className="flex gap-4">
          <div className="hidden w-[86px] flex-col gap-3 lg:flex">
            {Array.from({ length: 3 }).map((_, index) => (
              <div key={index} className="skeleton h-[86px] w-[86px] rounded-[16px]" />
            ))}
          </div>
          <div className="skeleton aspect-square w-full rounded-[28px]" />
        </div>
        <div className="flex flex-col gap-5">
          <div className="skeleton h-3 w-28 rounded-full" />
          <div className="skeleton h-11 w-3/4 rounded-full" />
          <div className="skeleton h-4 w-1/2 rounded-full" />
          <div className="skeleton h-16 w-full rounded-[16px]" />
          <div className="skeleton h-20 w-full rounded-[16px]" />
          <div className="flex gap-3">
            <div className="skeleton h-14 w-36 rounded-full" />
            <div className="skeleton h-14 flex-1 rounded-full" />
          </div>
          <div className="skeleton h-12 w-full rounded-full" />
          <div className="skeleton h-40 w-full rounded-[18px]" />
        </div>
      </div>
    </div>
  );
}
