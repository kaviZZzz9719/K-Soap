import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Gallery } from "@/components/product/Gallery";
import { PurchasePanel } from "@/components/product/PurchasePanel";
import { ReviewSection } from "@/components/product/ReviewSection";
import { ProductCard } from "@/components/ProductCard";
import { Reveal } from "@/components/Reveal";
import { ArrowRightIcon, DropletIcon, LeafIcon, ShieldIcon } from "@/components/icons";
import { getProductBySlug, getProductReviews, searchProducts } from "@/lib/catalog";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const found = await getProductBySlug(slug).catch(() => null);
  if (!found) return { title: "Product not found" };
  return {
    title: found.product.name,
    description: found.product.summary,
    openGraph: {
      title: `${found.product.name} · kAvI`,
      description: found.product.summary,
      images: found.product.images[0] ? [{ url: found.product.images[0].url }] : undefined,
    },
  };
}

const PROMISES = [
  { icon: LeafIcon, title: "Six-week cold cure", body: "Hard, long-lasting, mild — no heat shortcuts." },
  { icon: DropletIcon, title: "pH 5.5, tear-free", body: "Matched to infant skin, tested on human panels." },
  { icon: ShieldIcon, title: "60-day promise", body: "If it doesn’t suit your baby, we refund it." },
];

export default async function ProductPage({ params }: Props) {
  const { slug } = await params;
  const [found, reviewRows] = await Promise.all([
    getProductBySlug(slug).catch(() => null),
    getProductReviews(slug).catch(() => []),
  ]);

  if (!found) notFound();

  const { product, collectionAccent } = found;

  const [related, alsoLiked] = await Promise.all([
    searchProducts({ collection: [product.collectionSlug], limit: 5 }).catch(() => ({ products: [], total: 0 })),
    searchProducts({ concerns: product.concerns.slice(0, 1), limit: 5 }).catch(() => ({ products: [], total: 0 })),
  ]);

  const relatedProducts = [...related.products, ...alsoLiked.products]
    .filter((item, index, array) => item.slug !== product.slug && array.findIndex((x) => x.slug === item.slug) === index)
    .slice(0, 4);

  return (
    <>
      <div className="relative overflow-hidden border-b border-line bg-[radial-gradient(90%_70%_at_85%_0%,#fffdf9_0%,#f5eee3_60%,#ece2d3_100%)]">
        <div className="mx-auto max-w-[1400px] px-4 pt-8 pb-16 sm:px-6 lg:px-10 lg:pt-10 lg:pb-24">
          <nav className="flex flex-wrap items-center gap-2 text-[0.72rem] text-ink-mute" aria-label="Breadcrumb">
            <Link href="/" className="transition hover:text-ink">
              Home
            </Link>
            <span>/</span>
            <Link href="/shop" className="transition hover:text-ink">
              Shop
            </Link>
            <span>/</span>
            <Link href={`/collections/${product.collectionSlug}`} className="transition hover:text-ink">
              {product.collectionName}
            </Link>
            <span>/</span>
            <span className="text-ink-2">{product.name}</span>
          </nav>

          <div className="mt-8 grid gap-10 lg:grid-cols-[1.05fr_1fr] lg:gap-16">
            <Gallery images={product.images} name={product.name} badge={product.badge} />
            <PurchasePanel product={product} />
          </div>

          <div className="mt-16 grid gap-4 rounded-[26px] border border-line/70 bg-paper/70 p-6 sm:grid-cols-3 sm:p-8">
            {PROMISES.map(({ icon: Icon, title, body }) => (
              <div key={title} className="flex items-start gap-3">
                <span
                  className="grid h-10 w-10 shrink-0 place-items-center rounded-full"
                  style={{ backgroundColor: `${collectionAccent}44`, color: "#1d2a23" }}
                >
                  <Icon className="h-5 w-5" />
                </span>
                <div>
                  <p className="font-display text-[1.02rem] font-semibold text-ink">{title}</p>
                  <p className="mt-1 text-[0.84rem] leading-relaxed text-ink-soft">{body}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1400px] px-4 py-20 sm:px-6 lg:px-10 lg:py-24">
        <ReviewSection
          slug={product.slug}
          reviews={reviewRows}
          rating={product.rating}
          reviewCount={product.reviewCount}
        />
      </div>

      {relatedProducts.length > 0 ? (
        <section className="mx-auto max-w-[1400px] px-4 pb-24 sm:px-6 lg:px-10">
          <Reveal className="flex flex-wrap items-end justify-between gap-5 border-t border-line pt-16">
            <div>
              <p className="text-[0.66rem] font-semibold tracking-[0.24em] text-sage-deep uppercase">
                Complete the ritual
              </p>
              <h2 className="mt-3 font-display text-[clamp(1.9rem,4vw,2.8rem)] leading-tight font-semibold">
                Pairs well with
              </h2>
            </div>
            <Link
              href={`/collections/${product.collectionSlug}`}
              className="group inline-flex items-center gap-2 text-[0.74rem] font-semibold tracking-[0.16em] text-ink uppercase"
            >
              <span className="underline-sweep">All {product.collectionName}</span>
              <ArrowRightIcon className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
            </Link>
          </Reveal>

          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4 lg:gap-5">
            {relatedProducts.map((item, index) => (
              <Reveal key={item.slug} delay={index * 80} className="h-full">
                <ProductCard product={item} />
              </Reveal>
            ))}
          </div>
        </section>
      ) : null}
    </>
  );
}
