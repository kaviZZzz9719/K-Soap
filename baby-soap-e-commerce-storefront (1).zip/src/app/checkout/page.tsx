import type { Metadata } from "next";
import { CheckoutFlow } from "@/components/CheckoutFlow";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Checkout",
  description: "Complete your kAvI order — three quick steps, no account required.",
};

export default function CheckoutPage() {
  return <CheckoutFlow />;
}
