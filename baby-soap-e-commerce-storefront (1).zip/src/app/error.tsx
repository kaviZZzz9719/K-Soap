"use client";

import { useEffect } from "react";
import Link from "next/link";
import { ArrowRightIcon } from "@/components/icons";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[kAvI] Storefront error:", error);
  }, [error]);

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-xl flex-col items-center justify-center gap-6 px-4 py-24 text-center">
      <p className="text-[0.66rem] font-semibold tracking-[0.24em] text-clay uppercase">Something slipped</p>
      <h1 className="font-display text-[clamp(2rem,5vw,3.2rem)] leading-[1.05] font-semibold text-balance">
        We couldn’t load that part of the shop.
      </h1>
      <p className="max-w-md text-[0.98rem] leading-relaxed text-ink-soft">
        Nothing in your bag is lost — it lives on this device. Try again, or carry on browsing while we sort it out.
      </p>
      <div className="flex flex-wrap justify-center gap-3">
        <button
          type="button"
          onClick={reset}
          className="group inline-flex items-center gap-2 rounded-full bg-ink px-7 py-4 text-[0.76rem] font-semibold tracking-[0.16em] text-paper uppercase transition hover:bg-sage-deep"
        >
          Try again
          <ArrowRightIcon className="h-4 w-4 transition-transform group-hover:translate-x-1" />
        </button>
        <Link
          href="/"
          className="inline-flex items-center rounded-full border border-ink/25 px-7 py-4 text-[0.76rem] font-semibold tracking-[0.16em] text-ink uppercase transition hover:border-ink hover:bg-paper"
        >
          Back home
        </Link>
      </div>
      {error.digest ? <p className="text-[0.72rem] text-ink-mute">Reference: {error.digest}</p> : null}
    </div>
  );
}
