import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { ProductCard } from "@/components/ProductCard";
import { Reveal } from "@/components/Reveal";
import { ArrowRightIcon, CheckIcon, LeafIcon, TruckIcon } from "@/components/icons";
import { formatCents, formattedDate } from "@/lib/cart-types";
import { searchProducts } from "@/lib/catalog";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Order confirmed" };

type Props = { params: Promise<{ number: string }> };

const TIMELINE = [
  { label: "Order placed", detail: "We’ve got it — a receipt is on the way to your inbox." },
  { label: "Wrapped in the shed", detail: "Hand-wrapped in paper and tied with cotton twine." },
  { label: "Shipped", detail: "Carbon-neutral courier, tracking emailed as soon as it moves." },
  { label: "At your door", detail: "Typically 3–5 business days for standard delivery." },
];

export default async function OrderPage({ params }: Props) {
  const { number } = await params;
  const orderRows = await db
    .select()
    .from(orders)
    .where(eq(orders.orderNumber, number.toUpperCase()))
    .limit(1)
    .catch(() => []);

  const order = orderRows[0];
  if (!order) notFound();

  const [items, recommended] = await Promise.all([
    db.select().from(orderItems).where(eq(orderItems.orderId, order.id)).catch(() => []),
    searchProducts({ sort: "featured", limit: 4 }).catch(() => ({ products: [], total: 0 })),
  ]);

  const activeStage = order.status === "shipped" ? 3 : order.status === "packed" ? 2 : 1;

  return (
    <div className="mx-auto max-w-[1400px] px-4 py-14 sm:px-6 lg:px-10 lg:py-20">
      <div className="grid gap-10 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16">
        <div>
          <span className="inline-flex items-center gap-2 rounded-full bg-sage-mist px-4 py-1.5 text-[0.66rem] font-semibold tracking-[0.2em] text-sage-deep uppercase">
            <CheckIcon className="h-3.5 w-3.5" strokeWidth={2.6} />
            Order confirmed
          </span>
          <h1 className="mt-5 font-display text-[clamp(2.2rem,5vw,3.6rem)] leading-[1.02] font-semibold text-balance">
            Thank you, {order.customerName.split(" ")[0]}.
          </h1>
          <p className="mt-4 max-w-lg text-[1rem] leading-relaxed text-ink-soft">
            Order <strong className="font-semibold text-ink">{order.orderNumber}</strong> was placed on{" "}
            {formattedDate(order.placedAt)}. A receipt is on its way to {order.email} — you don’t need an account to
            track it.
          </p>

          <div className="mt-9 rounded-[26px] border border-line bg-paper p-6 sm:p-8">
            <h2 className="font-display text-[1.35rem] font-semibold text-ink">What happens next</h2>
            <ol className="mt-6 flex flex-col">
              {TIMELINE.map((stage, index) => {
                const done = index < activeStage;
                const current = index === activeStage;
                return (
                  <li key={stage.label} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <span
                        className={`grid h-7 w-7 shrink-0 place-items-center rounded-full border text-[0.66rem] font-semibold transition ${
                          done
                            ? "border-sage-deep bg-sage-deep text-paper"
                            : current
                              ? "border-ink bg-paper text-ink"
                              : "border-line bg-paper text-ink-mute"
                        }`}
                      >
                        {done ? <CheckIcon className="h-3.5 w-3.5" strokeWidth={3} /> : index + 1}
                      </span>
                      {index < TIMELINE.length - 1 ? (
                        <span className={`my-1 w-px flex-1 ${done ? "bg-sage/60" : "bg-line"}`} />
                      ) : null}
                    </div>
                    <div className={`pb-7 ${index === TIMELINE.length - 1 ? "pb-0" : ""}`}>
                      <p className={`font-display text-[1.05rem] font-semibold ${done || current ? "text-ink" : "text-ink-mute"}`}>
                        {stage.label}
                        {current ? <span className="ml-2 text-[0.68rem] tracking-[0.14em] text-clay-deep uppercase">In progress</span> : null}
                      </p>
                      <p className="mt-1 max-w-md text-[0.86rem] leading-relaxed text-ink-soft">{stage.detail}</p>
                    </div>
                  </li>
                );
              })}
            </ol>
          </div>

          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <div className="rounded-[22px] border border-line bg-paper p-6">
              <h3 className="flex items-center gap-2 text-[0.7rem] font-semibold tracking-[0.18em] text-ink-mute uppercase">
                <TruckIcon className="h-4 w-4 text-sage-deep" />
                Shipping to
              </h3>
              <address className="mt-3 text-[0.9rem] leading-relaxed text-ink-2 not-italic">
                {order.customerName}
                <br />
                {order.shippingAddress.address1}
                {order.shippingAddress.address2 ? (
                  <>
                    <br />
                    {order.shippingAddress.address2}
                  </>
                ) : null}
                <br />
                {order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.postalCode}
                <br />
                {order.shippingAddress.country}
                {order.phone ? (
                  <>
                    <br />
                    {order.phone}
                  </>
                ) : null}
              </address>
              <p className="mt-3 text-[0.8rem] text-ink-soft capitalize">{order.shippingMethod} delivery</p>
            </div>
            <div className="rounded-[22px] border border-line bg-paper p-6">
              <h3 className="flex items-center gap-2 text-[0.7rem] font-semibold tracking-[0.18em] text-ink-mute uppercase">
                <LeafIcon className="h-4 w-4 text-sage-deep" />
                Payment
              </h3>
              <p className="mt-3 text-[0.9rem] leading-relaxed text-ink-2">
                {order.paymentBrand} ending {order.paymentLast4}
                <br />
                Charged {formatCents(order.totalCents)} on {formattedDate(order.placedAt)}
                {order.promoCode ? (
                  <>
                    <br />
                    Code {order.promoCode} applied
                  </>
                ) : null}
              </p>
              {order.giftNote ? (
                <p className="mt-4 border-t border-line pt-4 text-[0.86rem] leading-relaxed text-ink-soft italic">
                  “{order.giftNote}”
                </p>
              ) : null}
            </div>
          </div>
        </div>

        <div className="lg:sticky lg:top-32 lg:self-start">
          <div className="rounded-[26px] border border-line bg-paper p-6 shadow-[var(--shadow-soft)] sm:p-8">
            <h2 className="font-display text-[1.35rem] font-semibold text-ink">
              Your box · {items.reduce((sum, item) => sum + item.quantity, 0)} items
            </h2>
            <ul className="mt-6 flex flex-col gap-5">
              {items.map((item) => (
                <li key={item.id} className="flex gap-4">
                  <Link
                    href={`/product/${item.slug}`}
                    className="relative h-[76px] w-[64px] shrink-0 overflow-hidden rounded-[12px] bg-shell-2"
                  >
                    {item.imageUrl ? (
                      <Image src={item.imageUrl} alt={item.name} fill sizes="64px" className="object-cover" />
                    ) : null}
                  </Link>
                  <div className="min-w-0 flex-1">
                    <Link
                      href={`/product/${item.slug}`}
                      className="block truncate font-display text-[1rem] font-semibold text-ink hover:text-sage-deep"
                    >
                      {item.name}
                    </Link>
                    <p className="text-[0.78rem] text-ink-soft">
                      {item.variantLabel} · Qty {item.quantity}
                    </p>
                  </div>
                  <p className="shrink-0 text-[0.92rem] font-semibold text-ink tabular-nums">
                    {formatCents(item.unitPriceCents * item.quantity)}
                  </p>
                </li>
              ))}
            </ul>

            <dl className="mt-7 flex flex-col gap-2 border-t border-line pt-5 text-[0.88rem]">
              <div className="flex justify-between">
                <dt className="text-ink-soft">Subtotal</dt>
                <dd className="font-medium text-ink tabular-nums">{formatCents(order.subtotalCents)}</dd>
              </div>
              {order.discountCents > 0 ? (
                <div className="flex justify-between text-sage-deep">
                  <dt>Discount {order.promoCode ? `(${order.promoCode})` : ""}</dt>
                  <dd className="font-semibold">−{formatCents(order.discountCents)}</dd>
                </div>
              ) : null}
              <div className="flex justify-between">
                <dt className="text-ink-soft">Shipping</dt>
                <dd className="font-medium text-ink tabular-nums">
                  {order.shippingCents === 0 ? "Free" : formatCents(order.shippingCents)}
                </dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-ink-soft">Tax</dt>
                <dd className="font-medium text-ink tabular-nums">{formatCents(order.taxCents)}</dd>
              </div>
              <div className="mt-2 flex items-center justify-between border-t border-line pt-4">
                <dt className="font-display text-[1.05rem] font-semibold text-ink">Total paid</dt>
                <dd className="font-display text-[1.5rem] font-semibold text-ink">{formatCents(order.totalCents)}</dd>
              </div>
            </dl>

            <div className="mt-7 flex flex-col gap-2.5">
              <Link
                href="/shop"
                className="group inline-flex items-center justify-center gap-2 rounded-full bg-ink px-6 py-3.5 text-[0.74rem] font-semibold tracking-[0.14em] text-paper uppercase transition hover:bg-sage-deep"
              >
                Continue shopping
                <ArrowRightIcon className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <Link
                href="/"
                className="inline-flex items-center justify-center rounded-full border border-line px-6 py-3.5 text-[0.74rem] font-semibold tracking-[0.14em] text-ink uppercase transition hover:border-ink"
              >
                Back home
              </Link>
            </div>
          </div>
        </div>
      </div>

      {recommended.products.length > 0 ? (
        <section className="mt-20">
          <Reveal className="border-t border-line pt-14">
            <h2 className="font-display text-[clamp(1.8rem,3.6vw,2.6rem)] font-semibold">Families also reorder</h2>
            <p className="mt-2 max-w-lg text-[0.95rem] text-ink-soft">
              Bars that live in the second bathroom, the holiday bag and the grandparents’ house.
            </p>
          </Reveal>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4 lg:gap-5">
            {recommended.products.map((product, index) => (
              <Reveal key={product.slug} delay={index * 80} className="h-full">
                <ProductCard product={product} />
              </Reveal>
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}
