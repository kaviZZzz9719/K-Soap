import Link from "next/link";
import { ArrowRightIcon, DropletIcon } from "@/components/icons";

export default function NotFound() {
  return (
    <div className="mx-auto flex min-h-[70vh] max-w-2xl flex-col items-center justify-center gap-6 px-4 py-24 text-center">
      <span className="grid h-20 w-20 place-items-center rounded-full bg-shell-2 text-sage-deep">
        <DropletIcon className="h-9 w-9" />
      </span>
      <p className="text-[0.66rem] font-semibold tracking-[0.24em] text-clay uppercase">Error 404</p>
      <h1 className="font-display text-[clamp(2.2rem,6vw,3.6rem)] leading-[1.02] font-semibold text-balance">
        This page must have dissolved in the bath.
      </h1>
      <p className="max-w-md text-[1rem] leading-relaxed text-ink-soft">
        The link may be old, or the bar you were looking for is out of the current batch. The full shelf is always one
        click away.
      </p>
      <div className="mt-2 flex flex-wrap justify-center gap-3">
        <Link
          href="/shop"
          className="group inline-flex items-center gap-2 rounded-full bg-ink px-7 py-4 text-[0.76rem] font-semibold tracking-[0.16em] text-paper uppercase transition hover:bg-sage-deep"
        >
          Shop all bars
          <ArrowRightIcon className="h-4 w-4 transition-transform group-hover:translate-x-1" />
        </Link>
        <Link
          href="/"
          className="inline-flex items-center rounded-full border border-ink/25 px-7 py-4 text-[0.76rem] font-semibold tracking-[0.16em] text-ink uppercase transition hover:border-ink hover:bg-paper"
        >
          Back home
        </Link>
      </div>
    </div>
  );
}
