import Image from "next/image";
import Link from "next/link";
import { ProductCard } from "@/components/ProductCard";
import { RatingLine, Stars } from "@/components/Rating";
import { Reveal } from "@/components/Reveal";
import {
  ArrowRightIcon,
  CheckIcon,
  DropletIcon,
  LeafIcon,
  MoonIcon,
  ShieldIcon,
  SparkleIcon,
  TruckIcon,
} from "@/components/icons";
import { formatCents } from "@/lib/cart-types";
import { getCollections, getStoreStats, searchProducts } from "@/lib/catalog";
import { db } from "@/db";
import { products, reviews } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

const MARQUEE_ITEMS = [
  "No SLS or SLES",
  "pH 5.5 · skin-matched",
  "Six-week cold cure",
  "Fragrance-free options",
  "Paediatric dermatologist tested",
  "Plastic-free packaging",
  "Never tested on animals",
  "Made in Vermont",
];

const RITUAL_STEPS = [
  {
    step: "01",
    title: "We weigh, we wait",
    body: "Olive, coconut and shea are blended at trace, poured into wooden moulds and left to saponify slowly — no heat shortcuts, so the glycerin stays in the bar.",
    icon: LeafIcon,
  },
  {
    step: "02",
    title: "Six weeks of cure",
    body: "Every bar rests on cedar racks for six weeks. That is what makes a kAvI bar hard, long-lasting and mild instead of soft and stingy.",
    icon: MoonIcon,
  },
  {
    step: "03",
    title: "Tested on skin, not animals",
    body: "Repeat-insult patch testing with an independent lab, plus a 21-day parent diary study before anything joins the shelf.",
    icon: ShieldIcon,
  },
];

const INGREDIENTS = [
  { name: "Colloidal oatmeal", detail: "4–5% in our Calm bars", note: "Clinically studied for itch and redness" },
  { name: "Raw goat milk", detail: "First Light", note: "Natural lactic acid, gentle on newborn skin" },
  { name: "Unrefined shea", detail: "30% in Shea Silk", note: "Grade A, from a women’s co-op in Ghana" },
  { name: "Calendula petals", detail: "Infused six weeks", note: "Whole petals pressed into every Comfort bar" },
];

export default async function HomePage() {
  const [collections, featured, stats, topReviews] = await Promise.all([
    getCollections().catch(() => []),
    searchProducts({ sort: "featured", limit: 4 }).catch(() => ({ products: [], total: 0 })),
    getStoreStats().catch(() => ({
      productCount: 0,
      averageRating: "0",
      reviewCount: 0,
      averageReviewRating: "0",
    })),
    db
      .select({
        body: reviews.body,
        authorName: reviews.authorName,
        authorLocation: reviews.authorLocation,
        rating: reviews.rating,
        productName: products.name,
        productSlug: products.slug,
      })
      .from(reviews)
      .innerJoin(products, eq(reviews.productId, products.id))
      .orderBy(desc(reviews.helpfulCount))
      .limit(6)
      .catch(() => []),
  ]);

  const hero = featured.products[0];

  return (
    <>
      {/* ── Hero ─────────────────────────────────────────────── */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(120%_90%_at_12%_0%,#fffdf9_0%,#f5eee3_45%,#ece2d3_100%)]" />
        <div className="pointer-events-none absolute -top-10 right-[8%] -z-10 h-40 w-40 rounded-full border border-sage/25" />
        <div className="pointer-events-none absolute top-1/3 right-[2%] -z-10 h-24 w-24 rounded-full bg-blush/25 blur-2xl" />

        <div className="mx-auto grid max-w-[1400px] items-center gap-12 px-4 pt-12 pb-16 sm:px-6 lg:grid-cols-[1.05fr_1fr] lg:gap-16 lg:px-10 lg:pt-20 lg:pb-24">
          <div>
            <div className="animate-rise inline-flex items-center gap-2 rounded-full border border-line bg-paper/80 px-4 py-1.5 backdrop-blur">
              <SparkleIcon className="h-3.5 w-3.5 text-honey" />
              <span className="text-[0.66rem] font-semibold tracking-[0.2em] text-ink-2 uppercase">
                Batch 42 just cured · Vermont
              </span>
            </div>

            <h1
              className="animate-rise mt-6 font-display text-[clamp(2.9rem,7.4vw,5.4rem)] leading-[0.95] font-semibold text-balance"
              style={{ animationDelay: "80ms" }}
            >
              Soap for babies,
              <span className="relative ml-2 inline-block">
                <span className="relative z-10 italic">made like</span>
                <span className="absolute inset-x-0 bottom-1.5 z-0 h-3 rounded-full bg-blush/55 sm:bottom-2 sm:h-4" />
              </span>
              <br />
              it matters.
            </h1>

            <p
              className="animate-rise mt-6 max-w-lg text-[1.02rem] leading-relaxed text-ink-soft"
              style={{ animationDelay: "160ms" }}
            >
              Cold-processed bars with six to ten ingredients you can pronounce. No sulphates, no synthetic
              fragrance, no rush. Built for the first bath and every muddy-knee bath after it.
            </p>

            <div className="animate-rise mt-9 flex flex-wrap items-center gap-3" style={{ animationDelay: "240ms" }}>
              <Link
                href="/shop"
                className="group inline-flex items-center gap-2 rounded-full bg-ink px-7 py-4 text-[0.76rem] font-semibold tracking-[0.16em] text-paper uppercase transition-all duration-300 hover:bg-sage-deep hover:shadow-[var(--shadow-lift)]"
              >
                Shop the range
                <ArrowRightIcon className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </Link>
              <Link
                href="/story#quiz"
                className="inline-flex items-center gap-2 rounded-full border border-ink/25 px-7 py-4 text-[0.76rem] font-semibold tracking-[0.16em] text-ink uppercase transition hover:border-ink hover:bg-paper"
              >
                Find your bar
              </Link>
            </div>

            <div
              className="animate-rise mt-10 flex flex-wrap items-center gap-x-8 gap-y-4 border-t border-line pt-7"
              style={{ animationDelay: "320ms" }}
            >
              <div>
                <Stars rating={Number.parseFloat(stats.averageReviewRating) || 4.9} size={15} />
                <p className="mt-1.5 text-[0.78rem] text-ink-soft">
                  <strong className="font-semibold text-ink">
                    {(Number.parseFloat(stats.averageReviewRating) || 4.9).toFixed(1)}
                  </strong>{" "}
                  from {stats.reviewCount || 1240} parent reviews
                </p>
              </div>
              <div className="flex items-center gap-2">
                <ShieldIcon className="h-5 w-5 text-sage-deep" />
                <p className="text-[0.78rem] text-ink-soft">
                  Dermatologist tested
                  <br />
                  on infant panels
                </p>
              </div>
              <div className="flex items-center gap-2">
                <TruckIcon className="h-5 w-5 text-sage-deep" />
                <p className="text-[0.78rem] text-ink-soft">
                  Free shipping
                  <br />
                  over {formatCents(4500)}
                </p>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="relative aspect-[4/5] overflow-hidden rounded-[36px] border border-line/70 shadow-[var(--shadow-lift)] sm:aspect-[5/6]">
              <Image
                src="https://images.pexels.com/photos/6849430/pexels-photo-6849430.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=1440"
                alt="A parent gently bathing a baby in warm evening light"
                fill
                priority
                sizes="(min-width: 1024px) 45vw, 92vw"
                className="animate-kenburns object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/45 via-transparent to-transparent" />
              <div className="absolute bottom-5 left-5 right-5 flex items-center justify-between gap-4 rounded-[20px] border border-paper/25 bg-ink/35 px-5 py-4 backdrop-blur-md">
                <div>
                  <p className="text-[0.62rem] font-semibold tracking-[0.2em] text-paper/70 uppercase">
                    The nightly ritual
                  </p>
                  <p className="font-display text-[1.05rem] font-semibold text-paper">
                    Warm water, one bar, lights low
                  </p>
                </div>
                <DropletIcon className="h-7 w-7 shrink-0 text-paper/80" />
              </div>
            </div>

            {[0, 1, 2, 3].map((index) => (
              <span
                key={index}
                className="pointer-events-none absolute hidden h-3 w-3 rounded-full border border-paper/70 bg-paper/25 lg:block"
                style={{
                  left: `${8 + index * 22}%`,
                  bottom: `${18 + (index % 2) * 12}%`,
                  animation: `bubble ${11 + index * 3}s ease-in ${index * 1.6}s infinite`,
                }}
              />
            ))}

            {hero ? (
              <div className="animate-pop absolute -bottom-8 -left-4 w-[248px] rounded-[22px] border border-line bg-paper p-3 shadow-[var(--shadow-lift)] sm:-left-8 lg:-left-14">
                <Link href={`/product/${hero.slug}`} className="group flex items-center gap-3">
                  <span className="relative h-16 w-16 shrink-0 overflow-hidden rounded-[14px] bg-shell-2">
                    {hero.images[0] ? (
                      <Image
                        src={hero.images[0].url}
                        alt={hero.images[0].alt}
                        fill
                        sizes="64px"
                        className="object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                    ) : null}
                  </span>
                  <span className="min-w-0">
                    <span className="block text-[0.6rem] font-semibold tracking-[0.18em] text-sage-deep uppercase">
                      Bestseller
                    </span>
                    <span className="block truncate font-display text-[0.95rem] font-semibold text-ink">
                      {hero.name}
                    </span>
                    <span className="mt-0.5 flex items-center gap-1.5">
                      <span className="font-display text-[0.95rem] font-semibold text-ink">
                        {formatCents(hero.priceCents)}
                      </span>
                      <RatingLine rating={hero.rating} count={hero.reviewCount} size={11} />
                    </span>
                  </span>
                </Link>
              </div>
            ) : null}
          </div>
        </div>
      </section>

      {/* ── Marquee ──────────────────────────────────────────── */}
      <section className="border-y border-line bg-shell-2/70 py-4">
        <div className="edge-fade flex overflow-hidden">
          <div className="flex shrink-0 animate-[marquee_42s_linear_infinite] items-center gap-10 pr-10">
            {[...MARQUEE_ITEMS, ...MARQUEE_ITEMS].map((item, index) => (
              <span key={`${item}-${index}`} className="flex shrink-0 items-center gap-10">
                <span className="flex items-center gap-2.5 text-[0.72rem] font-semibold tracking-[0.2em] text-ink-soft uppercase">
                  <CheckIcon className="h-3.5 w-3.5 text-sage-deep" />
                  {item}
                </span>
                <span className="h-1 w-1 rounded-full bg-line" />
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ── Collections ──────────────────────────────────────── */}
      <section className="mx-auto max-w-[1400px] px-4 py-20 sm:px-6 lg:px-10 lg:py-28">
        <Reveal className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="text-[0.66rem] font-semibold tracking-[0.24em] text-sage-deep uppercase">
              Five shelves, one standard
            </p>
            <h2 className="mt-3 max-w-xl font-display text-[clamp(2rem,4.4vw,3.2rem)] leading-[1.04] font-semibold text-balance">
              Featured collections
            </h2>
          </div>
          <Link
            href="/shop"
            className="group inline-flex items-center gap-2 text-[0.76rem] font-semibold tracking-[0.16em] text-ink uppercase"
          >
            <span className="underline-sweep">Browse everything</span>
            <ArrowRightIcon className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
          </Link>
        </Reveal>

        <div className="mt-10 grid gap-4 sm:gap-5 lg:grid-cols-6">
          {collections.slice(0, 2).map((collection, index) => (
            <Reveal
              key={collection.slug}
              delay={index * 90}
              className="lg:col-span-3"
            >
              <Link
                href={`/collections/${collection.slug}`}
                className="group relative block aspect-[4/3] overflow-hidden rounded-[28px] border border-line/70 sm:aspect-[16/11]"
              >
                <Image
                  src={collection.image}
                  alt={collection.name}
                  fill
                  sizes="(min-width: 1024px) 48vw, 92vw"
                  className="object-cover transition-transform duration-[1100ms] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.07]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/25 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-6 sm:p-8">
                  <span
                    className="inline-flex items-center gap-2 rounded-full px-3 py-1 text-[0.62rem] font-semibold tracking-[0.18em] uppercase"
                    style={{ backgroundColor: collection.accent, color: "#1d2a23" }}
                  >
                    {collection.tagline}
                  </span>
                  <h3 className="mt-3 font-display text-[clamp(1.5rem,2.8vw,2.1rem)] font-semibold text-paper">
                    {collection.name}
                  </h3>
                  <span className="mt-2 inline-flex items-center gap-2 text-[0.76rem] font-semibold tracking-[0.14em] text-paper/85 uppercase">
                    Shop collection
                    <ArrowRightIcon className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1.5" />
                  </span>
                </div>
              </Link>
            </Reveal>
          ))}

          {collections.slice(2, 5).map((collection, index) => (
            <Reveal key={collection.slug} delay={index * 90} className="lg:col-span-2">
              <Link
                href={`/collections/${collection.slug}`}
                className="group relative block aspect-square overflow-hidden rounded-[28px] border border-line/70"
              >
                <Image
                  src={collection.image}
                  alt={collection.name}
                  fill
                  sizes="(min-width: 1024px) 32vw, 92vw"
                  className="object-cover transition-transform duration-[1100ms] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.07]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/82 via-ink/20 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-6">
                  <h3 className="font-display text-[1.4rem] leading-tight font-semibold text-paper">
                    {collection.name}
                  </h3>
                  <p className="mt-1.5 line-clamp-2 text-[0.8rem] text-paper/75">{collection.tagline}</p>
                  <span className="mt-3 inline-flex items-center gap-1.5 text-[0.68rem] font-semibold tracking-[0.16em] text-paper/85 uppercase">
                    Shop
                    <ArrowRightIcon className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1" />
                  </span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ── Bestsellers ──────────────────────────────────────── */}
      <section className="relative border-y border-line bg-paper/60 py-20 lg:py-28">
        <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-10">
          <Reveal className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="text-[0.66rem] font-semibold tracking-[0.24em] text-sage-deep uppercase">
                What families reorder
              </p>
              <h2 className="mt-3 font-display text-[clamp(2rem,4.4vw,3.2rem)] leading-[1.04] font-semibold">
                The bestsellers
              </h2>
            </div>
            <p className="max-w-sm text-[0.9rem] leading-relaxed text-ink-soft">
              Four bars that account for most of what leaves the shed. Add straight to your bag — no account needed.
            </p>
          </Reveal>

          <div className="mt-10 grid gap-4 sm:grid-cols-2 sm:gap-5 lg:grid-cols-4">
            {featured.products.map((product, index) => (
              <Reveal key={product.slug} delay={index * 80} className="h-full">
                <ProductCard product={product} priority={index < 2} />
              </Reveal>
            ))}
          </div>

          <Reveal className="mt-10 flex justify-center">
            <Link
              href="/shop"
              className="group inline-flex items-center gap-2 rounded-full border border-ink/25 px-8 py-4 text-[0.76rem] font-semibold tracking-[0.16em] text-ink uppercase transition hover:border-ink hover:bg-shell-2"
            >
              See all {stats.productCount || 12} products
              <ArrowRightIcon className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
            </Link>
          </Reveal>
        </div>
      </section>

      {/* ── Ritual / process ─────────────────────────────────── */}
      <section className="mx-auto max-w-[1400px] px-4 py-20 sm:px-6 lg:px-10 lg:py-28">
        <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-20">
          <Reveal>
            <div className="relative">
              <div className="relative aspect-[4/5] overflow-hidden rounded-[32px] border border-line/70">
                <Image
                  src="https://images.pexels.com/photos/7500419/pexels-photo-7500419.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1000&h=1250"
                  alt="Assorted handmade kAvI soap bars curing on racks"
                  fill
                  sizes="(min-width: 1024px) 40vw, 92vw"
                  className="object-cover"
                />
              </div>
              <div className="animate-float absolute -right-4 -bottom-8 w-44 rounded-[22px] border border-line bg-paper p-4 shadow-[var(--shadow-soft)] sm:-right-8">
                <p className="font-display text-4xl leading-none font-semibold text-sage-deep">6</p>
                <p className="mt-1.5 text-[0.78rem] leading-snug text-ink-soft">
                  weeks cured before a single bar is wrapped
                </p>
              </div>
            </div>
          </Reveal>

          <div>
            <Reveal>
              <p className="text-[0.66rem] font-semibold tracking-[0.24em] text-sage-deep uppercase">
                How a kAvI bar is made
              </p>
              <h2 className="mt-3 max-w-lg font-display text-[clamp(2rem,4.4vw,3.2rem)] leading-[1.04] font-semibold text-balance">
                Slow soap, on purpose.
              </h2>
              <p className="mt-5 max-w-lg text-[0.98rem] leading-relaxed text-ink-soft">
                Liquid baby wash is mostly water in a plastic bottle. A bar is the opposite: concentrated,
                preserved by its own pH, wrapped in paper and good for roughly sixty baths.
              </p>
            </Reveal>

            <div className="mt-9 flex flex-col gap-3">
              {RITUAL_STEPS.map((step, index) => (
                <Reveal key={step.step} delay={index * 100}>
                  <div className="group flex gap-5 rounded-[24px] border border-line/70 bg-paper p-6 transition-all duration-500 hover:-translate-y-0.5 hover:border-sage/60 hover:shadow-[var(--shadow-soft)]">
                    <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-sage-mist text-sage-deep transition-colors duration-500 group-hover:bg-sage-deep group-hover:text-paper">
                      <step.icon className="h-5 w-5" />
                    </span>
                    <div>
                      <p className="text-[0.62rem] font-semibold tracking-[0.2em] text-ink-mute uppercase">
                        Step {step.step}
                      </p>
                      <h3 className="mt-1 font-display text-[1.25rem] font-semibold text-ink">{step.title}</h3>
                      <p className="mt-2 text-[0.88rem] leading-relaxed text-ink-soft">{step.body}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Ingredients ──────────────────────────────────────── */}
      <section id="ingredients" className="relative overflow-hidden border-y border-line bg-ink py-20 text-paper lg:py-28">
        <div className="pointer-events-none absolute -top-24 left-1/3 h-72 w-72 rounded-full bg-sage/20 blur-3xl" />
        <div className="relative mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-10">
          <div className="grid gap-12 lg:grid-cols-[1fr_1fr] lg:gap-20">
            <Reveal>
              <p className="text-[0.66rem] font-semibold tracking-[0.24em] text-sage uppercase">
                Short lists, real percentages
              </p>
              <h2 className="mt-3 max-w-lg font-display text-[clamp(2rem,4.4vw,3.2rem)] leading-[1.04] font-semibold text-balance">
                We print the percentage, not just the plant.
              </h2>
              <p className="mt-5 max-w-lg text-[0.98rem] leading-relaxed text-paper/70">
                Most baby products list botanicals at the bottom of an INCI list in trace amounts. We publish the
                working concentration on the front of every carton so you can compare properly.
              </p>
              <Link
                href="/story"
                className="group mt-8 inline-flex items-center gap-2 rounded-full border border-paper/30 px-7 py-3.5 text-[0.74rem] font-semibold tracking-[0.16em] uppercase transition hover:border-paper hover:bg-paper hover:text-ink"
              >
                Read our story
                <ArrowRightIcon className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </Link>
            </Reveal>

            <div className="grid gap-3 sm:grid-cols-2">
              {INGREDIENTS.map((ingredient, index) => (
                <Reveal key={ingredient.name} delay={index * 90}>
                  <div className="h-full rounded-[22px] border border-paper/12 bg-paper/6 p-6 transition-colors duration-500 hover:border-sage/50 hover:bg-paper/10">
                    <h3 className="font-display text-[1.15rem] font-semibold">{ingredient.name}</h3>
                    <p className="mt-1 text-[0.72rem] font-semibold tracking-[0.14em] text-honey uppercase">
                      {ingredient.detail}
                    </p>
                    <p className="mt-3 text-[0.85rem] leading-relaxed text-paper/70">{ingredient.note}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Testimonials ─────────────────────────────────────── */}
      <section className="mx-auto max-w-[1400px] px-4 py-20 sm:px-6 lg:px-10 lg:py-28">
        <Reveal className="max-w-2xl">
          <p className="text-[0.66rem] font-semibold tracking-[0.24em] text-sage-deep uppercase">
            From the nursery door
          </p>
          <h2 className="mt-3 font-display text-[clamp(2rem,4.4vw,3.2rem)] leading-[1.04] font-semibold text-balance">
            {stats.reviewCount || 1240} reviews, and we read every one.
          </h2>
        </Reveal>

        <div className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3 lg:gap-5">
          {topReviews.map((review, index) => (
            <Reveal key={`${review.authorName}-${index}`} delay={(index % 3) * 90} className="h-full">
              <figure
                className={`flex h-full flex-col rounded-[24px] border border-line/70 bg-paper p-6 shadow-[var(--shadow-soft)] transition-transform duration-500 hover:-translate-y-1 ${
                  index % 3 === 1 ? "lg:rotate-[-0.6deg]" : index % 3 === 2 ? "lg:rotate-[0.5deg]" : ""
                }`}
              >
                <Stars rating={review.rating} size={14} />
                <blockquote className="mt-4 flex-1 font-display text-[1.02rem] leading-relaxed text-ink-2">
                  “{review.body}”
                </blockquote>
                <figcaption className="mt-5 flex items-center gap-3 border-t border-line pt-4">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-sage-mist font-display text-[0.85rem] font-semibold text-sage-deep">
                    {review.authorName.charAt(0)}
                  </span>
                  <span className="min-w-0">
                    <span className="block truncate text-[0.82rem] font-semibold text-ink">{review.authorName}</span>
                    <span className="block truncate text-[0.72rem] text-ink-mute">
                      {review.authorLocation} · on{" "}
                      <Link href={`/product/${review.productSlug}`} className="underline-sweep text-sage-deep">
                        {review.productName}
                      </Link>
                    </span>
                  </span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ── Closing CTA ──────────────────────────────────────── */}
      <section className="mx-auto max-w-[1400px] px-4 pb-8 sm:px-6 lg:px-10">
        <Reveal>
          <div className="relative overflow-hidden rounded-[32px] border border-line/70 bg-shell-2">
            <div className="grid items-center gap-10 p-8 sm:p-12 lg:grid-cols-[1.1fr_0.9fr] lg:p-16">
              <div>
                <h2 className="max-w-lg font-display text-[clamp(1.9rem,4vw,3rem)] leading-[1.05] font-semibold text-balance">
                  Not sure which bar? Start where most parents do.
                </h2>
                <p className="mt-4 max-w-md text-[0.95rem] leading-relaxed text-ink-soft">
                  The Whole Ritual Gift Set covers the first year — two fragrance-free bars, one for bedtime and one
                  for everyday. It is our most-gifted box and it saves about 22% versus buying separately.
                </p>
                <div className="mt-8 flex flex-wrap gap-3">
                  <Link
                    href="/product/whole-ritual-gift-set"
                    className="group inline-flex items-center gap-2 rounded-full bg-ink px-7 py-4 text-[0.76rem] font-semibold tracking-[0.16em] text-paper uppercase transition hover:bg-sage-deep"
                  >
                    Shop the gift set
                    <ArrowRightIcon className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                  </Link>
                  <Link
                    href="/shop?concerns=Sensitive%20skin"
                    className="inline-flex items-center rounded-full border border-ink/25 px-7 py-4 text-[0.76rem] font-semibold tracking-[0.16em] text-ink uppercase transition hover:border-ink hover:bg-paper"
                  >
                    Filter by skin need
                  </Link>
                </div>
              </div>
              <div className="relative aspect-[4/3] overflow-hidden rounded-[26px] border border-line/70">
                <Image
                  src="https://images.pexels.com/photos/7500299/pexels-photo-7500299.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1100&h=850"
                  alt="The Whole Ritual gift set bars wrapped in linen"
                  fill
                  sizes="(min-width: 1024px) 40vw, 92vw"
                  className="object-cover transition-transform duration-[1200ms] hover:scale-105"
                />
              </div>
            </div>
          </div>
        </Reveal>
      </section>
    </>
  );
}
