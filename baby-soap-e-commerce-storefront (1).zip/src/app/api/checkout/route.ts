import { inArray } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, orders, productImages, products } from "@/db/schema";
import { FREE_SHIPPING_THRESHOLD_CENTS, PROMOS, SHIPPING_METHODS, TAX_RATE } from "@/lib/cart-types";

export const dynamic = "force-dynamic";

type CheckoutLine = { productId: number; variantId: string; quantity: number };

type CheckoutPayload = {
  lines?: unknown;
  email?: unknown;
  name?: unknown;
  phone?: unknown;
  address?: {
    address1?: unknown;
    address2?: unknown;
    city?: unknown;
    state?: unknown;
    postalCode?: unknown;
    country?: unknown;
  };
  shippingMethod?: unknown;
  promoCode?: unknown;
  giftNote?: unknown;
  payment?: { brand?: unknown; last4?: unknown };
};

function str(value: unknown, max = 200) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

export async function POST(request: Request) {
  let payload: CheckoutPayload;
  try {
    payload = (await request.json()) as CheckoutPayload;
  } catch {
    return Response.json({ ok: false, error: "Invalid JSON body" }, { status: 400 });
  }

  const lines = Array.isArray(payload.lines)
    ? (payload.lines as CheckoutLine[]).filter(
        (line) => line && Number.isInteger(Number(line.productId)) && Number(line.quantity) > 0,
      )
    : [];

  if (lines.length === 0) {
    return Response.json({ ok: false, error: "Your bag is empty." }, { status: 400 });
  }

  const email = str(payload.email, 160).toLowerCase();
  const name = str(payload.name, 120);
  const phone = str(payload.phone, 40);
  const address = payload.address ?? {};
  const address1 = str(address.address1, 160);
  const address2 = str(address.address2, 160);
  const city = str(address.city, 80);
  const state = str(address.state, 80);
  const postalCode = str(address.postalCode, 24);
  const country = str(address.country, 80) || "United States";

  const errors: Record<string, string> = {};
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) errors.email = "Enter a valid email address";
  if (name.length < 2) errors.name = "Enter the name for this order";
  if (address1.length < 3) errors.address1 = "Enter a street address";
  if (city.length < 2) errors.city = "Enter a city";
  if (state.length < 2) errors.state = "Enter a state or region";
  if (!/^[A-Za-z0-9][A-Za-z0-9\s-]{2,10}$/.test(postalCode)) errors.postalCode = "Enter a valid postal code";
  if (Object.keys(errors).length > 0) {
    return Response.json({ ok: false, error: "Please check the highlighted fields.", errors }, { status: 422 });
  }

  const methodId = str(payload.shippingMethod, 20);
  const method = SHIPPING_METHODS.find((option) => option.id === methodId) ?? SHIPPING_METHODS[0];
  const promoCode = str(payload.promoCode, 24).toUpperCase();
  const promo = promoCode ? PROMOS[promoCode] : undefined;
  if (promoCode && !promo) {
    return Response.json({ ok: false, error: `Promo code ${promoCode} isn't valid.`, errors: { promoCode: "Invalid code" } }, { status: 422 });
  }

  try {
    const productIds = [...new Set(lines.map((line) => Number(line.productId)))];
    const rows = await db.select().from(products).where(inArray(products.id, productIds));
    const byId = new Map(rows.map((row) => [row.id, row]));

    const firstImages = await db.select().from(productImages).where(inArray(productImages.productId, productIds));
    const imageByProduct = new Map<number, string>();
    for (const row of firstImages) {
      if (!imageByProduct.has(row.productId)) imageByProduct.set(row.productId, row.url);
    }

    let subtotalCents = 0;
    const resolvedItems: {
      productId: number;
      slug: string;
      name: string;
      variantLabel: string;
      imageUrl: string | null;
      unitPriceCents: number;
      quantity: number;
    }[] = [];

    for (const line of lines) {
      const product = byId.get(Number(line.productId));
      if (!product) continue;
      const quantity = Math.min(24, Math.max(1, Number(line.quantity) || 1));
      const variant = product.variants.find((option) => option.id === str(line.variantId, 40)) ?? product.variants[0];
      const unitPriceCents = variant?.priceCents ?? product.priceCents;

      subtotalCents += unitPriceCents * quantity;
      resolvedItems.push({
        productId: product.id,
        slug: product.slug,
        name: product.name,
        variantLabel: variant?.label ?? "Single bar",
        imageUrl: imageByProduct.get(product.id) ?? null,
        unitPriceCents,
        quantity,
      });
    }

    if (resolvedItems.length === 0) {
      return Response.json({ ok: false, error: "We couldn't find those products." }, { status: 400 });
    }

    const discountCents = promo?.kind === "percent" ? Math.round((subtotalCents * promo.value) / 100) : 0;
    const freeStandard = subtotalCents - discountCents >= FREE_SHIPPING_THRESHOLD_CENTS;
    const shippingCents =
      promo?.kind === "shipping" || (method.id === "standard" && freeStandard) ? 0 : method.priceCents;
    const taxCents = Math.round((subtotalCents - discountCents) * TAX_RATE);
    const totalCents = subtotalCents - discountCents + shippingCents + taxCents;

    let orderNumber = "";
    let order: typeof orders.$inferSelect | undefined;

    for (let attempt = 0; attempt < 5; attempt += 1) {
      orderNumber = `KAV-${Math.floor(100000 + Math.random() * 899999)}`;
      const inserted = await db
        .insert(orders)
        .values({
          orderNumber,
          email,
          customerName: name,
          phone: phone || null,
          shippingAddress: { address1, address2, city, state, postalCode, country },
          shippingMethod: method.id,
          promoCode: promo ? promoCode : null,
          subtotalCents,
          discountCents,
          shippingCents,
          taxCents,
          totalCents,
          paymentBrand: str(payload.payment?.brand, 20) || "Visa",
          paymentLast4: str(payload.payment?.last4, 4) || "4242",
          giftNote: str(payload.giftNote, 400) || null,
          status: "paid",
        })
        .returning();
      if (inserted[0]) {
        order = inserted[0];
        break;
      }
    }

    if (!order) {
      return Response.json({ ok: false, error: "Could not create the order. Please try again." }, { status: 500 });
    }

    await db.insert(orderItems).values(resolvedItems.map((item) => ({ ...item, orderId: order!.id })));

    return Response.json({
      ok: true,
      order: {
        id: order.id,
        orderNumber: order.orderNumber,
        email: order.email,
        totalCents: order.totalCents,
        placedAt: order.placedAt,
      },
      totals: { subtotalCents, discountCents, shippingCents, taxCents, totalCents },
    });
  } catch (error) {
    return Response.json({ ok: false, error: (error as Error).message }, { status: 500 });
  }
}
