import { seedDatabase } from "@/db/seed";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const force = new URL(request.url).searchParams.get("force") === "1";
  try {
    const result = await seedDatabase({ force });
    return Response.json({ ok: true, ...result });
  } catch (error) {
    return Response.json({ ok: false, error: (error as Error).message }, { status: 500 });
  }
}

export async function GET() {
  return Response.json({
    ok: true,
    hint: "POST /api/seed to populate demo data, or POST /api/seed?force=1 to reset it.",
  });
}
