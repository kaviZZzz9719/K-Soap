import { getFacets, searchProducts, type ProductFilters } from "@/lib/catalog";

export const dynamic = "force-dynamic";

function listParam(value: string | null) {
  if (!value) return undefined;
  const parts = value
    .split(",")
    .map((part) => part.trim())
    .filter(Boolean);
  return parts.length ? parts : undefined;
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);

  const sortRaw = searchParams.get("sort") ?? "featured";
  const allowedSorts = ["featured", "price-asc", "price-desc", "rating", "newest"] as const;
  const sort = (allowedSorts as readonly string[]).includes(sortRaw)
    ? (sortRaw as ProductFilters["sort"])
    : "featured";

  const page = Math.max(1, Number.parseInt(searchParams.get("page") ?? "1", 10) || 1);
  const limit = Math.min(48, Math.max(4, Number.parseInt(searchParams.get("limit") ?? "24", 10) || 24));

  const filters: ProductFilters = {
    q: searchParams.get("q") ?? undefined,
    collection: listParam(searchParams.get("collection")),
    concerns: listParam(searchParams.get("concerns")),
    scent: listParam(searchParams.get("scent")),
    minPriceCents: searchParams.get("minPrice") ? Number(searchParams.get("minPrice")) : undefined,
    maxPriceCents: searchParams.get("maxPrice") ? Number(searchParams.get("maxPrice")) : undefined,
    sort,
    limit,
    offset: (page - 1) * limit,
  };

  try {
    const [{ products, total }, facets] = await Promise.all([searchProducts(filters), getFacets()]);
    return Response.json({
      ok: true,
      products,
      total,
      page,
      pages: Math.max(1, Math.ceil(total / limit)),
      facets,
    });
  } catch (error) {
    return Response.json(
      { ok: false, error: (error as Error).message, products: [], total: 0, facets: null },
      { status: 500 },
    );
  }
}
