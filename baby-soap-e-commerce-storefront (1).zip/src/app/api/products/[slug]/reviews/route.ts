import { asc, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { products, reviews } from "@/db/schema";
import { getProductReviews } from "@/lib/catalog";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ slug: string }> };

export async function GET(_request: Request, context: RouteContext) {
  const { slug } = await context.params;
  try {
    const rows = await getProductReviews(slug);
    return Response.json({ ok: true, reviews: rows });
  } catch (error) {
    return Response.json({ ok: false, error: (error as Error).message, reviews: [] }, { status: 500 });
  }
}

export async function POST(request: Request, context: RouteContext) {
  const { slug } = await context.params;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid JSON body" }, { status: 400 });
  }

  const payload = body as {
    authorName?: unknown;
    authorLocation?: unknown;
    rating?: unknown;
    title?: unknown;
    body?: unknown;
  };

  const authorName = typeof payload.authorName === "string" ? payload.authorName.trim() : "";
  const authorLocation = typeof payload.authorLocation === "string" ? payload.authorLocation.trim() : "";
  const title = typeof payload.title === "string" ? payload.title.trim() : "";
  const text = typeof payload.body === "string" ? payload.body.trim() : "";
  const rating = Number(payload.rating);

  if (authorName.length < 2) {
    return Response.json({ ok: false, error: "Please tell us your name." }, { status: 400 });
  }
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
    return Response.json({ ok: false, error: "Please choose a rating between 1 and 5." }, { status: 400 });
  }
  if (title.length < 3) {
    return Response.json({ ok: false, error: "Please add a short headline." }, { status: 400 });
  }
  if (text.length < 15) {
    return Response.json(
      { ok: false, error: "Reviews need at least 15 characters so other parents can learn from them." },
      { status: 400 },
    );
  }

  try {
    const [product] = await db.select({ id: products.id }).from(products).where(eq(products.slug, slug)).limit(1);
    if (!product) {
      return Response.json({ ok: false, error: "Product not found" }, { status: 404 });
    }

    const [inserted] = await db
      .insert(reviews)
      .values({
        productId: product.id,
        authorName: authorName.slice(0, 80),
        authorLocation: (authorLocation || "Verified buyer").slice(0, 80),
        rating,
        title: title.slice(0, 120),
        body: text.slice(0, 1200),
        verified: true,
        helpfulCount: 0,
      })
      .returning();

    const aggregate = await db
      .select({
        average: sql<string>`round(avg(${reviews.rating})::numeric, 2)`,
        count: sql<number>`count(*)::int`,
      })
      .from(reviews)
      .where(eq(reviews.productId, product.id));

    await db
      .update(products)
      .set({
        rating: aggregate[0]?.average ?? "0",
        reviewCount: aggregate[0]?.count ?? 0,
      })
      .where(eq(products.id, product.id));

    const all = await db
      .select()
      .from(reviews)
      .where(eq(reviews.productId, product.id))
      .orderBy(desc(reviews.helpfulCount), desc(reviews.createdAt), asc(reviews.id));

    return Response.json({
      ok: true,
      review: inserted,
      reviews: all,
      summary: { rating: aggregate[0]?.average ?? "0", count: aggregate[0]?.count ?? 0 },
    });
  } catch (error) {
    return Response.json({ ok: false, error: (error as Error).message }, { status: 500 });
  }
}
