"use client";

import Image from "next/image";
import { useCart } from "@/lib/cart";
import { CheckIcon, CloseIcon } from "@/components/icons";

export function CartToast() {
  const { toast, dismissToast, openCart } = useCart();
  if (!toast) return null;

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-6 z-[80] flex justify-center px-4 sm:justify-start sm:px-8">
      <div
        key={toast.id}
        className="animate-pop pointer-events-auto flex w-full max-w-sm items-center gap-3 rounded-[20px] border border-line bg-paper/95 p-3 shadow-[var(--shadow-lift)] backdrop-blur"
        role="status"
        aria-live="polite"
      >
        <span className="relative h-12 w-12 shrink-0 overflow-hidden rounded-[12px] bg-shell-2">
          {toast.image ? (
            <Image src={toast.image} alt="" fill sizes="48px" className="object-cover" />
          ) : (
            <span className="grid h-full w-full place-items-center text-sage-deep">
              <CheckIcon className="h-5 w-5" />
            </span>
          )}
        </span>
        <p className="min-w-0 flex-1 text-[0.84rem] leading-snug text-ink-2">{toast.message}</p>
        <button
          type="button"
          onClick={() => {
            dismissToast();
            openCart();
          }}
          className="shrink-0 rounded-full bg-ink px-3.5 py-2 text-[0.64rem] font-semibold tracking-[0.12em] text-paper uppercase transition hover:bg-sage-deep"
        >
          View
        </button>
        <button
          type="button"
          onClick={dismissToast}
          className="shrink-0 rounded-full p-1.5 text-ink-mute transition hover:bg-shell-2"
          aria-label="Dismiss"
        >
          <CloseIcon className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
}
