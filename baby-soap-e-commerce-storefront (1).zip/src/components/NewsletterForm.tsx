"use client";

import { useState } from "react";
import { ArrowRightIcon, CheckIcon } from "@/components/icons";

export function NewsletterForm() {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [message, setMessage] = useState("");

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    if (!email.includes("@")) {
      setState("error");
      setMessage("Please enter a valid email address.");
      return;
    }
    setState("loading");
    try {
      const response = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const payload = (await response.json()) as { ok?: boolean; error?: string };
      if (!response.ok || !payload.ok) throw new Error(payload.error ?? "Something went wrong");
      setState("done");
      setMessage("You’re on the list. Your WELCOME10 code is in your inbox.");
      setEmail("");
    } catch (error) {
      setState("error");
      setMessage((error as Error).message);
    }
  }

  if (state === "done") {
    return (
      <div className="animate-pop flex items-center gap-3 rounded-full border border-sage/50 bg-sage-mist/60 px-5 py-3.5">
        <CheckIcon className="h-4 w-4 shrink-0 text-sage-deep" />
        <p className="text-[0.85rem] text-ink-2">{message}</p>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="w-full">
      <div className="flex items-center gap-2 rounded-full border border-line bg-paper px-5 py-2.5 transition focus-within:border-sage">
        <input
          type="email"
          value={email}
          onChange={(event) => {
            setEmail(event.target.value);
            if (state === "error") setState("idle");
          }}
          placeholder="Your email address"
          aria-label="Email address"
          className="w-full bg-transparent text-[0.88rem] text-ink placeholder:text-ink-mute focus:outline-none"
        />
        <button
          type="submit"
          disabled={state === "loading"}
          className="group shrink-0 rounded-full bg-ink px-4 py-2 text-[0.68rem] font-semibold tracking-[0.14em] text-paper uppercase transition hover:bg-sage-deep disabled:opacity-60"
        >
          <span className="flex items-center gap-1.5">
            {state === "loading" ? "Sending" : "Join"}
            <ArrowRightIcon className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
          </span>
        </button>
      </div>
      {state === "error" ? <p className="mt-2 pl-5 text-[0.78rem] text-clay-deep">{message}</p> : null}
    </form>
  );
}
