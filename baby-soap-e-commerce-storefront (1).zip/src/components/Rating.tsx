import { StarIcon } from "@/components/icons";

export function Stars({
  rating,
  size = 14,
  className = "",
}: {
  rating: number;
  size?: number;
  className?: string;
}) {
  const rounded = Math.max(0, Math.min(5, rating));
  return (
    <span className={`inline-flex items-center gap-[3px] ${className}`} aria-hidden="true">
      {[0, 1, 2, 3, 4].map((index) => {
        const fill = Math.max(0, Math.min(1, rounded - index));
        return (
          <span key={index} className="relative inline-block" style={{ width: size, height: size }}>
            <StarIcon filled={false} className="absolute inset-0 text-ink-mute/50" style={{ width: size, height: size }} />
            <span className="absolute inset-0 overflow-hidden" style={{ width: `${fill * 100}%` }}>
              <StarIcon filled className="text-honey" style={{ width: size, height: size }} />
            </span>
          </span>
        );
      })}
    </span>
  );
}

export function RatingLine({
  rating,
  count,
  size = 13,
  className = "",
}: {
  rating: number | string;
  count?: number;
  size?: number;
  className?: string;
}) {
  const value = typeof rating === "string" ? Number.parseFloat(rating) : rating;
  return (
    <span className={`inline-flex items-center gap-1.5 ${className}`}>
      <Stars rating={Number.isFinite(value) ? value : 0} size={size} />
      <span className="text-[0.72rem] font-medium tracking-[0.06em] text-ink-soft uppercase">
        {Number.isFinite(value) ? value.toFixed(1) : "0.0"}
        {typeof count === "number" ? ` · ${count}` : ""}
      </span>
    </span>
  );
}
