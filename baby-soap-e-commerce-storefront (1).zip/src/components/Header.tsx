"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { BagIcon, ChevronDownIcon, CloseIcon, Logo, MenuIcon, SearchIcon } from "@/components/icons";
import { useCart } from "@/lib/cart";

const ANNOUNCEMENTS = [
  "Complimentary carbon-neutral shipping over $45",
  "Cold-processed in small batches · pH 5.5",
  "New here? WELCOME10 takes 10% off your first order",
  "Paediatric-dermatologist tested, never on animals",
];

export function Header({
  collections,
}: {
  collections: { slug: string; name: string; tagline: string; image: string }[];
}) {
  const { count, openCart, hydrated } = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [collectionsOpen, setCollectionsOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [term, setTerm] = useState("");
  const [announcementIndex, setAnnouncementIndex] = useState(0);
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    // Close every transient panel whenever the route changes.
    /* eslint-disable react-hooks/set-state-in-effect */
    setMenuOpen(false);
    setCollectionsOpen(false);
    setSearchOpen(false);
    /* eslint-enable react-hooks/set-state-in-effect */
  }, [pathname]);

  useEffect(() => {
    const id = window.setInterval(
      () => setAnnouncementIndex((index) => (index + 1) % ANNOUNCEMENTS.length),
      5200,
    );
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  const submitSearch = (event: React.FormEvent) => {
    event.preventDefault();
    const query = term.trim();
    router.push(query ? `/shop?q=${encodeURIComponent(query)}` : "/shop");
    setSearchOpen(false);
    setTerm("");
  };

  const navLinks = [
    { href: "/shop", label: "Shop all" },
    { href: "/story", label: "Our story" },
    { href: "/shop?sort=rating", label: "Best rated" },
  ];

  return (
    <header className="sticky top-0 z-50">
      <div className="relative overflow-hidden bg-ink text-paper">
        <div className="mx-auto flex h-9 max-w-[1400px] items-center justify-center px-4">
          <p
            key={announcementIndex}
            className="animate-fade text-center text-[0.68rem] font-medium tracking-[0.16em] uppercase"
          >
            {ANNOUNCEMENTS[announcementIndex]}
          </p>
        </div>
      </div>

      <div
        className={`border-b transition-all duration-500 ${
          scrolled
            ? "border-line/80 bg-shell/92 py-2 shadow-[0_10px_30px_-24px_rgba(29,42,35,0.6)] backdrop-blur-xl"
            : "border-transparent bg-shell/70 py-3.5 backdrop-blur-md"
        }`}
      >
        <div className="mx-auto flex max-w-[1400px] items-center gap-4 px-4 sm:px-6 lg:px-10">
          <button
            type="button"
            onClick={() => setMenuOpen(true)}
            className="-ml-1 rounded-full p-2 text-ink transition hover:bg-shell-2 lg:hidden"
            aria-label="Open menu"
          >
            <MenuIcon className="h-5 w-5" />
          </button>

          <nav className="hidden items-center gap-1 lg:flex">
            {navLinks.slice(0, 1).map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="rounded-full px-3.5 py-2 text-[0.78rem] font-semibold tracking-[0.08em] text-ink-2 uppercase transition hover:bg-shell-2 hover:text-ink"
              >
                {link.label}
              </Link>
            ))}
            <div
              className="relative"
              onMouseEnter={() => setCollectionsOpen(true)}
              onMouseLeave={() => setCollectionsOpen(false)}
            >
              <button
                type="button"
                onClick={() => setCollectionsOpen((open) => !open)}
                className="flex items-center gap-1.5 rounded-full px-3.5 py-2 text-[0.78rem] font-semibold tracking-[0.08em] text-ink-2 uppercase transition hover:bg-shell-2 hover:text-ink"
              >
                Collections
                <ChevronDownIcon
                  className={`h-3.5 w-3.5 transition-transform duration-300 ${collectionsOpen ? "rotate-180" : ""}`}
                />
              </button>
              {collectionsOpen ? (
                <div className="animate-pop absolute top-full left-0 w-[520px] rounded-[24px] border border-line bg-paper p-3 shadow-[var(--shadow-lift)]">
                  <div className="grid grid-cols-2 gap-2">
                    {collections.map((collection) => (
                      <Link
                        key={collection.slug}
                        href={`/collections/${collection.slug}`}
                        className="group flex items-center gap-3 rounded-[18px] p-2 transition hover:bg-shell-2"
                      >
                        <span className="relative h-14 w-14 shrink-0 overflow-hidden rounded-[14px] bg-shell-2">
                          <Image
                            src={collection.image}
                            alt=""
                            fill
                            sizes="56px"
                            className="object-cover transition-transform duration-700 group-hover:scale-110"
                          />
                        </span>
                        <span className="min-w-0">
                          <span className="block font-display text-[0.95rem] font-semibold text-ink">
                            {collection.name}
                          </span>
                          <span className="block truncate text-[0.72rem] text-ink-soft">{collection.tagline}</span>
                        </span>
                      </Link>
                    ))}
                  </div>
                </div>
              ) : null}
            </div>
            {navLinks.slice(1).map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="rounded-full px-3.5 py-2 text-[0.78rem] font-semibold tracking-[0.08em] text-ink-2 uppercase transition hover:bg-shell-2 hover:text-ink"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <Link href="/" className="mx-auto lg:mx-0" aria-label="kAvI home">
            <span className="text-ink transition-colors hover:text-sage-deep">
              <Logo />
            </span>
          </Link>

          <div className="ml-auto flex items-center gap-1 lg:ml-0">
            <button
              type="button"
              onClick={() => setSearchOpen((open) => !open)}
              className="rounded-full p-2.5 text-ink transition hover:bg-shell-2"
              aria-label="Search products"
            >
              {searchOpen ? <CloseIcon className="h-5 w-5" /> : <SearchIcon className="h-5 w-5" />}
            </button>
            <button
              type="button"
              onClick={openCart}
              className="relative rounded-full p-2.5 text-ink transition hover:bg-shell-2"
              aria-label={`Open bag, ${count} items`}
            >
              <BagIcon className="h-5 w-5" />
              <span
                className={`absolute -top-0.5 -right-0.5 grid h-[18px] min-w-[18px] place-items-center rounded-full bg-clay px-1 text-[0.6rem] font-bold text-paper transition-all duration-300 ${
                  hydrated && count > 0 ? "scale-100 opacity-100" : "scale-50 opacity-0"
                }`}
              >
                {count > 9 ? "9+" : count}
              </span>
            </button>
          </div>
        </div>

        {searchOpen ? (
          <div className="animate-fade mx-auto mt-3 max-w-[1400px] px-4 sm:px-6 lg:px-10">
            <form onSubmit={submitSearch} className="flex items-center gap-3 rounded-full border border-line bg-paper px-5 py-3">
              <SearchIcon className="h-4 w-4 text-ink-mute" />
              <input
                autoFocus
                value={term}
                onChange={(event) => setTerm(event.target.value)}
                placeholder="Search bars, scents, skin concerns…"
                className="w-full bg-transparent text-[0.9rem] text-ink placeholder:text-ink-mute focus:outline-none"
              />
              <button
                type="submit"
                className="shrink-0 rounded-full bg-ink px-4 py-1.5 text-[0.7rem] font-semibold tracking-[0.12em] text-paper uppercase transition hover:bg-sage-deep"
              >
                Search
              </button>
            </form>
          </div>
        ) : null}
      </div>

      {menuOpen ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button
            type="button"
            className="absolute inset-0 bg-ink/45 backdrop-blur-sm"
            onClick={() => setMenuOpen(false)}
            aria-label="Close menu"
          />
          <div className="animate-drawer absolute inset-y-0 left-0 flex w-[86%] max-w-sm flex-col overflow-y-auto bg-shell shadow-[var(--shadow-lift)]">
            <div className="flex items-center justify-between border-b border-line px-5 py-4">
              <span className="text-ink">
                <Logo />
              </span>
              <button
                type="button"
                onClick={() => setMenuOpen(false)}
                className="rounded-full p-2 text-ink transition hover:bg-shell-2"
                aria-label="Close menu"
              >
                <CloseIcon className="h-5 w-5" />
              </button>
            </div>
            <div className="flex flex-col gap-1 px-3 py-4">
              {[...navLinks, { href: "/shop?sort=newest", label: "New in" }].map((link) => (
                <Link
                  key={link.href + link.label}
                  href={link.href}
                  className="rounded-2xl px-4 py-3 font-display text-lg font-semibold text-ink transition hover:bg-shell-2"
                >
                  {link.label}
                </Link>
              ))}
              <p className="px-4 pt-5 pb-2 text-[0.65rem] font-semibold tracking-[0.2em] text-ink-mute uppercase">
                Collections
              </p>
              {collections.map((collection) => (
                <Link
                  key={collection.slug}
                  href={`/collections/${collection.slug}`}
                  className="flex items-center gap-3 rounded-2xl px-4 py-2.5 transition hover:bg-shell-2"
                >
                  <span className="relative h-11 w-11 overflow-hidden rounded-xl bg-shell-2">
                    <Image src={collection.image} alt="" fill sizes="44px" className="object-cover" />
                  </span>
                  <span>
                    <span className="block text-[0.95rem] font-semibold text-ink">{collection.name}</span>
                    <span className="block text-[0.75rem] text-ink-soft">{collection.tagline}</span>
                  </span>
                </Link>
              ))}
            </div>
            <div className="mt-auto border-t border-line p-5">
              <p className="text-[0.78rem] leading-relaxed text-ink-soft">
                Made in Vermont · Ships worldwide · hello@kavi.soap
              </p>
            </div>
          </div>
        </div>
      ) : null}
    </header>
  );
}
