"use client";

import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import {
  ArrowRightIcon,
  BagIcon,
  CheckIcon,
  ChevronLeftIcon,
  LeafIcon,
  ShieldIcon,
  TruckIcon,
} from "@/components/icons";
import { useCart } from "@/lib/cart";
import {
  FREE_SHIPPING_THRESHOLD_CENTS,
  PROMOS,
  SHIPPING_METHODS,
  TAX_RATE,
  formatCents,
  type ShippingMethod,
} from "@/lib/cart-types";

const STORAGE_KEY = "kavi.checkout.v1";
const STEPS = ["Details", "Delivery", "Payment"] as const;

type FormState = {
  email: string;
  name: string;
  phone: string;
  address1: string;
  address2: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  shippingMethod: ShippingMethod;
  giftNote: string;
  cardName: string;
  cardNumber: string;
  cardExpiry: string;
  cardCvc: string;
};

const EMPTY_FORM: FormState = {
  email: "",
  name: "",
  phone: "",
  address1: "",
  address2: "",
  city: "",
  state: "",
  postalCode: "",
  country: "United States",
  shippingMethod: "standard",
  giftNote: "",
  cardName: "",
  cardNumber: "",
  cardExpiry: "",
  cardCvc: "",
};

function detectBrand(number: string) {
  const digits = number.replace(/\D/g, "");
  if (/^4/.test(digits)) return "Visa";
  if (/^(5[1-5]|2[2-7])/.test(digits)) return "Mastercard";
  if (/^3[47]/.test(digits)) return "American Express";
  if (/^6(?:011|5)/.test(digits)) return "Discover";
  return "Card";
}

export function CheckoutFlow() {
  const router = useRouter();
  const { lines, subtotalCents, count, clearCart, hydrated } = useCart();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [promoInput, setPromoInput] = useState("");
  const [promoCode, setPromoCode] = useState<string | null>(null);
  const [promoError, setPromoError] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setForm({ ...EMPTY_FORM, ...(JSON.parse(raw) as Partial<FormState>) });
    } catch {
      // Ignore malformed storage.
    }
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(form));
    } catch {
      // Ignore.
    }
  }, [form, hydrated]);

  const set = (key: keyof FormState) => (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const value = event.target.value;
    setForm((current) => ({ ...current, [key]: value }));
    setErrors((current) => {
      if (!current[key]) return current;
      const next = { ...current };
      delete next[key];
      return next;
    });
  };

  const promo = promoCode ? PROMOS[promoCode] : undefined;
  const discountCents = promo?.kind === "percent" ? Math.round((subtotalCents * promo.value) / 100) : 0;
  const method = SHIPPING_METHODS.find((option) => option.id === form.shippingMethod) ?? SHIPPING_METHODS[0];
  const shippingCents =
    promo?.kind === "shipping" || (method.id === "standard" && subtotalCents - discountCents >= FREE_SHIPPING_THRESHOLD_CENTS)
      ? 0
      : method.priceCents;
  const taxCents = Math.round((subtotalCents - discountCents) * TAX_RATE);
  const totalCents = subtotalCents - discountCents + shippingCents + taxCents;

  const remainingForFreeShipping = Math.max(0, FREE_SHIPPING_THRESHOLD_CENTS - (subtotalCents - discountCents));

  const applyPromo = () => {
    const code = promoInput.trim().toUpperCase();
    if (!code) return;
    if (PROMOS[code]) {
      setPromoCode(code);
      setPromoError("");
      setPromoInput("");
    } else {
      setPromoCode(null);
      setPromoError(`“${code}” isn’t a code we recognise. Try WELCOME10.`);
    }
  };

  const validate = (targetStep: number) => {
    const next: Record<string, string> = {};
    if (targetStep >= 1) {
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email.trim())) next.email = "Enter a valid email address";
      if (form.name.trim().length < 2) next.name = "Enter a full name";
      if (form.address1.trim().length < 3) next.address1 = "Enter a street address";
      if (form.city.trim().length < 2) next.city = "Enter a city";
      if (form.state.trim().length < 2) next.state = "Required";
      if (!/^[A-Za-z0-9][A-Za-z0-9\s-]{2,10}$/.test(form.postalCode.trim())) next.postalCode = "Enter a postal code";
    }
    if (targetStep >= 2) {
      const digits = form.cardNumber.replace(/\D/g, "");
      if (form.cardName.trim().length < 2) next.cardName = "Enter the name on the card";
      if (digits.length < 15) next.cardNumber = "Enter a valid card number";
      if (!/^(0[1-9]|1[0-2])\s?\/\s?\d{2}$/.test(form.cardExpiry.trim())) next.cardExpiry = "MM/YY";
      if (!/^\d{3,4}$/.test(form.cardCvc.trim())) next.cardCvc = "3–4 digits";
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const goNext = () => {
    if (validate(step)) {
      setStep((current) => Math.min(STEPS.length - 1, current + 1));
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const goBack = () => {
    setStep((current) => Math.max(0, current - 1));
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const placeOrder = async () => {
    if (!validate(2)) {
      setStep(2);
      return;
    }
    setSubmitting(true);
    setSubmitError("");
    try {
      const digits = form.cardNumber.replace(/\D/g, "");
      const response = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          lines: lines.map((line) => ({
            productId: line.productId,
            variantId: line.variantId,
            quantity: line.quantity,
          })),
          email: form.email.trim(),
          name: form.name.trim(),
          phone: form.phone.trim(),
          address: {
            address1: form.address1.trim(),
            address2: form.address2.trim(),
            city: form.city.trim(),
            state: form.state.trim(),
            postalCode: form.postalCode.trim(),
            country: form.country,
          },
          shippingMethod: form.shippingMethod,
          promoCode: promoCode ?? "",
          giftNote: form.giftNote.trim(),
          payment: { brand: detectBrand(digits), last4: digits.slice(-4) },
        }),
      });
      const payload = (await response.json()) as {
        ok: boolean;
        error?: string;
        errors?: Record<string, string>;
        order?: { orderNumber: string };
      };
      if (!response.ok || !payload.ok || !payload.order) {
        throw new Error(payload.error ?? "We couldn’t place that order.");
      }
      clearCart();
      try {
        window.localStorage.removeItem(STORAGE_KEY);
      } catch {
        // Ignore.
      }
      router.push(`/order/${payload.order.orderNumber}`);
    } catch (error) {
      setSubmitting(false);
      setSubmitError((error as Error).message);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const fieldClass = (key: keyof FormState) =>
    `w-full rounded-[14px] border bg-paper px-4 py-3.5 text-[0.92rem] text-ink placeholder:text-ink-mute transition focus:outline-none ${
      errors[key] ? "border-clay focus:border-clay" : "border-line focus:border-sage"
    }`;

  const summary = (
      <div className="rounded-[26px] border border-line bg-paper p-6 shadow-[var(--shadow-soft)]">
        <h2 className="font-display text-[1.3rem] font-semibold text-ink">
          Order summary{count > 0 ? ` · ${count}` : ""}
        </h2>
        <ul className="mt-5 flex flex-col gap-4">
          {lines.map((line) => (
            <li key={line.key} className="flex gap-3.5">
              <span className="relative h-[68px] w-[58px] shrink-0 overflow-hidden rounded-[12px] bg-shell-2">
                {line.image ? (
                  <Image src={line.image} alt={line.name} fill sizes="58px" className="object-cover" />
                ) : null}
                <span className="absolute -top-1.5 -right-1.5 grid h-5 w-5 place-items-center rounded-full bg-ink text-[0.62rem] font-bold text-paper">
                  {line.quantity}
                </span>
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[0.9rem] font-semibold text-ink">{line.name}</span>
                <span className="block truncate text-[0.76rem] text-ink-soft">
                  {line.variantLabel} · {line.variantDetail}
                </span>
              </span>
              <span className="shrink-0 text-[0.9rem] font-semibold text-ink tabular-nums">
                {formatCents(line.unitPriceCents * line.quantity)}
              </span>
            </li>
          ))}
        </ul>

        <div className="mt-6 border-t border-line pt-5">
          <div className="flex gap-2">
            <input
              value={promoInput}
              onChange={(event) => {
                setPromoInput(event.target.value.toUpperCase());
                setPromoError("");
              }}
              onKeyDown={(event) => {
                if (event.key === "Enter") {
                  event.preventDefault();
                  applyPromo();
                }
              }}
              placeholder="Promo code"
              aria-label="Promo code"
              className="w-full rounded-full border border-line bg-shell px-4 py-2.5 text-[0.84rem] uppercase tracking-[0.06em] text-ink placeholder:normal-case placeholder:tracking-normal placeholder:text-ink-mute focus:border-sage focus:outline-none"
            />
            <button
              type="button"
              onClick={applyPromo}
              className="shrink-0 rounded-full border border-ink/25 px-4 py-2.5 text-[0.7rem] font-semibold tracking-[0.12em] text-ink uppercase transition hover:border-ink hover:bg-shell-2"
            >
              Apply
            </button>
          </div>
          {promo ? (
            <p className="mt-2 flex items-center gap-1.5 text-[0.78rem] text-sage-deep">
              <CheckIcon className="h-3.5 w-3.5" />
              {promoCode} applied · {promo.label}
            </p>
          ) : null}
          {promoError ? <p className="mt-2 text-[0.78rem] text-clay-deep">{promoError}</p> : null}
        </div>

        <dl className="mt-5 flex flex-col gap-2 border-t border-line pt-5 text-[0.88rem]">
          <Row label="Subtotal" value={formatCents(subtotalCents)} />
          {discountCents > 0 ? <Row label={`Discount (${promoCode})`} value={`−${formatCents(discountCents)}`} accent /> : null}
          <Row label={`Shipping · ${method.label}`} value={shippingCents === 0 ? "Free" : formatCents(shippingCents)} />
          <Row label="Estimated tax" value={formatCents(taxCents)} />
          <div className="mt-2 flex items-center justify-between border-t border-line pt-4">
            <dt className="font-display text-[1.05rem] font-semibold text-ink">Total</dt>
            <dd className="font-display text-[1.5rem] font-semibold text-ink">{formatCents(totalCents)}</dd>
          </div>
        </dl>

        {remainingForFreeShipping > 0 && method.id === "standard" ? (
          <p className="mt-4 flex items-start gap-2 rounded-[14px] bg-shell-2 px-4 py-3 text-[0.78rem] text-ink-2">
            <TruckIcon className="mt-0.5 h-4 w-4 shrink-0 text-sage-deep" />
            Add {formatCents(remainingForFreeShipping)} for free standard shipping.
          </p>
        ) : null}

        <div className="mt-5 flex flex-col gap-2 text-[0.76rem] text-ink-mute">
          <span className="flex items-center gap-2">
            <ShieldIcon className="h-4 w-4 text-sage-deep" />
            Encrypted checkout · demo payments, no real charge
          </span>
          <span className="flex items-center gap-2">
            <LeafIcon className="h-4 w-4 text-sage-deep" />
            Paper-only packaging, carbon-neutral delivery
          </span>
        </div>
      </div>
  );

  if (!hydrated) {
    return (
      <div className="mx-auto max-w-[1400px] px-4 py-12 sm:px-6 lg:px-10 lg:py-16">
        <div className="skeleton h-3 w-40 rounded-full" />
        <div className="skeleton mt-4 h-12 w-80 max-w-full rounded-full" />
        <div className="mt-10 grid gap-8 lg:grid-cols-[1.15fr_0.85fr] lg:gap-12">
          <div className="skeleton h-[520px] rounded-[26px]" />
          <div className="skeleton h-[420px] rounded-[26px]" />
        </div>
      </div>
    );
  }

  if (lines.length === 0) {
    return (
      <div className="mx-auto flex min-h-[60vh] max-w-lg flex-col items-center justify-center gap-5 px-4 py-24 text-center">
        <span className="grid h-20 w-20 place-items-center rounded-full bg-shell-2 text-ink-mute">
          <BagIcon className="h-8 w-8" />
        </span>
        <h1 className="font-display text-[2rem] font-semibold text-ink">Your bag is empty</h1>
        <p className="text-[0.95rem] text-ink-soft">
          Add a bar or two and checkout will open up. Most families start with the fragrance-free First Light.
        </p>
        <Link
          href="/shop"
          className="group inline-flex items-center gap-2 rounded-full bg-ink px-7 py-4 text-[0.76rem] font-semibold tracking-[0.16em] text-paper uppercase transition hover:bg-sage-deep"
        >
          Shop the range
          <ArrowRightIcon className="h-4 w-4 transition-transform group-hover:translate-x-1" />
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-[1400px] px-4 py-12 sm:px-6 lg:px-10 lg:py-16">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-[0.66rem] font-semibold tracking-[0.24em] text-sage-deep uppercase">Secure checkout</p>
          <h1 className="mt-2 font-display text-[clamp(2rem,4.4vw,3rem)] leading-tight font-semibold">
            Almost at bath time.
          </h1>
        </div>
        <Link href="/shop" className="inline-flex items-center gap-2 text-[0.76rem] font-semibold tracking-[0.12em] text-ink-soft uppercase transition hover:text-ink">
          <ChevronLeftIcon className="h-4 w-4" />
          Continue shopping
        </Link>
      </div>

      {submitError ? (
        <p className="animate-pop mt-6 rounded-[16px] border border-clay/40 bg-clay/10 px-5 py-3.5 text-[0.88rem] text-clay-deep">
          {submitError}
        </p>
      ) : null}

      <ol className="mt-8 flex flex-wrap items-center gap-3">
        {STEPS.map((label, index) => (
          <li key={label} className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => (index < step ? setStep(index) : undefined)}
              disabled={index > step}
              className={`flex items-center gap-2.5 rounded-full px-4 py-2 text-[0.76rem] font-semibold tracking-[0.1em] uppercase transition ${
                index === step
                  ? "bg-ink text-paper"
                  : index < step
                    ? "bg-sage-mist text-sage-deep hover:bg-sage/30"
                    : "bg-shell-2 text-ink-mute"
              }`}
            >
              <span className="grid h-5 w-5 place-items-center rounded-full border border-current text-[0.66rem]">
                {index < step ? <CheckIcon className="h-3 w-3" strokeWidth={3} /> : index + 1}
              </span>
              {label}
            </button>
            {index < STEPS.length - 1 ? <span className="hidden h-px w-8 bg-line sm:block" /> : null}
          </li>
        ))}
      </ol>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1.15fr_0.85fr] lg:gap-12">
        <div className="rounded-[26px] border border-line bg-paper p-6 sm:p-8">
          {step === 0 ? (
            <div className="animate-fade">
              <h2 className="font-display text-[1.5rem] font-semibold text-ink">Contact & delivery address</h2>
              <p className="mt-1.5 text-[0.88rem] text-ink-soft">
                We’ll send tracking and bath-time tips to this address. No account required.
              </p>

              <div className="mt-7 flex flex-col gap-5">
                <Field label="Email" error={errors.email} required>
                  <input
                    type="email"
                    autoComplete="email"
                    value={form.email}
                    onChange={set("email")}
                    placeholder="you@example.com"
                    className={fieldClass("email")}
                  />
                </Field>
                <div className="grid gap-5 sm:grid-cols-2">
                  <Field label="Full name" error={errors.name} required>
                    <input
                      autoComplete="name"
                      value={form.name}
                      onChange={set("name")}
                      placeholder="Amara Whitfield"
                      className={fieldClass("name")}
                    />
                  </Field>
                  <Field label="Phone (optional)">
                    <input
                      autoComplete="tel"
                      value={form.phone}
                      onChange={set("phone")}
                      placeholder="+1 (555) 000-0000"
                      className={fieldClass("phone")}
                    />
                  </Field>
                </div>
                <Field label="Street address" error={errors.address1} required>
                  <input
                    autoComplete="address-line1"
                    value={form.address1}
                    onChange={set("address1")}
                    placeholder="1180 Fillmore Street"
                    className={fieldClass("address1")}
                  />
                </Field>
                <Field label="Apartment, suite (optional)">
                  <input
                    autoComplete="address-line2"
                    value={form.address2}
                    onChange={set("address2")}
                    placeholder="Apt 4B"
                    className={fieldClass("address2")}
                  />
                </Field>
                <div className="grid gap-5 sm:grid-cols-[1.4fr_1fr_1fr]">
                  <Field label="City" error={errors.city} required>
                    <input
                      autoComplete="address-level2"
                      value={form.city}
                      onChange={set("city")}
                      placeholder="San Francisco"
                      className={fieldClass("city")}
                    />
                  </Field>
                  <Field label="State" error={errors.state} required>
                    <input
                      autoComplete="address-level1"
                      value={form.state}
                      onChange={set("state")}
                      placeholder="CA"
                      className={fieldClass("state")}
                    />
                  </Field>
                  <Field label="Postal code" error={errors.postalCode} required>
                    <input
                      autoComplete="postal-code"
                      value={form.postalCode}
                      onChange={set("postalCode")}
                      placeholder="94115"
                      className={fieldClass("postalCode")}
                    />
                  </Field>
                </div>
                <Field label="Country">
                  <select value={form.country} onChange={set("country")} className={fieldClass("country")}>
                    {["United States", "Canada", "United Kingdom", "Ireland", "Germany", "France", "Australia"].map(
                      (country) => (
                        <option key={country} value={country}>
                          {country}
                        </option>
                      ),
                    )}
                  </select>
                </Field>
              </div>
            </div>
          ) : null}

          {step === 1 ? (
            <div className="animate-fade">
              <h2 className="font-display text-[1.5rem] font-semibold text-ink">Delivery speed</h2>
              <p className="mt-1.5 text-[0.88rem] text-ink-soft">
                Everything ships from Brattleboro, Vermont within one business day, wrapped in paper only.
              </p>

              <div className="mt-7 flex flex-col gap-3">
                {SHIPPING_METHODS.map((option) => {
                  const selected = form.shippingMethod === option.id;
                  const free = option.id === "standard" && subtotalCents - discountCents >= FREE_SHIPPING_THRESHOLD_CENTS;
                  return (
                    <label
                      key={option.id}
                      className={`flex cursor-pointer items-center gap-4 rounded-[18px] border px-5 py-4 transition-all duration-300 ${
                        selected ? "border-ink bg-shell/70 shadow-[var(--shadow-soft)]" : "border-line hover:border-ink/40"
                      }`}
                    >
                      <input
                        type="radio"
                        name="shippingMethod"
                        className="sr-only"
                        checked={selected}
                        onChange={() => setForm((current) => ({ ...current, shippingMethod: option.id }))}
                      />
                      <span
                        className={`grid h-5 w-5 shrink-0 place-items-center rounded-full border transition ${
                          selected ? "border-ink bg-ink text-paper" : "border-line"
                        }`}
                      >
                        {selected ? <CheckIcon className="h-3 w-3" strokeWidth={3} /> : null}
                      </span>
                      <span className="flex-1">
                        <span className="block text-[0.95rem] font-semibold text-ink">{option.label}</span>
                        <span className="block text-[0.8rem] text-ink-soft">{option.detail}</span>
                      </span>
                      <span className="shrink-0 font-display text-[1.05rem] font-semibold text-ink">
                        {option.priceCents === 0 || free ? "Free" : formatCents(option.priceCents)}
                      </span>
                    </label>
                  );
                })}
              </div>

              <div className="mt-8">
                <Field label="Gift note (optional)">
                  <textarea
                    rows={3}
                    value={form.giftNote}
                    onChange={set("giftNote")}
                    placeholder="For Margot — welcome to the world."
                    className={`${fieldClass("giftNote")} resize-y`}
                  />
                </Field>
                <p className="mt-2 text-[0.78rem] text-ink-mute">
                  Hand-written on seed paper and tucked into the box. Prices are hidden on gift orders.
                </p>
              </div>
            </div>
          ) : null}

          {step === 2 ? (
            <div className="animate-fade">
              <h2 className="font-display text-[1.5rem] font-semibold text-ink">Payment</h2>
              <p className="mt-1.5 text-[0.88rem] text-ink-soft">
                This is a demonstration storefront — use any well-formed card number, or drop in the test card.
              </p>

              <button
                type="button"
                onClick={() =>
                  setForm((current) => ({
                    ...current,
                    cardName: current.cardName || current.name || "Amara Whitfield",
                    cardNumber: "4242 4242 4242 4242",
                    cardExpiry: "04/29",
                    cardCvc: "242",
                  }))
                }
                className="mt-5 inline-flex items-center gap-2 rounded-full border border-sage/60 bg-sage-mist/50 px-4 py-2 text-[0.76rem] font-semibold text-sage-deep transition hover:bg-sage-mist"
              >
                <SparkleDot />
                Fill test card
              </button>

              <div className="mt-6 flex flex-col gap-5">
                <Field label="Name on card" error={errors.cardName} required>
                  <input
                    autoComplete="cc-name"
                    value={form.cardName}
                    onChange={set("cardName")}
                    placeholder="Amara Whitfield"
                    className={fieldClass("cardName")}
                  />
                </Field>
                <Field label={`Card number · ${detectBrand(form.cardNumber)}`} error={errors.cardNumber} required>
                  <input
                    inputMode="numeric"
                    autoComplete="cc-number"
                    value={form.cardNumber}
                    onChange={(event) => {
                      const digits = event.target.value.replace(/\D/g, "").slice(0, 19);
                      const grouped = digits.replace(/(.{4})/g, "$1 ").trim();
                      setForm((current) => ({ ...current, cardNumber: grouped }));
                      setErrors((current) => {
                        if (!current.cardNumber) return current;
                        const next = { ...current };
                        delete next.cardNumber;
                        return next;
                      });
                    }}
                    placeholder="4242 4242 4242 4242"
                    className={`${fieldClass("cardNumber")} tracking-[0.08em] tabular-nums`}
                  />
                </Field>
                <div className="grid gap-5 sm:grid-cols-2">
                  <Field label="Expiry" error={errors.cardExpiry} required>
                    <input
                      inputMode="numeric"
                      autoComplete="cc-exp"
                      value={form.cardExpiry}
                      onChange={(event) => {
                        const digits = event.target.value.replace(/\D/g, "").slice(0, 4);
                        const formatted = digits.length > 2 ? `${digits.slice(0, 2)}/${digits.slice(2)}` : digits;
                        setForm((current) => ({ ...current, cardExpiry: formatted }));
                      }}
                      placeholder="04/29"
                      className={`${fieldClass("cardExpiry")} tabular-nums`}
                    />
                  </Field>
                  <Field label="CVC" error={errors.cardCvc} required>
                    <input
                      inputMode="numeric"
                      autoComplete="cc-csc"
                      value={form.cardCvc}
                      onChange={(event) =>
                        setForm((current) => ({
                          ...current,
                          cardCvc: event.target.value.replace(/\D/g, "").slice(0, 4),
                        }))
                      }
                      placeholder="242"
                      className={`${fieldClass("cardCvc")} tabular-nums`}
                    />
                  </Field>
                </div>
              </div>

              <div className="mt-8 rounded-[18px] border border-line bg-shell/70 p-5">
                <h3 className="text-[0.7rem] font-semibold tracking-[0.18em] text-ink-mute uppercase">Review</h3>
                <div className="mt-3 grid gap-4 text-[0.86rem] text-ink-2 sm:grid-cols-2">
                  <div>
                    <p className="font-semibold text-ink">Ship to</p>
                    <p className="mt-1 leading-relaxed">
                      {form.name || "—"}
                      <br />
                      {form.address1 || "—"}
                      {form.address2 ? `, ${form.address2}` : ""}
                      <br />
                      {form.city || "—"} {form.state} {form.postalCode}
                      <br />
                      {form.country}
                    </p>
                  </div>
                  <div>
                    <p className="font-semibold text-ink">Delivery</p>
                    <p className="mt-1 leading-relaxed">
                      {method.label} · {method.detail}
                      <br />
                      {form.email || "—"}
                      <br />
                      {detectBrand(form.cardNumber)} ending {form.cardNumber.replace(/\D/g, "").slice(-4) || "••••"}
                    </p>
                  </div>
                </div>
                {form.giftNote ? (
                  <p className="mt-4 border-t border-line pt-4 text-[0.84rem] italic text-ink-soft">
                    “{form.giftNote}”
                  </p>
                ) : null}
              </div>
            </div>
          ) : null}

          <div className="mt-9 flex flex-wrap items-center justify-between gap-3 border-t border-line pt-6">
            {step > 0 ? (
              <button
                type="button"
                onClick={goBack}
                className="inline-flex items-center gap-2 rounded-full border border-line px-5 py-3 text-[0.74rem] font-semibold tracking-[0.12em] text-ink uppercase transition hover:border-ink"
              >
                <ChevronLeftIcon className="h-4 w-4" />
                Back
              </button>
            ) : (
              <span className="text-[0.78rem] text-ink-mute">Step 1 of 3</span>
            )}

            {step < STEPS.length - 1 ? (
              <button
                type="button"
                onClick={goNext}
                className="group inline-flex items-center gap-2 rounded-full bg-ink px-7 py-4 text-[0.76rem] font-semibold tracking-[0.16em] text-paper uppercase transition hover:bg-sage-deep"
              >
                Continue to {STEPS[step + 1]}
                <ArrowRightIcon className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </button>
            ) : (
              <button
                type="button"
                onClick={placeOrder}
                disabled={submitting}
                className="group inline-flex items-center gap-2 rounded-full bg-ink px-8 py-4 text-[0.76rem] font-semibold tracking-[0.16em] text-paper uppercase transition hover:bg-sage-deep disabled:opacity-60"
              >
                {submitting ? "Placing order…" : `Place order · ${formatCents(totalCents)}`}
                {!submitting ? <ArrowRightIcon className="h-4 w-4 transition-transform group-hover:translate-x-1" /> : null}
              </button>
            )}
          </div>
        </div>

        <div className="lg:sticky lg:top-32 lg:self-start">{summary}</div>
      </div>
    </div>
  );
}

function Row({ label, value, accent = false }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <dt className="text-ink-soft">{label}</dt>
      <dd className={accent ? "font-semibold text-sage-deep" : "font-medium text-ink tabular-nums"}>{value}</dd>
    </div>
  );
}

function Field({
  label,
  error,
  required,
  children,
}: {
  label: string;
  error?: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 flex items-center gap-1 text-[0.72rem] font-semibold tracking-[0.14em] text-ink-mute uppercase">
        {label}
        {required ? <span className="text-clay">*</span> : null}
      </span>
      {children}
      {error ? <span className="mt-1.5 block text-[0.76rem] text-clay-deep">{error}</span> : null}
    </label>
  );
}

function SparkleDot() {
  return (
    <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={1.6}>
      <path d="M12 4.5c.7 3.6 2.4 5.3 6 6-3.6.7-5.3 2.4-6 6-.7-3.6-2.4-5.3-6-6 3.6-.7 5.3-2.4 6-6Z" />
    </svg>
  );
}
