import Link from "next/link";
import { NewsletterForm } from "@/components/NewsletterForm";
import { InstagramIcon, LeafIcon, Logo, PinterestIcon, ShieldIcon, TruckIcon } from "@/components/icons";

const SHOP_LINKS = [
  { href: "/shop", label: "All bars & sets" },
  { href: "/collections/newborn-rituals", label: "Newborn Rituals" },
  { href: "/collections/everyday-bath", label: "Everyday Bath" },
  { href: "/collections/calm-comfort", label: "Calm & Comfort" },
  { href: "/collections/bedtime", label: "Bedtime" },
  { href: "/collections/gift-sets", label: "Gifting & Sets" },
];

const CARE_LINKS = [
  { href: "/story", label: "Our story" },
  { href: "/story#ingredients", label: "Ingredient index" },
  { href: "/shop?sort=rating", label: "Parent reviews" },
  { href: "/story#shipping", label: "Shipping & returns" },
  { href: "/story#faq", label: "Bath FAQ" },
];

export function Footer() {
  return (
    <footer className="relative mt-24 overflow-hidden border-t border-line bg-ink text-paper">
      <div className="pointer-events-none absolute -top-24 -right-24 h-72 w-72 rounded-full bg-sage/15 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-32 -left-16 h-80 w-80 rounded-full bg-clay/15 blur-3xl" />

      <div className="relative mx-auto max-w-[1400px] px-4 py-16 sm:px-6 lg:px-10 lg:py-20">
        <div className="grid gap-12 lg:grid-cols-[1.1fr_1fr] lg:gap-20">
          <div>
            <span className="text-paper">
              <Logo />
            </span>
            <h2 className="mt-6 max-w-md font-display text-[clamp(1.8rem,3.4vw,2.6rem)] leading-[1.08] font-semibold text-balance">
              Letters from the soap shed.
            </h2>
            <p className="mt-4 max-w-md text-[0.92rem] leading-relaxed text-paper/70">
              Batch notes, seasonal releases and honest advice on infant skin — roughly once a month, never more.
              New subscribers get 10% off their first order.
            </p>
            <div className="mt-7 max-w-md [&_input]:text-ink">
              <NewsletterForm />
            </div>
          </div>

          <div className="grid gap-10 sm:grid-cols-3">
            <div>
              <h3 className="text-[0.65rem] font-semibold tracking-[0.22em] text-paper/50 uppercase">Shop</h3>
              <ul className="mt-4 flex flex-col gap-2.5">
                {SHOP_LINKS.map((link) => (
                  <li key={link.href + link.label}>
                    <Link
                      href={link.href}
                      className="underline-sweep text-[0.88rem] text-paper/80 transition hover:text-paper"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-[0.65rem] font-semibold tracking-[0.22em] text-paper/50 uppercase">Care</h3>
              <ul className="mt-4 flex flex-col gap-2.5">
                {CARE_LINKS.map((link) => (
                  <li key={link.href + link.label}>
                    <Link
                      href={link.href}
                      className="underline-sweep text-[0.88rem] text-paper/80 transition hover:text-paper"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-[0.65rem] font-semibold tracking-[0.22em] text-paper/50 uppercase">Studio</h3>
              <address className="mt-4 flex flex-col gap-2.5 text-[0.88rem] not-italic text-paper/80">
                <span>41 Mill Lane</span>
                <span>Brattleboro, Vermont</span>
                <a href="mailto:hello@kavi.soap" className="underline-sweep w-fit transition hover:text-paper">
                  hello@kavi.soap
                </a>
                <a href="tel:+18025550142" className="underline-sweep w-fit transition hover:text-paper">
                  +1 (802) 555-0142
                </a>
              </address>
              <div className="mt-5 flex items-center gap-2">
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noreferrer"
                  aria-label="kAvI on Instagram"
                  className="grid h-9 w-9 place-items-center rounded-full border border-paper/20 text-paper/80 transition hover:border-paper/60 hover:text-paper"
                >
                  <InstagramIcon className="h-4 w-4" />
                </a>
                <a
                  href="https://pinterest.com"
                  target="_blank"
                  rel="noreferrer"
                  aria-label="kAvI on Pinterest"
                  className="grid h-9 w-9 place-items-center rounded-full border border-paper/20 text-paper/80 transition hover:border-paper/60 hover:text-paper"
                >
                  <PinterestIcon className="h-4 w-4" />
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-14 grid gap-4 border-t border-paper/12 pt-8 sm:grid-cols-3">
          {[
            { icon: TruckIcon, title: "Free shipping over $45", body: "Carbon-neutral, plastic-free, 3–5 days." },
            { icon: ShieldIcon, title: "60-day skin promise", body: "If it doesn’t suit your baby, we refund it." },
            { icon: LeafIcon, title: "Made in small batches", body: "Cured six weeks in Brattleboro, Vermont." },
          ].map(({ icon: Icon, title, body }) => (
            <div key={title} className="flex items-start gap-3">
              <Icon className="mt-0.5 h-5 w-5 shrink-0 text-sage" />
              <div>
                <p className="text-[0.86rem] font-semibold text-paper">{title}</p>
                <p className="text-[0.78rem] text-paper/60">{body}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-4 border-t border-paper/12 pt-7 text-[0.74rem] text-paper/55 sm:flex-row">
          <p>© {new Date().getFullYear()} kAvI Soap Co. All rights reserved. A demonstration storefront.</p>
          <p className="flex items-center gap-4">
            <span>Visa</span>
            <span>Mastercard</span>
            <span>Amex</span>
            <span>Apple Pay</span>
            <span>Shop Pay</span>
          </p>
        </div>
      </div>

      <p
        aria-hidden="true"
        className="pointer-events-none relative -mb-6 select-none text-center font-display text-[clamp(4rem,17vw,15rem)] leading-[0.78] font-semibold text-paper/6"
      >
        kAvI
      </p>
    </footer>
  );
}
