"use client";

import Image from "next/image";
import Link from "next/link";
import { ArrowRightIcon, BagIcon, CheckIcon, CloseIcon, LeafIcon, MinusIcon, PlusIcon, TruckIcon } from "@/components/icons";
import { useCart } from "@/lib/cart";
import { FREE_SHIPPING_THRESHOLD_CENTS, formatCents } from "@/lib/cart-types";

export function CartDrawer() {
  const { isOpen, closeCart, lines, count, subtotalCents, savingsCents, updateQuantity, removeLine, hydrated } =
    useCart();

  // `isOpen` can only become true after a client-side interaction, so the drawer never renders on the server.
  if (!isOpen) return null;

  const remaining = Math.max(0, FREE_SHIPPING_THRESHOLD_CENTS - subtotalCents);
  const progress = Math.min(100, (subtotalCents / FREE_SHIPPING_THRESHOLD_CENTS) * 100);

  return (
    <div className="fixed inset-0 z-[70]" role="dialog" aria-modal="true" aria-label="Shopping bag">
      <button
        type="button"
        aria-label="Close bag"
        onClick={closeCart}
        className="animate-fade absolute inset-0 bg-ink/45 backdrop-blur-[3px]"
      />
      <aside className="animate-drawer absolute inset-y-0 right-0 flex w-full max-w-[440px] flex-col bg-shell shadow-[var(--shadow-lift)]">
        <header className="flex items-center justify-between border-b border-line px-6 py-5">
          <div>
            <p className="text-[0.62rem] font-semibold tracking-[0.22em] text-sage-deep uppercase">kAvI</p>
            <h2 className="font-display text-xl font-semibold text-ink">
              Your bag{hydrated && count > 0 ? ` · ${count}` : ""}
            </h2>
          </div>
          <button
            type="button"
            onClick={closeCart}
            className="rounded-full p-2 text-ink transition hover:bg-shell-2"
            aria-label="Close bag"
          >
            <CloseIcon className="h-5 w-5" />
          </button>
        </header>

        {lines.length > 0 ? (
          <div className="border-b border-line bg-paper/70 px-6 py-4">
            {remaining > 0 ? (
              <p className="flex items-center gap-2 text-[0.8rem] text-ink-2">
                <TruckIcon className="h-4 w-4 text-sage-deep" />
                You’re <strong className="font-semibold text-ink">{formatCents(remaining)}</strong> from free shipping
              </p>
            ) : (
              <p className="flex items-center gap-2 text-[0.8rem] font-medium text-sage-deep">
                <CheckIcon className="h-4 w-4" />
                Free carbon-neutral shipping unlocked
              </p>
            )}
            <div className="mt-2.5 h-1.5 overflow-hidden rounded-full bg-shell-3">
              <div
                className="h-full rounded-full bg-gradient-to-r from-sage to-sage-deep transition-[width] duration-700 ease-out"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        ) : null}

        <div className="flex-1 overflow-y-auto px-6 py-5">
          {lines.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center gap-5 text-center">
              <span className="grid h-20 w-20 place-items-center rounded-full bg-shell-2 text-ink-mute">
                <BagIcon className="h-8 w-8" />
              </span>
              <div>
                <h3 className="font-display text-xl font-semibold text-ink">Your bag is empty</h3>
                <p className="mx-auto mt-2 max-w-[16rem] text-[0.85rem] leading-relaxed text-ink-soft">
                  Start with First Light — the fragrance-free bar most families begin with.
                </p>
              </div>
              <div className="flex flex-col gap-2">
                <Link
                  href="/product/first-light-newborn-bar"
                  onClick={closeCart}
                  className="rounded-full bg-ink px-6 py-3 text-[0.72rem] font-semibold tracking-[0.14em] text-paper uppercase transition hover:bg-sage-deep"
                >
                  Shop the bestseller
                </Link>
                <Link
                  href="/shop"
                  onClick={closeCart}
                  className="rounded-full border border-line px-6 py-3 text-[0.72rem] font-semibold tracking-[0.14em] text-ink uppercase transition hover:border-ink"
                >
                  Browse all bars
                </Link>
              </div>
            </div>
          ) : (
            <ul className="flex flex-col gap-5">
              {lines.map((line) => (
                <li key={line.key} className="flex gap-4">
                  <Link
                    href={`/product/${line.slug}`}
                    onClick={closeCart}
                    className="relative h-24 w-20 shrink-0 overflow-hidden rounded-[14px] bg-shell-2"
                  >
                    {line.image ? (
                      <Image src={line.image} alt={line.name} fill sizes="80px" className="object-cover" />
                    ) : null}
                  </Link>
                  <div className="flex min-w-0 flex-1 flex-col">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <Link
                          href={`/product/${line.slug}`}
                          onClick={closeCart}
                          className="block truncate font-display text-[0.98rem] font-semibold text-ink hover:text-sage-deep"
                        >
                          {line.name}
                        </Link>
                        <p className="mt-0.5 text-[0.75rem] text-ink-soft">
                          {line.variantLabel}
                          {line.variantDetail ? ` · ${line.variantDetail}` : ""}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeLine(line.key)}
                        className="shrink-0 rounded-full p-1.5 text-ink-mute transition hover:bg-shell-2 hover:text-clay"
                        aria-label={`Remove ${line.name}`}
                      >
                        <CloseIcon className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <div className="mt-auto flex items-center justify-between pt-3">
                      <div className="flex items-center rounded-full border border-line bg-paper">
                        <button
                          type="button"
                          onClick={() => updateQuantity(line.key, line.quantity - 1)}
                          className="grid h-8 w-8 place-items-center rounded-full text-ink transition hover:bg-shell-2"
                          aria-label="Decrease quantity"
                        >
                          <MinusIcon className="h-3.5 w-3.5" />
                        </button>
                        <span className="w-6 text-center text-[0.85rem] font-semibold tabular-nums">{line.quantity}</span>
                        <button
                          type="button"
                          onClick={() => updateQuantity(line.key, line.quantity + 1)}
                          disabled={line.quantity >= line.maxQuantity}
                          className="grid h-8 w-8 place-items-center rounded-full text-ink transition hover:bg-shell-2 disabled:opacity-35"
                          aria-label="Increase quantity"
                        >
                          <PlusIcon className="h-3.5 w-3.5" />
                        </button>
                      </div>
                      <div className="text-right">
                        {line.compareAtCents && line.compareAtCents > line.unitPriceCents ? (
                          <span className="mr-1.5 text-[0.72rem] text-ink-mute line-through">
                            {formatCents(line.compareAtCents * line.quantity)}
                          </span>
                        ) : null}
                        <span className="font-display text-[0.98rem] font-semibold text-ink">
                          {formatCents(line.unitPriceCents * line.quantity)}
                        </span>
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {lines.length > 0 ? (
          <footer className="border-t border-line bg-paper px-6 py-5">
            <dl className="flex flex-col gap-1.5 text-[0.85rem]">
              <div className="flex items-center justify-between">
                <dt className="text-ink-soft">Subtotal</dt>
                <dd className="font-display text-lg font-semibold text-ink">{formatCents(subtotalCents)}</dd>
              </div>
              {savingsCents > 0 ? (
                <div className="flex items-center justify-between text-sage-deep">
                  <dt>You save</dt>
                  <dd className="font-semibold">−{formatCents(savingsCents)}</dd>
                </div>
              ) : null}
              <div className="flex items-center justify-between text-[0.78rem] text-ink-mute">
                <dt>Shipping & tax</dt>
                <dd>Calculated at checkout</dd>
              </div>
            </dl>
            <Link
              href="/checkout"
              onClick={closeCart}
              className="group mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-ink px-6 py-4 text-[0.76rem] font-semibold tracking-[0.16em] text-paper uppercase transition hover:bg-sage-deep"
            >
              Checkout
              <ArrowRightIcon className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
            </Link>
            <button
              type="button"
              onClick={closeCart}
              className="mt-2 w-full rounded-full px-6 py-3 text-[0.74rem] font-semibold tracking-[0.12em] text-ink-soft uppercase transition hover:text-ink"
            >
              Continue shopping
            </button>
            <p className="mt-3 flex items-center justify-center gap-1.5 text-[0.7rem] text-ink-mute">
              <LeafIcon className="h-3.5 w-3.5 text-sage-deep" />
              Plastic-free packaging · 60-day gentle-skin guarantee
            </p>
          </footer>
        ) : null}
      </aside>
    </div>
  );
}
