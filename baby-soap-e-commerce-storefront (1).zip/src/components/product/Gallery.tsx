"use client";

import Image from "next/image";
import { useEffect, useState } from "react";
import { ChevronLeftIcon, ChevronRightIcon, CloseIcon } from "@/components/icons";

export function Gallery({
  images,
  name,
  badge,
}: {
  images: { url: string; alt: string }[];
  name: string;
  badge?: string | null;
}) {
  const [active, setActive] = useState(0);
  const [zoomed, setZoomed] = useState(false);
  const [lightbox, setLightbox] = useState(false);
  const safeImages = images.length ? images : [{ url: "", alt: name }];
  const current = safeImages[Math.min(active, safeImages.length - 1)];

  useEffect(() => {
    if (!lightbox) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setLightbox(false);
      if (event.key === "ArrowRight") setActive((index) => (index + 1) % safeImages.length);
      if (event.key === "ArrowLeft") setActive((index) => (index - 1 + safeImages.length) % safeImages.length);
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [lightbox, safeImages.length]);

  const step = (direction: number) => {
    setZoomed(false);
    setActive((index) => (index + direction + safeImages.length) % safeImages.length);
  };

  return (
    <div className="flex flex-col-reverse gap-4 lg:flex-row">
      <div className="flex gap-3 overflow-x-auto no-scrollbar lg:w-[86px] lg:flex-col lg:overflow-visible">
        {safeImages.map((image, index) => (
          <button
            key={`${image.url}-${index}`}
            type="button"
            onClick={() => {
              setActive(index);
              setZoomed(false);
            }}
            aria-label={`View image ${index + 1} of ${safeImages.length}`}
            aria-current={index === active}
            className={`relative h-[74px] w-[74px] shrink-0 overflow-hidden rounded-[16px] border transition-all duration-300 lg:h-[86px] lg:w-[86px] ${
              index === active
                ? "border-ink shadow-[var(--shadow-soft)]"
                : "border-line/70 opacity-70 hover:opacity-100"
            }`}
          >
            {image.url ? (
              <Image src={image.url} alt="" fill sizes="86px" className="object-cover" />
            ) : (
              <span className="skeleton absolute inset-0" />
            )}
          </button>
        ))}
      </div>

      <div className="relative flex-1">
        <div
          className="group relative aspect-square overflow-hidden rounded-[28px] border border-line/70 bg-shell-2"
          onMouseEnter={() => setZoomed(true)}
          onMouseLeave={() => setZoomed(false)}
        >
          {current.url ? (
            <Image
              key={current.url}
              src={current.url}
              alt={current.alt}
              fill
              priority
              sizes="(min-width: 1024px) 46vw, 92vw"
              className={`animate-fade cursor-zoom-in object-cover transition-transform duration-[900ms] ease-[cubic-bezier(0.16,1,0.3,1)] ${
                zoomed ? "scale-[1.12]" : "scale-100"
              }`}
              onClick={() => setLightbox(true)}
            />
          ) : (
            <div className="skeleton absolute inset-0" />
          )}

          {badge ? (
            <span className="absolute top-4 left-4 rounded-full bg-ink/85 px-3 py-1.5 text-[0.62rem] font-semibold tracking-[0.16em] text-paper uppercase backdrop-blur">
              {badge}
            </span>
          ) : null}

          <span className="absolute right-4 bottom-4 rounded-full bg-paper/90 px-3 py-1.5 text-[0.68rem] font-semibold tracking-[0.1em] text-ink-2 tabular-nums backdrop-blur">
            {active + 1} / {safeImages.length}
          </span>

          {safeImages.length > 1 ? (
            <>
              <button
                type="button"
                onClick={() => step(-1)}
                aria-label="Previous image"
                className="absolute top-1/2 left-3 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-full border border-line/60 bg-paper/85 text-ink opacity-0 backdrop-blur transition-all duration-300 group-hover:opacity-100 hover:bg-paper"
              >
                <ChevronLeftIcon className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => step(1)}
                aria-label="Next image"
                className="absolute top-1/2 right-3 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-full border border-line/60 bg-paper/85 text-ink opacity-0 backdrop-blur transition-all duration-300 group-hover:opacity-100 hover:bg-paper"
              >
                <ChevronRightIcon className="h-4 w-4" />
              </button>
            </>
          ) : null}
        </div>

        <div className="mt-3 flex gap-2 lg:hidden">
          {safeImages.map((image, index) => (
            <span
              key={`dot-${index}`}
              className={`h-1.5 flex-1 rounded-full transition-colors duration-300 ${
                index === active ? "bg-ink" : "bg-shell-3"
              }`}
            />
          ))}
        </div>
      </div>

      {lightbox ? (
        <div className="fixed inset-0 z-[90] flex items-center justify-center bg-ink/92 p-4 backdrop-blur-sm">
          <button
            type="button"
            className="absolute inset-0 cursor-zoom-out"
            onClick={() => setLightbox(false)}
            aria-label="Close image viewer"
          />
          <div className="animate-pop relative h-[86vh] w-full max-w-4xl">
            {current.url ? (
              <Image src={current.url} alt={current.alt} fill sizes="90vw" className="rounded-[24px] object-contain" />
            ) : null}
          </div>
          <button
            type="button"
            onClick={() => setLightbox(false)}
            className="absolute top-6 right-6 grid h-11 w-11 place-items-center rounded-full border border-paper/25 text-paper transition hover:bg-paper hover:text-ink"
            aria-label="Close"
          >
            <CloseIcon className="h-5 w-5" />
          </button>
          {safeImages.length > 1 ? (
            <>
              <button
                type="button"
                onClick={() => step(-1)}
                className="absolute top-1/2 left-4 grid h-12 w-12 -translate-y-1/2 place-items-center rounded-full border border-paper/25 text-paper transition hover:bg-paper hover:text-ink"
                aria-label="Previous image"
              >
                <ChevronLeftIcon className="h-5 w-5" />
              </button>
              <button
                type="button"
                onClick={() => step(1)}
                className="absolute top-1/2 right-4 grid h-12 w-12 -translate-y-1/2 place-items-center rounded-full border border-paper/25 text-paper transition hover:bg-paper hover:text-ink"
                aria-label="Next image"
              >
                <ChevronRightIcon className="h-5 w-5" />
              </button>
            </>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
