"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { RatingLine } from "@/components/Rating";
import {
  ArrowRightIcon,
  BagIcon,
  CheckIcon,
  ChevronDownIcon,
  DropletIcon,
  LeafIcon,
  MinusIcon,
  PlusIcon,
  ShieldIcon,
  TruckIcon,
} from "@/components/icons";
import { useCart } from "@/lib/cart";
import { formatCents } from "@/lib/cart-types";
import type { CatalogProduct } from "@/lib/catalog";

const ACCORDIONS = [
  { id: "description", label: "The details" },
  { id: "ingredients", label: "Full ingredients" },
  { id: "ritual", label: "How to use it" },
  { id: "shipping", label: "Shipping & returns" },
] as const;

export function PurchasePanel({ product }: { product: CatalogProduct }) {
  const { addLine } = useCart();
  const router = useRouter();
  const variants = product.variants.length ? product.variants : [
    {
      id: "single",
      label: "Single bar",
      detail: `${product.weightGrams} g`,
      priceCents: product.priceCents,
      stock: product.stock,
    },
  ];
  const [variantId, setVariantId] = useState(variants[0].id);
  const [quantity, setQuantity] = useState(1);
  const [open, setOpen] = useState<string[]>(["description"]);
  const variant = variants.find((item) => item.id === variantId) ?? variants[0];
  const savings = variant.compareAtCents ? variant.compareAtCents - variant.priceCents : 0;

  const delivery = useMemo(() => {
    const date = new Date();
    date.setDate(date.getDate() + 4);
    return new Intl.DateTimeFormat("en-US", { weekday: "long", month: "short", day: "numeric" }).format(date);
  }, []);

  const stockLeft = Math.min(variant.stock, product.stock);

  const buildLine = (qty: number) => ({
    productId: product.id,
    slug: product.slug,
    name: product.name,
    subtitle: product.subtitle,
    variantId: variant.id,
    variantLabel: variant.label,
    variantDetail: variant.detail,
    unitPriceCents: variant.priceCents,
    compareAtCents: variant.compareAtCents ?? null,
    quantity: qty,
    image: product.images[0]?.url ?? "",
    maxQuantity: Math.min(stockLeft, 12),
  });

  const toggleAccordion = (id: string) => {
    setOpen((current) => (current.includes(id) ? current.filter((item) => item !== id) : [...current, id]));
  };

  return (
    <div className="flex flex-col gap-6 lg:sticky lg:top-32 lg:self-start">
      <div>
        <Link
          href={`/collections/${product.collectionSlug}`}
          className="text-[0.66rem] font-semibold tracking-[0.22em] text-sage-deep uppercase underline-sweep"
        >
          {product.collectionName}
        </Link>
        <h1 className="mt-3 font-display text-[clamp(2rem,4.4vw,3rem)] leading-[1.02] font-semibold text-balance">
          {product.name}
        </h1>
        <p className="mt-2.5 text-[0.98rem] text-ink-soft">{product.subtitle}</p>
        <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2">
          <a href="#reviews" className="transition hover:opacity-75">
            <RatingLine rating={product.rating} count={product.reviewCount} size={15} />
          </a>
          <span className="flex items-center gap-1.5 text-[0.76rem] text-ink-soft">
            <DropletIcon className="h-4 w-4 text-sage-deep" />
            {product.scent}
          </span>
          <span className="flex items-center gap-1.5 text-[0.76rem] text-ink-soft">
            <ShieldIcon className="h-4 w-4 text-sage-deep" />
            {product.ageRange}
          </span>
        </div>
      </div>

      <div className="flex flex-wrap items-baseline gap-3 border-y border-line py-5">
        <span className="font-display text-[2rem] leading-none font-semibold text-ink">
          {formatCents(variant.priceCents * quantity)}
        </span>
        {variant.compareAtCents && variant.compareAtCents > variant.priceCents ? (
          <>
            <span className="text-[0.95rem] text-ink-mute line-through">
              {formatCents(variant.compareAtCents * quantity)}
            </span>
            <span className="rounded-full bg-clay/12 px-2.5 py-1 text-[0.7rem] font-semibold tracking-[0.1em] text-clay-deep uppercase">
              Save {formatCents(savings * quantity)}
            </span>
          </>
        ) : null}
        <span className="ml-auto text-[0.78rem] text-ink-mute">
          {product.weightGrams} g · about 60 baths
        </span>
      </div>

      <p className="text-[0.95rem] leading-relaxed text-ink-2">{product.summary}</p>

      <div>
        <div className="flex items-center justify-between">
          <h2 className="text-[0.68rem] font-semibold tracking-[0.2em] text-ink-mute uppercase">Choose a size</h2>
          <span className="text-[0.76rem] text-ink-soft">{variant.detail}</span>
        </div>
        <div className="mt-3 flex flex-wrap gap-2.5">
          {variants.map((option) => {
            const selected = option.id === variantId;
            return (
              <button
                key={option.id}
                type="button"
                onClick={() => {
                  setVariantId(option.id);
                  setQuantity(1);
                }}
                className={`group relative rounded-[16px] border px-4 py-3 text-left transition-all duration-300 ${
                  selected
                    ? "border-ink bg-paper shadow-[var(--shadow-soft)]"
                    : "border-line bg-paper/60 hover:border-ink/45"
                }`}
                aria-pressed={selected}
              >
                <span className="block text-[0.88rem] font-semibold text-ink">{option.label}</span>
                <span className="mt-0.5 block text-[0.76rem] text-ink-soft">
                  {formatCents(option.priceCents)}
                  {option.compareAtCents && option.compareAtCents > option.priceCents ? (
                    <span className="ml-1.5 text-ink-mute line-through">{formatCents(option.compareAtCents)}</span>
                  ) : null}
                </span>
                {selected ? (
                  <span className="absolute top-2.5 right-2.5 grid h-4 w-4 place-items-center rounded-full bg-sage-deep text-paper">
                    <CheckIcon className="h-2.5 w-2.5" strokeWidth={3} />
                  </span>
                ) : null}
              </button>
            );
          })}
        </div>
      </div>

      {stockLeft <= 60 ? (
        <p className="flex items-center gap-2 rounded-[14px] bg-honey/12 px-4 py-2.5 text-[0.8rem] text-ink-2">
          <LeafIcon className="h-4 w-4 text-honey" />
          Only {stockLeft} left from this batch — the next pour cures in six weeks.
        </p>
      ) : null}

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="flex items-center justify-between rounded-full border border-line bg-paper px-2 sm:w-36">
          <button
            type="button"
            onClick={() => setQuantity((value) => Math.max(1, value - 1))}
            className="grid h-11 w-11 place-items-center rounded-full text-ink transition hover:bg-shell-2"
            aria-label="Decrease quantity"
          >
            <MinusIcon className="h-4 w-4" />
          </button>
          <span className="text-[0.95rem] font-semibold tabular-nums" aria-live="polite">
            {quantity}
          </span>
          <button
            type="button"
            onClick={() => setQuantity((value) => Math.min(Math.min(stockLeft, 12), value + 1))}
            className="grid h-11 w-11 place-items-center rounded-full text-ink transition hover:bg-shell-2"
            aria-label="Increase quantity"
          >
            <PlusIcon className="h-4 w-4" />
          </button>
        </div>

        <button
          type="button"
          onClick={() => addLine(buildLine(quantity))}
          className="group inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-ink px-7 py-4 text-[0.76rem] font-semibold tracking-[0.16em] text-paper uppercase transition-all duration-300 hover:bg-sage-deep hover:shadow-[var(--shadow-lift)]"
        >
          <BagIcon className="h-4 w-4 transition-transform duration-300 group-hover:-rotate-6" />
          Add to bag · {formatCents(variant.priceCents * quantity)}
        </button>
      </div>

      <button
        type="button"
        onClick={() => {
          addLine(buildLine(quantity), { open: false, announce: "Taking you to checkout…" });
          router.push("/checkout");
        }}
        className="group inline-flex items-center justify-center gap-2 rounded-full border border-ink/25 px-7 py-3.5 text-[0.74rem] font-semibold tracking-[0.16em] text-ink uppercase transition hover:border-ink hover:bg-shell-2"
      >
        Buy it now
        <ArrowRightIcon className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
      </button>

      <div className="flex flex-wrap gap-x-6 gap-y-2.5 rounded-[18px] bg-shell-2/70 px-5 py-4 text-[0.78rem] text-ink-2">
        <span className="flex items-center gap-2">
          <TruckIcon className="h-4 w-4 text-sage-deep" />
          Free over {formatCents(4500)} · arrives by {delivery}
        </span>
        <span className="flex items-center gap-2">
          <ShieldIcon className="h-4 w-4 text-sage-deep" />
          60-day gentle-skin promise
        </span>
        <span className="flex items-center gap-2">
          <LeafIcon className="h-4 w-4 text-sage-deep" />
          Plastic-free, paper wrap
        </span>
      </div>

      <div className="flex flex-wrap gap-2">
        {product.concerns.map((concern) => (
          <Link
            key={concern}
            href={`/shop?concerns=${encodeURIComponent(concern)}`}
            className="rounded-full border border-line bg-paper px-3.5 py-1.5 text-[0.74rem] text-ink-soft transition hover:border-sage hover:text-ink"
          >
            {concern}
          </Link>
        ))}
      </div>

      <div className="divide-y divide-line border-y border-line">
        {ACCORDIONS.map((section) => {
          const isOpen = open.includes(section.id);
          return (
            <div key={section.id}>
              <button
                type="button"
                onClick={() => toggleAccordion(section.id)}
                className="flex w-full items-center justify-between gap-4 py-4 text-left"
                aria-expanded={isOpen}
              >
                <span className="font-display text-[1.02rem] font-semibold text-ink">{section.label}</span>
                <ChevronDownIcon
                  className={`h-4 w-4 shrink-0 text-ink-soft transition-transform duration-400 ${isOpen ? "rotate-180" : ""}`}
                />
              </button>
              <div
                className="grid transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]"
                style={{ gridTemplateRows: isOpen ? "1fr" : "0fr" }}
              >
                <div className="overflow-hidden">
                  <div className="pb-5 text-[0.88rem] leading-relaxed whitespace-pre-line text-ink-soft">
                    {section.id === "description" ? product.description : null}
                    {section.id === "ingredients" ? (
                      <>
                        <p>{product.ingredients}</p>
                        <p className="mt-3 text-[0.8rem] text-ink-mute">
                          Free from SLS/SLES, parabens, phthalates, synthetic fragrance, dyes and palm oil.
                        </p>
                      </>
                    ) : null}
                    {section.id === "ritual" ? product.ritual : null}
                    {section.id === "shipping" ? (
                      <p>
                        Dispatched within one business day from Brattleboro, Vermont in paper-only packaging.
                        Standard delivery is free over {formatCents(4500)} and takes 3–5 business days. If a bar
                        doesn’t suit your baby’s skin, email hello@kavi.soap within 60 days and we’ll refund it —
                        you don’t need to send it back.
                      </p>
                    ) : null}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
