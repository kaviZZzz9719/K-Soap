"use client";

import { useMemo, useState } from "react";
import { Stars } from "@/components/Rating";
import { CheckIcon, ChevronDownIcon, CloseIcon, StarIcon, ThumbIcon } from "@/components/icons";
import { relativeDate } from "@/lib/cart-types";

export type ReviewItem = {
  id: number;
  authorName: string;
  authorLocation: string;
  rating: number;
  title: string;
  body: string;
  verified: boolean;
  helpfulCount: number;
  createdAt: Date | string;
};

type SortKey = "helpful" | "recent" | "high" | "low";

const SORTS: { id: SortKey; label: string }[] = [
  { id: "helpful", label: "Most helpful" },
  { id: "recent", label: "Most recent" },
  { id: "high", label: "Highest rated" },
  { id: "low", label: "Lowest rated" },
];

export function ReviewSection({
  slug,
  reviews: initialReviews,
  rating,
  reviewCount,
}: {
  slug: string;
  reviews: ReviewItem[];
  rating: string | number;
  reviewCount: number;
}) {
  const [reviews, setReviews] = useState<ReviewItem[]>(initialReviews);
  const [sort, setSort] = useState<SortKey>("helpful");
  const [ratingFilter, setRatingFilter] = useState<number | null>(null);
  const [visible, setVisible] = useState(6);
  const [helpful, setHelpful] = useState<Record<number, boolean>>({});
  const [formOpen, setFormOpen] = useState(false);
  const [summary, setSummary] = useState({ rating: Number(rating), count: reviewCount });

  const distribution = useMemo(() => {
    const counts = [0, 0, 0, 0, 0];
    for (const review of reviews) {
      const index = Math.min(5, Math.max(1, review.rating)) - 1;
      counts[index] += 1;
    }
    return counts.reverse();
  }, [reviews]);

  const shown = useMemo(() => {
    const filtered = ratingFilter ? reviews.filter((review) => review.rating === ratingFilter) : reviews;
    const sorted = [...filtered].sort((a, b) => {
      if (sort === "recent") return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      if (sort === "high") return b.rating - a.rating;
      if (sort === "low") return a.rating - b.rating;
      const aHelpful = a.helpfulCount + (helpful[a.id] ? 1 : 0);
      const bHelpful = b.helpfulCount + (helpful[b.id] ? 1 : 0);
      if (bHelpful !== aHelpful) return bHelpful - aHelpful;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
    return sorted.slice(0, visible);
  }, [helpful, ratingFilter, reviews, sort, visible]);

  const markHelpful = (id: number) => {
    setHelpful((current) => ({ ...current, [id]: !current[id] }));
  };

  return (
    <section id="reviews" className="scroll-mt-28">
      <div className="grid gap-10 lg:grid-cols-[300px_1fr] lg:gap-16">
        <div className="lg:sticky lg:top-32 lg:self-start">
          <h2 className="font-display text-[clamp(1.8rem,3.4vw,2.5rem)] leading-tight font-semibold">
            Parent reviews
          </h2>
          <div className="mt-5 flex items-end gap-3">
            <span className="font-display text-[3.4rem] leading-none font-semibold text-ink">
              {summary.rating.toFixed(1)}
            </span>
            <div className="pb-1.5">
              <Stars rating={summary.rating} size={16} />
              <p className="mt-1 text-[0.8rem] text-ink-soft">{summary.count} verified reviews</p>
            </div>
          </div>

          <div className="mt-6 flex flex-col gap-2">
            {distribution.map((count, index) => {
              const stars = 5 - index;
              const percent = summary.count > 0 ? Math.round((count / Math.max(1, reviews.length)) * 100) : 0;
              const active = ratingFilter === stars;
              return (
                <button
                  key={stars}
                  type="button"
                  onClick={() => {
                    setRatingFilter(active ? null : stars);
                    setVisible(6);
                  }}
                  className={`group flex items-center gap-3 rounded-[12px] px-2 py-1.5 text-left transition ${
                    active ? "bg-sage-mist/70" : "hover:bg-shell-2"
                  }`}
                  aria-pressed={active}
                >
                  <span className="flex w-10 shrink-0 items-center gap-1 text-[0.76rem] font-medium text-ink-soft">
                    {stars}
                    <StarIcon filled className="h-3 w-3 text-honey" />
                  </span>
                  <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-shell-3">
                    <span
                      className="block h-full rounded-full bg-honey transition-[width] duration-700"
                      style={{ width: `${percent}%` }}
                    />
                  </span>
                  <span className="w-8 shrink-0 text-right text-[0.74rem] text-ink-mute tabular-nums">{count}</span>
                </button>
              );
            })}
          </div>

          <button
            type="button"
            onClick={() => setFormOpen((open) => !open)}
            className="mt-7 w-full rounded-full bg-ink px-6 py-3.5 text-[0.74rem] font-semibold tracking-[0.14em] text-paper uppercase transition hover:bg-sage-deep"
          >
            {formOpen ? "Close form" : "Write a review"}
          </button>
          <p className="mt-3 text-[0.76rem] leading-relaxed text-ink-mute">
            Reviews are from verified purchases and moderated for detail, never for star count.
          </p>
        </div>

        <div>
          {formOpen ? (
            <ReviewForm
              slug={slug}
              onCreated={(review, nextSummary) => {
                setReviews((current) => [review, ...current]);
                if (nextSummary) setSummary(nextSummary);
                setFormOpen(false);
                setSort("recent");
              }}
              onCancel={() => setFormOpen(false)}
            />
          ) : null}

          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-line pb-4">
            <p className="text-[0.86rem] text-ink-soft">
              Showing <strong className="font-semibold text-ink">{shown.length}</strong> of{" "}
              {ratingFilter ? `${reviews.filter((review) => review.rating === ratingFilter).length} ${ratingFilter}-star` : `${reviews.length}`} reviews
              {ratingFilter ? (
                <button
                  type="button"
                  onClick={() => setRatingFilter(null)}
                  className="ml-2 inline-flex items-center gap-1 text-[0.76rem] font-semibold text-clay-deep underline-sweep"
                >
                  Clear rating filter
                  <CloseIcon className="h-3 w-3" />
                </button>
              ) : null}
            </p>
            <div className="relative">
              <select
                value={sort}
                onChange={(event) => setSort(event.target.value as SortKey)}
                className="appearance-none rounded-full border border-line bg-paper py-2.5 pr-9 pl-4 text-[0.8rem] font-medium text-ink transition hover:border-ink/50 focus:outline-none"
                aria-label="Sort reviews"
              >
                {SORTS.map((option) => (
                  <option key={option.id} value={option.id}>
                    {option.label}
                  </option>
                ))}
              </select>
              <ChevronDownIcon className="pointer-events-none absolute top-1/2 right-3 h-3.5 w-3.5 -translate-y-1/2 text-ink-soft" />
            </div>
          </div>

          <ul className="mt-6 flex flex-col gap-4">
            {shown.map((review) => (
              <li
                key={review.id}
                className="animate-rise rounded-[22px] border border-line/70 bg-paper p-6 transition-shadow duration-500 hover:shadow-[var(--shadow-soft)]"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-sage-mist font-display text-[0.95rem] font-semibold text-sage-deep">
                      {review.authorName.charAt(0).toUpperCase()}
                    </span>
                    <div>
                      <p className="flex items-center gap-2 text-[0.9rem] font-semibold text-ink">
                        {review.authorName}
                        {review.verified ? (
                          <span className="inline-flex items-center gap-1 rounded-full bg-sage-mist/70 px-2 py-0.5 text-[0.62rem] font-semibold tracking-[0.1em] text-sage-deep uppercase">
                            <CheckIcon className="h-2.5 w-2.5" strokeWidth={3} />
                            Verified
                          </span>
                        ) : null}
                      </p>
                      <p className="text-[0.74rem] text-ink-mute">{review.authorLocation}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Stars rating={review.rating} size={13} />
                    <p className="mt-1 text-[0.72rem] text-ink-mute">{relativeDate(review.createdAt)}</p>
                  </div>
                </div>

                <h3 className="mt-4 font-display text-[1.12rem] font-semibold text-ink">{review.title}</h3>
                <p className="mt-2 text-[0.9rem] leading-relaxed text-ink-soft">{review.body}</p>

                <div className="mt-4 flex items-center gap-4 border-t border-line pt-4">
                  <button
                    type="button"
                    onClick={() => markHelpful(review.id)}
                    className={`inline-flex items-center gap-2 rounded-full border px-3.5 py-1.5 text-[0.74rem] font-medium transition ${
                      helpful[review.id]
                        ? "border-sage-deep bg-sage-mist/60 text-sage-deep"
                        : "border-line text-ink-soft hover:border-ink/50 hover:text-ink"
                    }`}
                  >
                    <ThumbIcon className="h-3.5 w-3.5" />
                    Helpful · {review.helpfulCount + (helpful[review.id] ? 1 : 0)}
                  </button>
                  <span className="text-[0.74rem] text-ink-mute">Report</span>
                </div>
              </li>
            ))}
          </ul>

          {shown.length === 0 ? (
            <p className="mt-6 rounded-[18px] border border-dashed border-line px-6 py-12 text-center text-[0.9rem] text-ink-soft">
              No reviews match that filter yet.
            </p>
          ) : null}

          {visible < (ratingFilter ? reviews.filter((r) => r.rating === ratingFilter).length : reviews.length) ? (
            <div className="mt-8 flex justify-center">
              <button
                type="button"
                onClick={() => setVisible((count) => count + 6)}
                className="rounded-full border border-ink/25 px-7 py-3.5 text-[0.74rem] font-semibold tracking-[0.14em] text-ink uppercase transition hover:border-ink hover:bg-shell-2"
              >
                Show more reviews
              </button>
            </div>
          ) : null}
        </div>
      </div>
    </section>
  );
}

function ReviewForm({
  slug,
  onCreated,
  onCancel,
}: {
  slug: string;
  onCreated: (review: ReviewItem, summary?: { rating: number; count: number }) => void;
  onCancel: () => void;
}) {
  const [rating, setRating] = useState(5);
  const [hover, setHover] = useState(0);
  const [form, setForm] = useState({ authorName: "", authorLocation: "", title: "", body: "" });
  const [state, setState] = useState<"idle" | "loading" | "error">("idle");
  const [error, setError] = useState("");

  const set = (key: keyof typeof form) => (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((current) => ({ ...current, [key]: event.target.value }));

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setState("loading");
    setError("");
    try {
      const response = await fetch(`/api/products/${slug}/reviews`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, rating }),
      });
      const payload = (await response.json()) as {
        ok: boolean;
        error?: string;
        review?: ReviewItem;
        summary?: { rating: string; count: number };
      };
      if (!response.ok || !payload.ok || !payload.review) throw new Error(payload.error ?? "Could not save review");
      onCreated(payload.review, {
        rating: Number.parseFloat(payload.summary?.rating ?? "0"),
        count: payload.summary?.count ?? 0,
      });
    } catch (submitError) {
      setState("error");
      setError((submitError as Error).message);
    }
  }

  const field =
    "w-full rounded-[14px] border border-line bg-shell px-4 py-3 text-[0.9rem] text-ink placeholder:text-ink-mute transition focus:border-sage focus:outline-none";

  return (
    <form
      onSubmit={submit}
      className="animate-pop mb-8 rounded-[24px] border border-line bg-paper p-6 shadow-[var(--shadow-soft)] sm:p-8"
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <h3 className="font-display text-[1.35rem] font-semibold text-ink">Share how it went</h3>
          <p className="mt-1 text-[0.84rem] text-ink-soft">
            Specific detail helps other parents more than a star count alone.
          </p>
        </div>
        <button
          type="button"
          onClick={onCancel}
          className="rounded-full p-2 text-ink-mute transition hover:bg-shell-2 hover:text-ink"
          aria-label="Close review form"
        >
          <CloseIcon className="h-4 w-4" />
        </button>
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-4">
        <span className="text-[0.72rem] font-semibold tracking-[0.16em] text-ink-mute uppercase">Your rating</span>
        <div className="flex items-center gap-1">
          {[1, 2, 3, 4, 5].map((value) => (
            <button
              key={value}
              type="button"
              onClick={() => setRating(value)}
              onMouseEnter={() => setHover(value)}
              onMouseLeave={() => setHover(0)}
              aria-label={`${value} star${value > 1 ? "s" : ""}`}
              className="transition-transform duration-200 hover:scale-110"
            >
              <StarIcon
                filled={(hover || rating) >= value}
                className={`h-6 w-6 ${(hover || rating) >= value ? "text-honey" : "text-shell-3"}`}
              />
            </button>
          ))}
        </div>
      </div>

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <label className="block">
          <span className="mb-1.5 block text-[0.72rem] font-semibold tracking-[0.14em] text-ink-mute uppercase">
            Name
          </span>
          <input required value={form.authorName} onChange={set("authorName")} placeholder="Amara W." className={field} />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-[0.72rem] font-semibold tracking-[0.14em] text-ink-mute uppercase">
            Location
          </span>
          <input
            value={form.authorLocation}
            onChange={set("authorLocation")}
            placeholder="Brattleboro, VT"
            className={field}
          />
        </label>
      </div>

      <label className="mt-4 block">
        <span className="mb-1.5 block text-[0.72rem] font-semibold tracking-[0.14em] text-ink-mute uppercase">
          Headline
        </span>
        <input
          required
          value={form.title}
          onChange={set("title")}
          placeholder="Cleared the newborn rash in a week"
          className={field}
        />
      </label>

      <label className="mt-4 block">
        <span className="mb-1.5 block text-[0.72rem] font-semibold tracking-[0.14em] text-ink-mute uppercase">
          Your review
        </span>
        <textarea
          required
          rows={4}
          value={form.body}
          onChange={set("body")}
          placeholder="How long have you used it, what was your baby’s skin like before and after?"
          className={`${field} resize-y`}
        />
      </label>

      {state === "error" ? <p className="mt-3 text-[0.84rem] text-clay-deep">{error}</p> : null}

      <div className="mt-6 flex flex-wrap items-center gap-3">
        <button
          type="submit"
          disabled={state === "loading"}
          className="rounded-full bg-ink px-7 py-3.5 text-[0.74rem] font-semibold tracking-[0.14em] text-paper uppercase transition hover:bg-sage-deep disabled:opacity-60"
        >
          {state === "loading" ? "Publishing…" : "Publish review"}
        </button>
        <p className="text-[0.76rem] text-ink-mute">Posted instantly to this product page.</p>
      </div>
    </form>
  );
}
