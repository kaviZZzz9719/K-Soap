"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ProductCard } from "@/components/ProductCard";
import { Reveal } from "@/components/Reveal";
import { CheckIcon, ChevronDownIcon, CloseIcon, FilterIcon, SearchIcon } from "@/components/icons";
import type { CatalogProduct } from "@/lib/catalog";
import { formatCents } from "@/lib/cart-types";

type Facets = {
  collections: { slug: string; name: string }[];
  concerns: { value: string; count: number }[];
  scents: string[];
  price: { min: number; max: number };
};

type SortKey = "featured" | "price-asc" | "price-desc" | "rating" | "newest";

const SORT_OPTIONS: { id: SortKey; label: string }[] = [
  { id: "featured", label: "Featured" },
  { id: "newest", label: "Newest" },
  { id: "price-asc", label: "Price · low to high" },
  { id: "price-desc", label: "Price · high to low" },
  { id: "rating", label: "Highest rated" },
];

const PRICE_BANDS = [
  { id: "all", label: "Any price", min: undefined, max: undefined },
  { id: "under15", label: "Under $15", min: undefined, max: 1499 },
  { id: "15to25", label: "$15 – $25", min: 1500, max: 2500 },
  { id: "25to45", label: "$25 – $45", min: 2501, max: 4500 },
  { id: "over45", label: "$45 +", min: 4501, max: undefined },
] as const;

const EMPTY_FACETS: Facets = { collections: [], concerns: [], scents: [], price: { min: 0, max: 5000 } };

export function CatalogBrowser({
  facets,
  lockedCollection,
  heading,
  subheading,
}: {
  facets: Facets | null;
  lockedCollection?: string;
  heading: string;
  subheading?: string;
}) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [products, setProducts] = useState<CatalogProduct[]>([]);
  const [total, setTotal] = useState(0);
  const [pages, setPages] = useState(1);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [sortOpen, setSortOpen] = useState(false);

  const [query, setQuery] = useState(searchParams.get("q") ?? "");
  const [sort, setSort] = useState<SortKey>((searchParams.get("sort") as SortKey) ?? "featured");
  const [collectionFilter, setCollectionFilter] = useState<string[]>(
    lockedCollection
      ? [lockedCollection]
      : (searchParams.get("collection") ?? "").split(",").filter(Boolean),
  );
  const [concernFilter, setConcernFilter] = useState<string[]>(
    (searchParams.get("concerns") ?? "").split(",").filter(Boolean),
  );
  const [scentFilter, setScentFilter] = useState<string[]>(
    (searchParams.get("scent") ?? "").split(",").filter(Boolean),
  );
  const [priceBand, setPriceBand] = useState<string>(searchParams.get("price") ?? "all");
  const [facetData, setFacetData] = useState<Facets>(facets ?? EMPTY_FACETS);
  const requestId = useRef(0);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const band = PRICE_BANDS.find((option) => option.id === priceBand) ?? PRICE_BANDS[0];

  const buildUrl = useCallback(
    (nextPage: number) => {
      const params = new URLSearchParams();
      if (query.trim()) params.set("q", query.trim());
      if (sort !== "featured") params.set("sort", sort);
      if (!lockedCollection && collectionFilter.length) params.set("collection", collectionFilter.join(","));
      if (concernFilter.length) params.set("concerns", concernFilter.join(","));
      if (scentFilter.length) params.set("scent", scentFilter.join(","));
      if (priceBand !== "all") params.set("price", priceBand);
      if (nextPage > 1) params.set("page", String(nextPage));
      const search = params.toString();
      return search ? `?${search}` : "";
    },
    [collectionFilter, concernFilter, lockedCollection, priceBand, query, scentFilter, sort],
  );

  const load = useCallback(
    async (targetPage: number, mode: "replace" | "append") => {
      const id = ++requestId.current;
      setLoading(true);
      const params = new URLSearchParams();
      if (query.trim()) params.set("q", query.trim());
      params.set("sort", sort);
      if (collectionFilter.length) params.set("collection", collectionFilter.join(","));
      if (concernFilter.length) params.set("concerns", concernFilter.join(","));
      if (scentFilter.length) params.set("scent", scentFilter.join(","));
      if (typeof band.min === "number") params.set("minPrice", String(band.min));
      if (typeof band.max === "number") params.set("maxPrice", String(band.max));
      params.set("page", String(targetPage));
      params.set("limit", "12");

      try {
        const response = await fetch(`/api/products?${params.toString()}`);
        const payload = (await response.json()) as {
          ok: boolean;
          products: CatalogProduct[];
          total: number;
          pages: number;
          facets: Facets | null;
        };
        if (id !== requestId.current) return;
        if (!payload.ok) throw new Error("Catalogue unavailable");
        setProducts((current) => (mode === "append" ? [...current, ...payload.products] : payload.products));
        setTotal(payload.total);
        setPages(payload.pages);
        setPage(targetPage);
        if (payload.facets) setFacetData(payload.facets);
      } catch {
        if (id !== requestId.current) return;
        setProducts([]);
        setTotal(0);
      } finally {
        if (id === requestId.current) setLoading(false);
      }
    },
    [band.max, band.min, collectionFilter, concernFilter, query, scentFilter, sort],
  );

  // Debounced text search, immediate for structured filters.
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => void load(1, "replace"), query ? 320 : 0);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query, sort, collectionFilter, concernFilter, scentFilter, priceBand]);

  useEffect(() => {
    const search = buildUrl(page);
    const target = `${window.location.pathname}${search}`;
    if (`${window.location.pathname}${window.location.search}` !== target) {
      router.replace(target, { scroll: false });
    }
  }, [buildUrl, page, router]);

  const toggle = (list: string[], value: string, setter: (next: string[]) => void) => {
    setter(list.includes(value) ? list.filter((item) => item !== value) : [...list, value]);
  };

  const activeCount =
    (lockedCollection ? 0 : collectionFilter.length) +
    concernFilter.length +
    scentFilter.length +
    (priceBand !== "all" ? 1 : 0) +
    (query.trim() ? 1 : 0);

  const clearAll = () => {
    setQuery("");
    setCollectionFilter(lockedCollection ? [lockedCollection] : []);
    setConcernFilter([]);
    setScentFilter([]);
    setPriceBand("all");
    setSort("featured");
  };

  const filterPanel = useMemo(
    () => (
      <div className="flex flex-col gap-8">
        <section>
          <h3 className="text-[0.66rem] font-semibold tracking-[0.2em] text-ink-mute uppercase">Search</h3>
          <div className="mt-3 flex items-center gap-2 rounded-full border border-line bg-paper px-4 py-2.5 transition focus-within:border-sage">
            <SearchIcon className="h-4 w-4 shrink-0 text-ink-mute" />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Lavender, oat, newborn…"
              className="w-full bg-transparent text-[0.86rem] text-ink placeholder:text-ink-mute focus:outline-none"
              aria-label="Search products"
            />
            {query ? (
              <button type="button" onClick={() => setQuery("")} aria-label="Clear search" className="text-ink-mute hover:text-ink">
                <CloseIcon className="h-3.5 w-3.5" />
              </button>
            ) : null}
          </div>
        </section>

        {!lockedCollection ? (
          <FilterGroup title="Collection">
            {facetData.collections.map((collection) => (
              <FilterRow
                key={collection.slug}
                label={collection.name}
                checked={collectionFilter.includes(collection.slug)}
                onChange={() => toggle(collectionFilter, collection.slug, setCollectionFilter)}
              />
            ))}
          </FilterGroup>
        ) : null}

        <FilterGroup title="Skin need">
          {facetData.concerns.map((concern) => (
            <FilterRow
              key={concern.value}
              label={concern.value}
              count={concern.count}
              checked={concernFilter.includes(concern.value)}
              onChange={() => toggle(concernFilter, concern.value, setConcernFilter)}
            />
          ))}
        </FilterGroup>

        <FilterGroup title="Scent">
          {facetData.scents.map((scent) => (
            <FilterRow
              key={scent}
              label={scent}
              checked={scentFilter.includes(scent)}
              onChange={() => toggle(scentFilter, scent, setScentFilter)}
            />
          ))}
        </FilterGroup>

        <FilterGroup title="Price">
          <div className="flex flex-wrap gap-2">
            {PRICE_BANDS.map((option) => (
              <button
                key={option.id}
                type="button"
                onClick={() => setPriceBand(option.id)}
                className={`rounded-full border px-3.5 py-1.5 text-[0.76rem] font-medium transition ${
                  priceBand === option.id
                    ? "border-ink bg-ink text-paper"
                    : "border-line bg-paper text-ink-soft hover:border-ink/50 hover:text-ink"
                }`}
              >
                {option.label}
              </button>
            ))}
          </div>
        </FilterGroup>

        {activeCount > 0 ? (
          <button
            type="button"
            onClick={clearAll}
            className="w-fit text-[0.76rem] font-semibold tracking-[0.1em] text-clay-deep uppercase underline-sweep"
          >
            Clear all filters
          </button>
        ) : null}
      </div>
    ),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [facetData, collectionFilter, concernFilter, scentFilter, priceBand, query, lockedCollection, activeCount],
  );

  return (
    <div className="mx-auto max-w-[1400px] px-4 pb-24 sm:px-6 lg:px-10">
      <div className="pt-10 lg:pt-14">
        <nav className="flex items-center gap-2 text-[0.72rem] text-ink-mute" aria-label="Breadcrumb">
          <Link href="/" className="transition hover:text-ink">
            Home
          </Link>
          <span>/</span>
          <span className="text-ink-2">{heading}</span>
        </nav>
        <h1 className="mt-4 font-display text-[clamp(2.2rem,5vw,3.6rem)] leading-[1.02] font-semibold text-balance">
          {heading}
        </h1>
        {subheading ? <p className="mt-4 max-w-2xl text-[1rem] leading-relaxed text-ink-soft">{subheading}</p> : null}
      </div>

      <div className="mt-10 grid gap-8 lg:grid-cols-[260px_1fr] lg:gap-12">
        <aside className="hidden lg:block">
          <div className="sticky top-32 max-h-[calc(100vh-9rem)] overflow-y-auto pr-2 pb-8">{filterPanel}</div>
        </aside>

        <div>
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-line pb-5">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setFiltersOpen(true)}
                className="inline-flex items-center gap-2 rounded-full border border-line bg-paper px-4 py-2.5 text-[0.74rem] font-semibold tracking-[0.1em] text-ink uppercase transition hover:border-ink lg:hidden"
              >
                <FilterIcon className="h-4 w-4" />
                Filters
                {activeCount > 0 ? (
                  <span className="grid h-5 min-w-5 place-items-center rounded-full bg-clay px-1 text-[0.62rem] text-paper">
                    {activeCount}
                  </span>
                ) : null}
              </button>
              <p className="text-[0.84rem] text-ink-soft">
                {loading && total === 0 ? "Loading…" : `${total} ${total === 1 ? "product" : "products"}`}
              </p>
            </div>

            <div className="relative">
              <button
                type="button"
                onClick={() => setSortOpen((open) => !open)}
                onBlur={() => setTimeout(() => setSortOpen(false), 140)}
                className="inline-flex items-center gap-2 rounded-full border border-line bg-paper px-4 py-2.5 text-[0.78rem] font-medium text-ink transition hover:border-ink/60"
                aria-haspopup="listbox"
                aria-expanded={sortOpen}
              >
                Sort: {SORT_OPTIONS.find((option) => option.id === sort)?.label}
                <ChevronDownIcon className={`h-3.5 w-3.5 transition-transform ${sortOpen ? "rotate-180" : ""}`} />
              </button>
              {sortOpen ? (
                <ul
                  className="animate-pop absolute right-0 z-30 mt-2 w-56 overflow-hidden rounded-[18px] border border-line bg-paper py-1.5 shadow-[var(--shadow-lift)]"
                  role="listbox"
                >
                  {SORT_OPTIONS.map((option) => (
                    <li key={option.id}>
                      <button
                        type="button"
                        onMouseDown={() => {
                          setSort(option.id);
                          setSortOpen(false);
                        }}
                        className={`flex w-full items-center justify-between px-4 py-2.5 text-left text-[0.84rem] transition hover:bg-shell-2 ${
                          sort === option.id ? "font-semibold text-ink" : "text-ink-soft"
                        }`}
                        role="option"
                        aria-selected={sort === option.id}
                      >
                        {option.label}
                        {sort === option.id ? <CheckIcon className="h-4 w-4 text-sage-deep" /> : null}
                      </button>
                    </li>
                  ))}
                </ul>
              ) : null}
            </div>
          </div>

          {activeCount > 0 ? (
            <div className="mt-5 flex flex-wrap gap-2">
              {query.trim() ? <Chip label={`“${query.trim()}”`} onClear={() => setQuery("")} /> : null}
              {!lockedCollection
                ? collectionFilter.map((slug) => (
                    <Chip
                      key={slug}
                      label={facetData.collections.find((collection) => collection.slug === slug)?.name ?? slug}
                      onClear={() => toggle(collectionFilter, slug, setCollectionFilter)}
                    />
                  ))
                : null}
              {concernFilter.map((concern) => (
                <Chip key={concern} label={concern} onClear={() => toggle(concernFilter, concern, setConcernFilter)} />
              ))}
              {scentFilter.map((scent) => (
                <Chip key={scent} label={scent} onClear={() => toggle(scentFilter, scent, setScentFilter)} />
              ))}
              {priceBand !== "all" ? (
                <Chip
                  label={PRICE_BANDS.find((option) => option.id === priceBand)?.label ?? priceBand}
                  onClear={() => setPriceBand("all")}
                />
              ) : null}
            </div>
          ) : null}

          <div
            className={`mt-6 grid grid-cols-2 gap-4 transition-opacity duration-300 md:grid-cols-3 xl:grid-cols-4 ${
              loading ? "opacity-55" : "opacity-100"
            }`}
          >
            {products.map((product, index) => (
              <Reveal key={product.slug} delay={(index % 4) * 60} className="h-full">
                <ProductCard product={product} />
              </Reveal>
            ))}
            {loading && products.length === 0
              ? Array.from({ length: 8 }).map((_, index) => (
                  <div key={index} className="overflow-hidden rounded-[22px] border border-line/70 bg-paper">
                    <div className="skeleton aspect-square w-full" />
                    <div className="flex flex-col gap-2 p-5">
                      <div className="skeleton h-2.5 w-20 rounded-full" />
                      <div className="skeleton h-4 w-3/4 rounded-full" />
                      <div className="skeleton h-3 w-1/2 rounded-full" />
                    </div>
                  </div>
                ))
              : null}
          </div>

          {!loading && products.length === 0 ? (
            <div className="mt-6 rounded-[26px] border border-dashed border-line bg-paper/60 px-6 py-20 text-center">
              <h3 className="font-display text-2xl font-semibold text-ink">Nothing matches those filters</h3>
              <p className="mx-auto mt-3 max-w-sm text-[0.9rem] text-ink-soft">
                Try widening the price band, or clear the search to see the full shelf of {formatCents(1200)} –{" "}
                {formatCents(4800)} bars.
              </p>
              <button
                type="button"
                onClick={clearAll}
                className="mt-6 rounded-full bg-ink px-6 py-3 text-[0.72rem] font-semibold tracking-[0.14em] text-paper uppercase transition hover:bg-sage-deep"
              >
                Clear filters
              </button>
            </div>
          ) : null}

          {page < pages ? (
            <div className="mt-12 flex justify-center">
              <button
                type="button"
                disabled={loading}
                onClick={() => void load(page + 1, "append")}
                className="rounded-full border border-ink/25 px-8 py-4 text-[0.74rem] font-semibold tracking-[0.16em] text-ink uppercase transition hover:border-ink hover:bg-shell-2 disabled:opacity-50"
              >
                {loading ? "Loading…" : `Load more · ${Math.max(0, total - products.length)} remaining`}
              </button>
            </div>
          ) : null}
        </div>
      </div>

      {filtersOpen ? (
        <div className="fixed inset-0 z-[65] lg:hidden" role="dialog" aria-modal="true" aria-label="Filters">
          <button
            type="button"
            aria-label="Close filters"
            className="animate-fade absolute inset-0 bg-ink/45 backdrop-blur-[3px]"
            onClick={() => setFiltersOpen(false)}
          />
          <div className="animate-drawer absolute inset-y-0 right-0 flex w-full max-w-sm flex-col bg-shell">
            <div className="flex items-center justify-between border-b border-line px-5 py-4">
              <h2 className="font-display text-lg font-semibold text-ink">
                Filters{activeCount > 0 ? ` · ${activeCount}` : ""}
              </h2>
              <button
                type="button"
                onClick={() => setFiltersOpen(false)}
                className="rounded-full p-2 text-ink transition hover:bg-shell-2"
                aria-label="Close filters"
              >
                <CloseIcon className="h-5 w-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto px-5 py-6">{filterPanel}</div>
            <div className="border-t border-line bg-paper p-5">
              <button
                type="button"
                onClick={() => setFiltersOpen(false)}
                className="w-full rounded-full bg-ink px-6 py-3.5 text-[0.74rem] font-semibold tracking-[0.14em] text-paper uppercase transition hover:bg-sage-deep"
              >
                Show {total} {total === 1 ? "result" : "results"}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function FilterGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section>
      <h3 className="text-[0.66rem] font-semibold tracking-[0.2em] text-ink-mute uppercase">{title}</h3>
      <div className="mt-3 flex flex-col gap-1.5">{children}</div>
    </section>
  );
}

function FilterRow({
  label,
  checked,
  onChange,
  count,
}: {
  label: string;
  checked: boolean;
  onChange: () => void;
  count?: number;
}) {
  return (
    <label className="group flex cursor-pointer items-center gap-3 py-1 text-[0.88rem] text-ink-2 transition hover:text-ink">
      <span
        className={`grid h-[18px] w-[18px] shrink-0 place-items-center rounded-[6px] border transition-all duration-200 ${
          checked ? "border-sage-deep bg-sage-deep text-paper" : "border-line bg-paper group-hover:border-ink/50"
        }`}
      >
        {checked ? <CheckIcon className="h-3 w-3" strokeWidth={2.4} /> : null}
      </span>
      <input type="checkbox" className="sr-only" checked={checked} onChange={onChange} />
      <span className="flex-1">{label}</span>
      {typeof count === "number" ? <span className="text-[0.72rem] text-ink-mute">{count}</span> : null}
    </label>
  );
}

function Chip({ label, onClear }: { label: string; onClear: () => void }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-line bg-paper px-3.5 py-1.5 text-[0.78rem] text-ink-2">
      {label}
      <button type="button" onClick={onClear} aria-label={`Remove ${label}`} className="text-ink-mute transition hover:text-clay">
        <CloseIcon className="h-3 w-3" />
      </button>
    </span>
  );
}
