"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { BagIcon } from "@/components/icons";
import { RatingLine } from "@/components/Rating";
import { useCart } from "@/lib/cart";
import { formatCents } from "@/lib/cart-types";
import type { CatalogProduct } from "@/lib/catalog";

export function ProductCard({ product, priority = false }: { product: CatalogProduct; priority?: boolean }) {
  const { addLine } = useCart();
  const [added, setAdded] = useState(false);
  const variant = product.variants[0];
  const priceCents = variant?.priceCents ?? product.priceCents;
  const compareAt = variant?.compareAtCents ?? product.compareAtCents ?? null;
  const primary = product.images[0];
  const secondary = product.images[1] ?? product.images[0];

  const handleAdd = (event: React.MouseEvent) => {
    event.preventDefault();
    event.stopPropagation();
    addLine({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      subtitle: product.subtitle,
      variantId: variant?.id ?? "single",
      variantLabel: variant?.label ?? "Single bar",
      variantDetail: variant?.detail ?? `${product.weightGrams} g`,
      unitPriceCents: priceCents,
      compareAtCents: compareAt,
      quantity: 1,
      image: primary?.url ?? "",
      maxQuantity: Math.min(variant?.stock ?? product.stock, 12),
    });
    setAdded(true);
    window.setTimeout(() => setAdded(false), 1400);
  };

  return (
    <Link
      href={`/product/${product.slug}`}
      className="group relative flex h-full flex-col overflow-hidden rounded-[22px] border border-line/70 bg-paper transition-all duration-500 hover:-translate-y-1 hover:border-sage/60 hover:shadow-[var(--shadow-lift)]"
    >
      <div className="relative aspect-square overflow-hidden bg-shell-2">
        {primary ? (
          <>
            <Image
              src={primary.url}
              alt={primary.alt}
              fill
              sizes="(min-width: 1280px) 25vw, (min-width: 768px) 33vw, 50vw"
              priority={priority}
              className="object-cover transition-transform duration-[900ms] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.06]"
            />
            {secondary && secondary.url !== primary.url ? (
              <Image
                src={secondary.url}
                alt=""
                fill
                sizes="(min-width: 1280px) 25vw, (min-width: 768px) 33vw, 50vw"
                className="object-cover opacity-0 transition-opacity duration-700 group-hover:opacity-100"
              />
            ) : null}
          </>
        ) : (
          <div className="skeleton absolute inset-0" />
        )}

        {product.badge ? (
          <span className="absolute top-3 left-3 rounded-full bg-ink/85 px-2.5 py-1 text-[0.6rem] font-semibold tracking-[0.14em] text-paper uppercase backdrop-blur-sm">
            {product.badge}
          </span>
        ) : null}

        {compareAt && compareAt > priceCents ? (
          <span className="absolute top-3 right-3 rounded-full bg-clay px-2.5 py-1 text-[0.6rem] font-semibold tracking-[0.14em] text-paper uppercase">
            −{Math.round((1 - priceCents / compareAt) * 100)}%
          </span>
        ) : null}

        <button
          type="button"
          onClick={handleAdd}
          aria-label={`Add ${product.name} to bag`}
          className={`absolute right-3 bottom-3 inline-flex items-center gap-1.5 rounded-full px-3.5 py-2 text-[0.68rem] font-semibold tracking-[0.1em] uppercase shadow-[var(--shadow-soft)] transition-all duration-300 sm:translate-y-2 sm:opacity-0 sm:group-hover:translate-y-0 sm:group-hover:opacity-100 ${
            added ? "bg-sage-deep text-paper" : "bg-paper/95 text-ink hover:bg-ink hover:text-paper"
          }`}
        >
          <BagIcon className="h-3.5 w-3.5" />
          {added ? "Added" : "Add"}
        </button>
      </div>

      <div className="flex flex-1 flex-col gap-2 p-4 sm:p-5">
        <p className="text-[0.62rem] font-semibold tracking-[0.18em] text-sage-deep uppercase">
          {product.collectionName}
        </p>
        <h3 className="font-display text-[1.05rem] leading-snug font-semibold text-ink">{product.name}</h3>
        <p className="line-clamp-2 text-[0.8rem] leading-relaxed text-ink-soft">{product.scent} · {product.ageRange}</p>
        <div className="mt-auto flex items-end justify-between gap-3 pt-3">
          <RatingLine rating={product.rating} count={product.reviewCount} />
          <div className="text-right">
            {compareAt && compareAt > priceCents ? (
              <span className="mr-1.5 text-[0.72rem] text-ink-mute line-through">{formatCents(compareAt)}</span>
            ) : null}
            <span className="font-display text-[1.05rem] font-semibold text-ink">{formatCents(priceCents)}</span>
          </div>
        </div>
      </div>
    </Link>
  );
}
