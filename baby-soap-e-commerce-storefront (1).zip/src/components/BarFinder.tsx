"use client";

import Link from "next/link";
import { useState } from "react";
import { ArrowRightIcon, CheckIcon, SparkleIcon } from "@/components/icons";

const QUESTIONS = [
  {
    id: "age",
    prompt: "How old is the bather?",
    options: [
      { value: "newborn", label: "Newborn · 0–3 months" },
      { value: "baby", label: "Baby · 3–12 months" },
      { value: "toddler", label: "Toddler · 1–3 years" },
      { value: "gift", label: "I’m buying a gift" },
    ],
  },
  {
    id: "skin",
    prompt: "What is their skin like after a bath?",
    options: [
      { value: "normal", label: "Fine — nothing to report" },
      { value: "dry", label: "Dry, tight or flaky" },
      { value: "reactive", label: "Red, itchy or eczema-prone" },
      { value: "heat", label: "Prone to heat rash or prickly bits" },
    ],
  },
  {
    id: "mood",
    prompt: "What should the bath smell like?",
    options: [
      { value: "plain", label: "Nothing at all, thank you" },
      { value: "milky", label: "Soft milk and vanilla" },
      { value: "calm", label: "Lavender, for the wind-down" },
      { value: "fresh", label: "Fresh and cooling" },
    ],
  },
] as const;

type AnswerKey = (typeof QUESTIONS)[number]["id"];

const RECOMMENDATIONS: Record<string, { slug: string; name: string; reason: string }> = {
  "first-light-newborn-bar": {
    slug: "first-light-newborn-bar",
    name: "First Light Newborn Bar",
    reason: "Fragrance-free goat milk, pH 5.5 and six ingredients — the safest place to start with brand-new skin.",
  },
  "oat-calendula-comfort-bar": {
    slug: "oat-calendula-comfort-bar",
    name: "Oat & Calendula Comfort Bar",
    reason: "5% colloidal oatmeal and six-week calendula infusion for itch, rough patches and eczema-prone skin.",
  },
  "chamomile-hush-bar": {
    slug: "chamomile-hush-bar",
    name: "Chamomile Hush Bar",
    reason: "Chamomile infusion with 4% colloidal oat — our go-to for cheeks that flush red after bathing.",
  },
  "sleepy-moon-lavender-bar": {
    slug: "sleepy-moon-lavender-bar",
    name: "Sleepy Moon Lavender Bar",
    reason: "Single-farm French lavender at 0.3%, dosed low for little noses and the evening wind-down.",
  },
  "aloe-whisper-bar": {
    slug: "aloe-whisper-bar",
    name: "Aloe Whisper Bar",
    reason: "12% aloe and cucumber seed oil — light, cooling and built for heat rash and post-sun skin.",
  },
  "cloud-milk-bath-bar": {
    slug: "cloud-milk-bath-bar",
    name: "Cloud Milk Bath Bar",
    reason: "Oat milk and the softest vanilla we’re allowed to use. Lathers fast, even in hard water.",
  },
  "shea-silk-body-bar": {
    slug: "shea-silk-body-bar",
    name: "Shea Silk Body Bar",
    reason: "30% unrefined shea for dry, tight skin — and the best value per bath in the range.",
  },
  "whole-ritual-gift-set": {
    slug: "whole-ritual-gift-set",
    name: "The Whole Ritual Gift Set",
    reason: "Four bars covering the first year, wrapped in linen with a plantable card and a hand-written note.",
  },
};

function recommend(answers: Record<AnswerKey, string>) {
  if (answers.age === "gift") return RECOMMENDATIONS["whole-ritual-gift-set"];
  if (answers.skin === "heat" || answers.mood === "fresh") return RECOMMENDATIONS["aloe-whisper-bar"];
  if (answers.skin === "reactive") {
    return answers.age === "newborn"
      ? RECOMMENDATIONS["chamomile-hush-bar"]
      : RECOMMENDATIONS["oat-calendula-comfort-bar"];
  }
  if (answers.mood === "calm") return RECOMMENDATIONS["sleepy-moon-lavender-bar"];
  if (answers.mood === "plain") return RECOMMENDATIONS["first-light-newborn-bar"];
  if (answers.skin === "dry") {
    return answers.age === "toddler"
      ? RECOMMENDATIONS["shea-silk-body-bar"]
      : RECOMMENDATIONS["cloud-milk-bath-bar"];
  }
  if (answers.mood === "milky") return RECOMMENDATIONS["cloud-milk-bath-bar"];
  return answers.age === "newborn"
    ? RECOMMENDATIONS["first-light-newborn-bar"]
    : RECOMMENDATIONS["shea-silk-body-bar"];
}

export function BarFinder() {
  const [answers, setAnswers] = useState<Partial<Record<AnswerKey, string>>>({});
  const [index, setIndex] = useState(0);
  const [done, setDone] = useState(false);

  const question = QUESTIONS[index];
  const complete = done && Object.keys(answers).length === QUESTIONS.length;
  const result = complete ? recommend(answers as Record<AnswerKey, string>) : null;

  const answer = (key: AnswerKey, value: string) => {
    const next = { ...answers, [key]: value };
    setAnswers(next);
    if (index < QUESTIONS.length - 1) {
      setIndex((current) => current + 1);
    } else {
      setDone(true);
    }
  };

  const reset = () => {
    setAnswers({});
    setIndex(0);
    setDone(false);
  };

  return (
    <div className="overflow-hidden rounded-[28px] border border-line bg-paper shadow-[var(--shadow-soft)]">
      <div className="flex items-center justify-between border-b border-line bg-shell-2/60 px-6 py-4">
        <span className="flex items-center gap-2 text-[0.66rem] font-semibold tracking-[0.2em] text-sage-deep uppercase">
          <SparkleIcon className="h-3.5 w-3.5" />
          Find your bar
        </span>
        <span className="text-[0.74rem] text-ink-soft tabular-nums">
          {done ? "Result" : `${Math.min(index + 1, QUESTIONS.length)} / ${QUESTIONS.length}`}
        </span>
      </div>

      <div className="p-6 sm:p-8">
        {!done ? (
          <>
            <div className="mb-6 flex gap-1.5">
              {QUESTIONS.map((item, position) => (
                <span
                  key={item.id}
                  className={`h-1 flex-1 rounded-full transition-colors duration-500 ${
                    position < index ? "bg-sage-deep" : position === index ? "bg-ink" : "bg-shell-3"
                  }`}
                />
              ))}
            </div>
            <h3 className="font-display text-[clamp(1.4rem,3vw,1.9rem)] leading-tight font-semibold text-ink">
              {question.prompt}
            </h3>
            <div className="mt-6 grid gap-2.5 sm:grid-cols-2">
              {question.options.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => answer(question.id, option.value)}
                  className={`group flex items-center justify-between gap-3 rounded-[16px] border px-5 py-4 text-left transition-all duration-300 hover:-translate-y-0.5 ${
                    answers[question.id] === option.value
                      ? "border-ink bg-shell"
                      : "border-line bg-paper hover:border-ink/50"
                  }`}
                >
                  <span className="text-[0.92rem] font-medium text-ink-2 group-hover:text-ink">{option.label}</span>
                  <ArrowRightIcon className="h-4 w-4 shrink-0 text-ink-mute transition-transform duration-300 group-hover:translate-x-1 group-hover:text-ink" />
                </button>
              ))}
            </div>
            {index > 0 ? (
              <button
                type="button"
                onClick={() => setIndex((current) => Math.max(0, current - 1))}
                className="mt-6 text-[0.76rem] font-semibold tracking-[0.12em] text-ink-soft uppercase transition hover:text-ink"
              >
                ← Previous question
              </button>
            ) : null}
          </>
        ) : null}

        {result ? (
          <div className="animate-pop">
            <span className="inline-flex items-center gap-2 rounded-full bg-sage-mist px-3.5 py-1.5 text-[0.66rem] font-semibold tracking-[0.16em] text-sage-deep uppercase">
              <CheckIcon className="h-3.5 w-3.5" strokeWidth={2.6} />
              Your match
            </span>
            <h3 className="mt-5 font-display text-[clamp(1.6rem,3.6vw,2.3rem)] leading-tight font-semibold text-ink">
              {result.name}
            </h3>
            <p className="mt-3 max-w-lg text-[0.95rem] leading-relaxed text-ink-soft">{result.reason}</p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link
                href={`/product/${result.slug}`}
                className="group inline-flex items-center gap-2 rounded-full bg-ink px-7 py-4 text-[0.74rem] font-semibold tracking-[0.16em] text-paper uppercase transition hover:bg-sage-deep"
              >
                View the bar
                <ArrowRightIcon className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <button
                type="button"
                onClick={reset}
                className="inline-flex items-center rounded-full border border-ink/25 px-7 py-4 text-[0.74rem] font-semibold tracking-[0.16em] text-ink uppercase transition hover:border-ink hover:bg-shell-2"
              >
                Start again
              </button>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
