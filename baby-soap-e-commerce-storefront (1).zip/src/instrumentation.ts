export async function register() {
  // Never touch the database while Next is compiling a production build.
  if (process.env.NEXT_PHASE === "phase-production-build") return;
  if (process.env.NEXT_RUNTIME !== "nodejs") return;

  try {
    const { seedDatabase } = await import("@/db/seed");
    const result = await seedDatabase();
    if (result.seeded) {
      console.log(`[kAvI] Seeded storefront with ${result.productCount} products.`);
    }
  } catch (error) {
    console.warn("[kAvI] Skipping automatic seed:", (error as Error).message);
  }
}
