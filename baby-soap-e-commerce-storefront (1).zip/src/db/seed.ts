import { sql } from "drizzle-orm";
import { db } from "@/db";
import {
  collections,
  orderItems,
  orders,
  productImages,
  products,
  reviews,
  type ProductVariant,
} from "@/db/schema";

const img = (id: number, w = 1200, h = 1200) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=${w}&h=${h}`;

const daysAgo = (n: number) => new Date(Date.now() - n * 86_400_000);

type SeedCollection = {
  slug: string;
  name: string;
  tagline: string;
  description: string;
  image: string;
  accent: string;
  position: number;
};

const COLLECTIONS: SeedCollection[] = [
  {
    slug: "newborn-rituals",
    name: "Newborn Rituals",
    tagline: "Fragrance-free, from the very first bath",
    description:
      "The gentlest bars we make. pH-balanced for the first weeks of life, with nothing added that a newborn's skin has to work at — no fragrance, no dyes, no essential oils.",
    image: img(6849432, 1000, 1250),
    accent: "#e6c9b4",
    position: 1,
  },
  {
    slug: "everyday-bath",
    name: "Everyday Bath",
    tagline: "Built for nightly splashes and muddy knees",
    description:
      "Creamy, long-lasting bars that lather fast and rinse clean. Cold-processed in small batches so the glycerin stays in the soap, not down the drain.",
    image: img(6690846, 1000, 1250),
    accent: "#9bb09a",
    position: 2,
  },
  {
    slug: "calm-comfort",
    name: "Calm & Comfort",
    tagline: "For skin that flushes, itches and complains",
    description:
      "Colloidal oatmeal, calendula and chamomile in concentrations that actually do something. Developed with paediatric dermatologists for eczema-prone and reactive skin.",
    image: img(6815656, 1000, 1250),
    accent: "#d8b26a",
    position: 3,
  },
  {
    slug: "bedtime",
    name: "Bedtime",
    tagline: "Lavender, chamomile and a slower evening",
    description:
      "Low-dose botanical blends designed for the wind-down. Independent testing showed 8 in 10 parents said the bedtime bath felt calmer within a week.",
    image: img(6187610, 1000, 1250),
    accent: "#a9a4c9",
    position: 4,
  },
  {
    slug: "gift-sets",
    name: "Gifting & Sets",
    tagline: "Wrapped in seed paper, ready for the nursery door",
    description:
      "Baby-shower sets, hospital-bag bundles and travel minis — packed plastic-free in letterpress boxes with a hand-written note if you'd like one.",
    image: img(7500299, 1000, 1250),
    accent: "#c98f7a",
    position: 5,
  },
];

type SeedProduct = {
  slug: string;
  name: string;
  subtitle: string;
  collection: string;
  priceCents: number;
  compareAtCents?: number;
  scent: string;
  ageRange: string;
  concerns: string[];
  badge?: string;
  summary: string;
  description: string;
  ingredients: string;
  ritual: string;
  weightGrams: number;
  stock: number;
  featured: boolean;
  position: number;
  images: { url: string; alt: string }[];
  variants: ProductVariant[];
  reviews: {
    authorName: string;
    authorLocation: string;
    rating: number;
    title: string;
    body: string;
    daysAgo: number;
    verified?: boolean;
    helpfulCount?: number;
  }[];
};

const singleAndPack = (single: number, trio: number, note = "Saves 15%") => [
  { id: "single", label: "Single bar", detail: "100 g", priceCents: single, stock: 140 },
  { id: "trio", label: "Ritual pack of 3", detail: "3 × 100 g", priceCents: trio, stock: 45 },
] as ProductVariant[];

const PRODUCTS: SeedProduct[] = [
  {
    slug: "first-light-newborn-bar",
    name: "First Light Newborn Bar",
    subtitle: "Fragrance-free goat milk bar · 0m+",
    collection: "newborn-rituals",
    priceCents: 1400,
    compareAtCents: 1800,
    scent: "Fragrance-free",
    ageRange: "Newborn 0m+",
    concerns: ["Sensitive skin", "Newborn", "Eczema-prone"],
    badge: "Bestseller",
    summary:
      "Six ingredients, no fragrance, and a lather so soft you can use it on a two-week-old without a second thought.",
    description:
      "We built First Light for the bath nobody warns you about — the first one, with a slippery newborn and shaking hands. Goat milk brings natural lactic acid and fat, cold-processed shea seals the barrier, and that is genuinely the whole story. It is pH-balanced to 5.5, tear-free, and passes the repeat-insult patch test at an independent lab on adult and paediatric panels.\n\nThe bar cures for six weeks, which is why it does not turn to mush in the dish and why one bar outlasts roughly three bottles of liquid wash.",
    ingredients:
      "Saponified oils of Olea Europaea (Olive) Fruit Oil, Butyrospermum Parkii (Shea) Butter, Cocos Nucifera (Coconut) Oil, Caprae Lac (Goat Milk), Avena Sativa (Colloidal Oat) Kernel Flour, Ricinus Communis (Castor) Seed Oil. Nothing else.",
    ritual:
      "Lather in warm (not hot) hands rather than directly on baby skin. Sweep over the body in one pass, rinse with a soft cloth, and pat — never rub — dry. Use three times a week; newborns do not need a daily soak.",
    weightGrams: 100,
    stock: 140,
    featured: true,
    position: 1,
    images: [
      { url: img(6682972), alt: "First Light newborn soap bar on a white surface" },
      { url: img(7500296), alt: "Handmade newborn soap bar held in cupped hands" },
      { url: img(7630252), alt: "Soft white foam from the First Light bar" },
    ],
    variants: singleAndPack(1400, 3570),
    reviews: [
      {
        authorName: "Priya Raman",
        authorLocation: "Austin, TX",
        rating: 5,
        title: "The only thing that survived our NICU homecoming",
        body: "Our daughter came home with skin so dry it cracked at the wrists. The midwife suggested a plain soap with no fragrance and this is the third bar we've bought. Two months in, no flare-ups at all.",
        daysAgo: 4,
        helpfulCount: 46,
      },
      {
        authorName: "Daniel Okafor",
        authorLocation: "Chicago, IL",
        rating: 5,
        title: "Doesn't dissolve in the dish",
        body: "Small thing but it matters: three weeks of near-daily use and the bar is still firm. Smells like nothing, which is exactly the point.",
        daysAgo: 11,
        helpfulCount: 22,
      },
      {
        authorName: "Marta Lindqvist",
        authorLocation: "Brooklyn, NY",
        rating: 4,
        title: "Lovely, wish it came in a bigger size",
        body: "Gentle and creamy. I use it on my own face now too. My only note is that I'd happily pay for a 200 g version for the family bathroom.",
        daysAgo: 23,
        helpfulCount: 9,
      },
      {
        authorName: "Aisha Karim",
        authorLocation: "Toronto, ON",
        rating: 5,
        title: "No tears, no redness",
        body: "We've tried four 'baby' brands that all left her cheeks flushed. This one leaves her skin feeling like skin. Ordered the three-pack on subscription.",
        daysAgo: 38,
        verified: true,
        helpfulCount: 31,
      },
    ],
  },
  {
    slug: "cloud-milk-bath-bar",
    name: "Cloud Milk Bath Bar",
    subtitle: "Oat milk & vanilla cream · 3m+",
    collection: "everyday-bath",
    priceCents: 1200,
    scent: "Warm milk, soft vanilla",
    ageRange: "3 months +",
    concerns: ["Dry skin", "Daily bath", "Toddler"],
    badge: "New",
    summary:
      "A milky everyday bar that turns a rushed Tuesday bath into something that smells like a bakery in winter.",
    description:
      "Cloud Milk is our softest-scented everyday bar — vanilla absolute at 0.08%, well below the level paediatric dermatologists flag as irritating, plus oat milk for slip. It lathers in under ten seconds even in hard water, which is the whole reason it exists.\n\nHard-water households lose a shocking amount of liquid wash to the rinse cycle. A cured bar performs in the same water with roughly a third of the product.",
    ingredients:
      "Saponified Olive Oil, Shea Butter, Coconut Oil, Avena Sativa (Oat) Milk Powder, Castor Oil, Vanilla Planifolia Fruit Extract, Kaolin Clay, Tocopherol (Vitamin E).",
    ritual:
      "Rub between wet palms for five seconds to build the milk lather, then work through hair and body. Rinse once. Store on a draining dish so the bar cures between uses.",
    weightGrams: 100,
    stock: 180,
    featured: true,
    position: 2,
    images: [
      { url: img(6187525), alt: "Stack of Cloud Milk bath bars" },
      { url: img(6690916), alt: "Cloud Milk bar with cream and lotion on a white surface" },
      { url: img(7630254), alt: "Airy foam bubbles from the milk bar" },
    ],
    variants: singleAndPack(1200, 3060),
    reviews: [
      {
        authorName: "Hannah Weiss",
        authorLocation: "Portland, OR",
        rating: 5,
        title: "Smells like a hug",
        body: "The vanilla is faint in the best way — you notice it in the steam, not on the skin afterwards. My three-year-old asks for 'the cloud soap' by name.",
        daysAgo: 6,
        helpfulCount: 28,
      },
      {
        authorName: "Tom Beckett",
        authorLocation: "Denver, CO",
        rating: 5,
        title: "Handles our hard water",
        body: "We have brutally hard water in Denver and liquid wash just slides off. This lathers properly. Bar is still going after a month.",
        daysAgo: 19,
        helpfulCount: 14,
      },
      {
        authorName: "Lucia Fernández",
        authorLocation: "Miami, FL",
        rating: 4,
        title: "Great, mild scent",
        body: "Would have loved a slightly stronger vanilla but I understand why they keep it low for babies. Skin feels soft without any film.",
        daysAgo: 31,
        helpfulCount: 5,
      },
    ],
  },
  {
    slug: "sleepy-moon-lavender-bar",
    name: "Sleepy Moon Lavender Bar",
    subtitle: "French lavender & chamomile · 6m+",
    collection: "bedtime",
    priceCents: 1500,
    scent: "French lavender, chamomile",
    ageRange: "6 months +",
    concerns: ["Bedtime", "Restless sleep", "Dry skin"],
    badge: "Bestseller",
    summary:
      "Our most-bought bar. Lavender from a single farm in Provence, dosed low enough for little noses and strong enough to change the mood of a room.",
    description:
      "Sleepy Moon started as a request from a sleep consultant we work with: something that makes the last bath of the day feel like a boundary rather than a battle. We use Lavandula angustifolia (true lavender, not the sharper lavandin) steam-distilled on one farm in Provence, plus Roman chamomile.\n\nFragrance load is 0.3% — a third of what a typical adult body bar carries. In a 21-day parent diary study, 82% reported their child settled faster on bath nights.",
    ingredients:
      "Saponified Olive Oil, Shea Butter, Coconut Oil, Lavandula Angustifolia (Lavender) Flower Oil, Anthemis Nobilis (Chamomile) Flower Extract, Calendula Officinalis Petals, Castor Oil, Tocopherol.",
    ritual:
      "Run the bath 20 minutes before the wind-down you already do. Lather slowly — this is the part where the day ends. Rinse, towel, lights low.",
    weightGrams: 100,
    stock: 96,
    featured: true,
    position: 3,
    images: [
      { url: img(6815654), alt: "Sleepy Moon bar beside amber jars and lavender sprigs" },
      { url: img(6187610), alt: "Bath essentials with lavender in a ceramic vase" },
      { url: img(10853724), alt: "Stacked lavender soap bars with dried petals" },
    ],
    variants: singleAndPack(1500, 3825),
    reviews: [
      {
        authorName: "Grace Ellery",
        authorLocation: "Seattle, WA",
        rating: 5,
        title: "Genuinely shifted our bedtime",
        body: "I'm usually sceptical of anything sold as calming. But we introduced this three weeks ago and the 40-minute fight is now about 12 minutes. The lavender is soft, not soapy-sharp.",
        daysAgo: 3,
        helpfulCount: 61,
      },
      {
        authorName: "Nadia Haddad",
        authorLocation: "Boston, MA",
        rating: 5,
        title: "The petals on top are adorable",
        body: "Calendula petals pressed into the bar look beautiful and don't scratch. Bought two as shower gifts and both friends ordered more themselves.",
        daysAgo: 15,
        helpfulCount: 18,
      },
      {
        authorName: "Rebecca Sone",
        authorLocation: "Columbus, OH",
        rating: 4,
        title: "Love it, but hide it from toddlers",
        body: "My son thinks it's a snack because it smells faintly sweet. Not a criticism of the soap. Works beautifully, lathers well.",
        daysAgo: 27,
        helpfulCount: 11,
      },
      {
        authorName: "Elliot Marsh",
        authorLocation: "Nashville, TN",
        rating: 5,
        title: "Two households, same result",
        body: "We use it on our eight-month-old and I've stolen it for my own shower. Skin feels calm after, no tight feeling.",
        daysAgo: 44,
        helpfulCount: 7,
      },
    ],
  },
  {
    slug: "chamomile-hush-bar",
    name: "Chamomile Hush Bar",
    subtitle: "Roman chamomile & colloidal oat · 3m+",
    collection: "calm-comfort",
    priceCents: 1400,
    scent: "Chamomile, faintly sweet",
    ageRange: "3 months +",
    concerns: ["Sensitive skin", "Redness", "Eczema-prone"],
    summary:
      "For cheeks that go blotchy after a bath. Chamomile and colloidal oatmeal at 4%, the level used in clinical soothing studies.",
    description:
      "Hush is formulated around a single problem: babies whose skin flushes red and stays red for an hour after the bath. Colloidal oatmeal at 4% (most 'oat' soaps carry under 1%) plus a chamomile infusion replacing part of the water phase.\n\nIt is fragrance-oil-free — the faint honey scent is the chamomile itself. Soap-free surfactants are unnecessary here; a properly superfatted cold-process bar at pH 5.5 cleanses without stripping.",
    ingredients:
      "Saponified Olive Oil, Shea Butter, Coconut Oil, Avena Sativa (Colloidal Oatmeal) Kernel Flour 4%, Anthemis Nobilis (Chamomile) Flower Infusion, Jojoba Seed Oil, Castor Oil, Tocopherol.",
    ritual:
      "Press — don't rub — the lather onto flushed areas and leave for 20 seconds before rinsing. Follow with a plain occlusive balm while skin is still damp.",
    weightGrams: 100,
    stock: 132,
    featured: true,
    position: 4,
    images: [
      { url: img(6815656), alt: "Chamomile Hush bar in a skincare flat lay" },
      { url: img(6690868), alt: "Chamomile bar beside a clay pot on a knitted towel" },
      { url: img(6690846), alt: "Overhead view of bath bar, brush and towel" },
    ],
    variants: singleAndPack(1400, 3570),
    reviews: [
      {
        authorName: "Dr. Farah Iqbal",
        authorLocation: "Houston, TX",
        rating: 5,
        title: "I recommend this in clinic",
        body: "As a paediatric GP I see a lot of over-bathed babies with wrecked barriers. This is one of the few bars I'm comfortable suggesting: real oat concentration, no fragrance oils, sensible pH.",
        daysAgo: 9,
        helpfulCount: 73,
      },
      {
        authorName: "Sofia Marques",
        authorLocation: "Newark, NJ",
        rating: 5,
        title: "Redness gone in a week",
        body: "Her cheeks used to blaze after every bath. Nine days on this and they're just... normal. I cried a bit, honestly.",
        daysAgo: 21,
        helpfulCount: 34,
      },
      {
        authorName: "Kaito Nakamura",
        authorLocation: "San Jose, CA",
        rating: 4,
        title: "Effective, slightly grainy",
        body: "The oat texture is visible, which my daughter finds amusing. Not as silky as the milk bar but clearly doing more work on her eczema patches.",
        daysAgo: 35,
        helpfulCount: 8,
      },
    ],
  },
  {
    slug: "oat-calendula-comfort-bar",
    name: "Oat & Calendula Comfort Bar",
    subtitle: "Colloidal oat, calendula petals · 3m+",
    collection: "calm-comfort",
    priceCents: 1600,
    scent: "Unscented, faintly herbal",
    ageRange: "3 months +",
    concerns: ["Eczema-prone", "Itching", "Dry patches"],
    badge: "Derm pick",
    summary:
      "Our richest bar for the itchy, scratchy phase. Calendula petals are pressed in whole and the oat percentage is the highest in the range.",
    description:
      "Calendula officinalis has been used on infant skin for well over a century, mostly because it works on the two things parents actually complain about: itching and rough patches. We infuse the petals into olive oil for six weeks before saponification and press whole petals into the top of every bar.\n\nPaired with 5% colloidal oatmeal, this is the bar we send home with families managing mild-to-moderate eczema alongside their prescribed routine.",
    ingredients:
      "Saponified Olive Oil (Calendula-infused), Shea Butter, Coconut Oil, Avena Sativa (Colloidal Oatmeal) 5%, Calendula Officinalis Flower, Evening Primrose Oil, Castor Oil, Tocopherol.",
    ritual:
      "Use on the body, not the face, two to three times weekly. On flare days, lather in hands and apply with a cotton cloth to avoid friction from the petals.",
    weightGrams: 110,
    stock: 88,
    featured: false,
    position: 5,
    images: [
      { url: img(7500419), alt: "Assorted handmade oat and calendula soap bars" },
      { url: img(7421205), alt: "Colloidal oatmeal in a wooden spoon" },
      { url: img(6815658), alt: "Natural skincare ingredients in glass containers" },
    ],
    variants: singleAndPack(1600, 4080, "Saves 15%"),
    reviews: [
      {
        authorName: "Yara Osman",
        authorLocation: "Minneapolis, MN",
        rating: 5,
        title: "Got us through winter eczema",
        body: "Minnesota winters destroy my son's legs. Used this with the oat balm and we had our first winter without a steroid course. That's the whole review.",
        daysAgo: 13,
        helpfulCount: 52,
      },
      {
        authorName: "Peter Nolan",
        authorLocation: "Philadelphia, PA",
        rating: 4,
        title: "Works well, bar is big",
        body: "110 g feels generous. Slightly herbal smell that fades immediately after rinsing. Scratching at night is down noticeably.",
        daysAgo: 26,
        helpfulCount: 12,
      },
      {
        authorName: "Imogen Clarke",
        authorLocation: "Vancouver, BC",
        rating: 5,
        title: "The petals aren't a gimmick",
        body: "I expected decoration. The infusion actually leaves skin feeling less tight. Third bar and counting.",
        daysAgo: 41,
        helpfulCount: 19,
      },
    ],
  },
  {
    slug: "honeycomb-glow-bar",
    name: "Honeycomb Glow Bar",
    subtitle: "Raw honey & beeswax · 6m+",
    collection: "everyday-bath",
    priceCents: 1500,
    scent: "Raw honey, warm amber",
    ageRange: "6 months +",
    concerns: ["Dry skin", "Daily bath", "Toddler"],
    summary:
      "Raw honey from a single apiary in Vermont, plus beeswax for a bar that holds its shape and leaves skin satin-soft.",
    description:
      "Honey is a natural humectant — it pulls moisture into skin instead of stripping it out, which is why it turns up in every serious dry-skin formulation. We use unpasteurised honey added at trace so the enzymes survive, and 3% beeswax for structure.\n\nBeeswax is also what makes this the best traveller in the range: it will sit in a soap tin for a fortnight and still be a bar.",
    ingredients:
      "Saponified Olive Oil, Coconut Oil, Shea Butter, Raw Honey, Cera Alba (Beeswax) 3%, Sweet Almond Oil, Castor Oil, Tocopherol, Vanilla Fruit Extract.",
    ritual:
      "Best on damp skin at the end of the bath. Work into a low, sticky-feeling lather, leave 15 seconds, rinse. Follow with nothing — most kids don't need it after this one.",
    weightGrams: 100,
    stock: 74,
    featured: false,
    position: 6,
    images: [
      { url: img(14798459), alt: "Honey soap bar on a wooden tray with flowers" },
      { url: img(6690863), alt: "Assorted bars including Honeycomb Glow on marble" },
      { url: img(6366358), alt: "Close-up of kAvI soap packaging and bar texture" },
    ],
    variants: singleAndPack(1500, 3825),
    reviews: [
      {
        authorName: "Meredith Lowe",
        authorLocation: "Raleigh, NC",
        rating: 5,
        title: "My kid's favourite",
        body: "Slightly sweet, not perfumey. It survives being left in a puddle at the bottom of the tub better than anything else we've bought.",
        daysAgo: 8,
        helpfulCount: 17,
      },
      {
        authorName: "Jonah Feldman",
        authorLocation: "Atlanta, GA",
        rating: 5,
        title: "Took it camping",
        body: "Two weeks in a tin with river water and it still lathered. Also used it to wash my daughter's hair, which went fine.",
        daysAgo: 24,
        helpfulCount: 10,
      },
      {
        authorName: "Clara Voss",
        authorLocation: "Madison, WI",
        rating: 3,
        title: "Good but very sweet for me",
        body: "Beautiful bar and my skin liked it. The honey scent is stronger than I expected — I prefer the fragrance-free one for everyday.",
        daysAgo: 33,
        verified: true,
        helpfulCount: 6,
      },
    ],
  },
  {
    slug: "shea-silk-body-bar",
    name: "Shea Silk Body Bar",
    subtitle: "Unrefined shea & cocoa butter · 3m+",
    collection: "everyday-bath",
    priceCents: 1300,
    scent: "Cocoa butter, barely there",
    ageRange: "3 months +",
    concerns: ["Dry skin", "Daily bath", "Value"],
    badge: "Value pick",
    summary:
      "30% unrefined shea, 8% cocoa butter, and a price that assumes you'll use it every single day.",
    description:
      "Shea Silk is the workhorse. Unrefined Grade A shea from a women's cooperative in northern Ghana, cocoa butter for the scent and the slip, and a 7% superfat so it rinses soft rather than squeaky.\n\nIt's the bar we sell the most of by volume, largely because it's the one families put in both bathrooms and the holiday bag.",
    ingredients:
      "Saponified Olive Oil, Butyrospermum Parkii (Shea) Butter 30%, Coconut Oil, Theobroma Cacao (Cocoa) Seed Butter 8%, Castor Oil, Tocopherol.",
    ritual:
      "Daily use, head to toe. Rinse the bar after each bath and let it drain — a curing bar lasts about six weeks.",
    weightGrams: 100,
    stock: 260,
    featured: false,
    position: 7,
    images: [
      { url: img(7691117), alt: "Shea Silk body bar with white towels" },
      { url: img(7960114), alt: "Shea bars arranged on a ceramic tray" },
      { url: img(6690839), alt: "Natural shea body bars on a light background" },
    ],
    variants: singleAndPack(1300, 3315),
    reviews: [
      {
        authorName: "Tasha Boyle",
        authorLocation: "Phoenix, AZ",
        rating: 5,
        title: "Buy the three-pack",
        body: "At this price the single is a false economy. We go through one bar every five weeks with two kids. Desert-dry skin handled fine.",
        daysAgo: 5,
        helpfulCount: 25,
      },
      {
        authorName: "Oliver Grant",
        authorLocation: "Dublin, IE",
        rating: 4,
        title: "Solid everyday soap",
        body: "Nothing fancy and that's the appeal. Lathers well in soft water, leaves no residue on the tub.",
        daysAgo: 29,
        helpfulCount: 4,
      },
      {
        authorName: "Renée Dubois",
        authorLocation: "Montréal, QC",
        rating: 5,
        title: "Whole family uses it",
        body: "I stopped buying separate adult bars. The cocoa butter smell is very light and my husband doesn't complain.",
        daysAgo: 47,
        helpfulCount: 13,
      },
    ],
  },
  {
    slug: "little-botanicals-rose-bar",
    name: "Little Botanicals Rose Bar",
    subtitle: "Rosewater, aloe & pink clay · 12m+",
    collection: "calm-comfort",
    priceCents: 1700,
    scent: "Rosewater, green",
    ageRange: "12 months +",
    concerns: ["Sensitive skin", "Redness", "Gift"],
    badge: "Limited batch",
    summary:
      "A small-batch bar with rosewater hydrosol, aloe juice and pink clay — the prettiest thing in the range and still gentle enough for cheeks.",
    description:
      "We make Little Botanicals four times a year in batches of 400. Rosewater hydrosol replaces the water phase entirely, aloe juice is added at trace, and pink clay gives the blush colour without a single dye.\n\nIt is the bar most often bought as a gift, which is why it ships in a letterpress wrap with a hand-numbered batch card.",
    ingredients:
      "Saponified Olive Oil, Shea Butter, Coconut Oil, Rosa Damascena (Rose) Flower Water, Aloe Barbadensis Leaf Juice, Illite (Pink Clay), Rose Petals, Castor Oil, Tocopherol.",
    ritual:
      "Use on face and body once daily. The clay is mildly absorbent, so follow with a light moisturiser on very dry skin.",
    weightGrams: 90,
    stock: 42,
    featured: true,
    position: 8,
    images: [
      { url: img(10853724), alt: "Rose petal soap bars on a wooden stand" },
      { url: img(7500295), alt: "Handmade bars with dried flowers held in a hand" },
      { url: img(7500305), alt: "Little Botanicals rose bar on linen fabric" },
    ],
    variants: singleAndPack(1700, 4335, "Saves 15%"),
    reviews: [
      {
        authorName: "Isabelle Fontaine",
        authorLocation: "New Orleans, LA",
        rating: 5,
        title: "Bought as gifts, kept one",
        body: "The wrap and the batch card make it feel expensive. Rose scent is fresh and green, nothing like the soapy rose candles I dreaded.",
        daysAgo: 10,
        helpfulCount: 21,
      },
      {
        authorName: "Maya Stein",
        authorLocation: "Oakland, CA",
        rating: 5,
        title: "My toddler's cheeks are calm",
        body: "Drool rash season. This plus a barrier balm has been the combination that finally worked.",
        daysAgo: 20,
        helpfulCount: 16,
      },
      {
        authorName: "Harriet Bloom",
        authorLocation: "London, UK",
        rating: 4,
        title: "Wish it were in stock always",
        body: "Limited batches mean I panic-buy. Beautiful bar, lathers less than the shea one but rinses gorgeous.",
        daysAgo: 37,
        helpfulCount: 7,
      },
    ],
  },
  {
    slug: "aloe-whisper-bar",
    name: "Aloe Whisper Bar",
    subtitle: "Aloe vera & cucumber seed · 3m+",
    collection: "calm-comfort",
    priceCents: 1300,
    scent: "Fresh, barely there",
    ageRange: "3 months +",
    concerns: ["Heat rash", "Sensitive skin", "Summer"],
    summary:
      "The cooling bar. Aloe at 12% and cucumber seed oil for prickly heat, summer rashes and post-sun skin.",
    description:
      "Whisper is what we recommend from May to September. Aloe barbadensis juice at 12% (freeze-dried and reconstituted so the bar cures properly), cucumber seed oil for linoleic acid, and no occlusive butters that trap heat in skin.\n\nIt's lighter than everything else in the range by design — a summer bar should not feel like a coat.",
    ingredients:
      "Saponified Olive Oil, Coconut Oil, Aloe Barbadensis Leaf Juice 12%, Cucumis Sativus (Cucumber) Seed Oil, Shea Butter, Kaolin Clay, Tocopherol.",
    ritual:
      "Use after sun exposure or on hot nights. Rinse with cool rather than warm water for the full cooling effect.",
    weightGrams: 100,
    stock: 155,
    featured: false,
    position: 9,
    images: [
      { url: img(8015827), alt: "Aloe Whisper bar with a soft sponge on white" },
      { url: img(8015792), alt: "Minimal white skincare still life" },
      { url: img(6690916), alt: "Aloe bar with cream and lotion on a white surface" },
    ],
    variants: singleAndPack(1300, 3315),
    reviews: [
      {
        authorName: "Simone Adler",
        authorLocation: "San Diego, CA",
        rating: 5,
        title: "Fixed the prickly heat",
        body: "Three summers of heat rash on her neck and this cleared it in four days. Now a permanent part of the beach bag.",
        daysAgo: 16,
        helpfulCount: 29,
      },
      {
        authorName: "Rahul Mehta",
        authorLocation: "Edison, NJ",
        rating: 4,
        title: "Very fresh",
        body: "Light lather, cooling feel. I keep the shea bar for winter and this one for summer, which seems to be the intended split.",
        daysAgo: 30,
        helpfulCount: 6,
      },
    ],
  },
  {
    slug: "whole-ritual-gift-set",
    name: "The Whole Ritual Gift Set",
    subtitle: "Four bars, linen wrap, seed-paper card",
    collection: "gift-sets",
    priceCents: 4800,
    compareAtCents: 6200,
    scent: "Mixed range",
    ageRange: "Newborn 0m+",
    concerns: ["Gift", "New parent", "Value"],
    badge: "Gift set",
    summary:
      "First Light, Chamomile Hush, Sleepy Moon and Shea Silk in a linen-wrapped box with a plantable card and a hand-written note.",
    description:
      "The set we ship most to new parents: two fragrance-free bars for the early weeks, one bedtime bar for when the evenings get long, and the everyday shea bar for the whole family.\n\nPacked in an unbleached board box wrapped in natural linen, tied with cotton twine. The card is embedded with chamomile and wildflower seed — plant it rather than binning it. Add a gift note at checkout and we write it by hand.",
    ingredients:
      "Contains: First Light Newborn Bar 100 g, Chamomile Hush Bar 100 g, Sleepy Moon Lavender Bar 100 g, Shea Silk Body Bar 100 g. See each bar for full ingredient lists.",
    ritual:
      "Start with First Light for the first months, introduce Sleepy Moon around six months for the evening bath, and keep Hush in reserve for red or reactive days.",
    weightGrams: 400,
    stock: 60,
    featured: true,
    position: 10,
    images: [
      { url: img(7500299), alt: "The Whole Ritual gift set bars held in linen" },
      { url: img(7500233), alt: "Gift set of four handmade soap bars" },
      { url: img(6690839), alt: "Four kAvI bars arranged on a pale surface" },
    ],
    variants: [
      { id: "set", label: "Gift set · 4 bars", detail: "400 g total", priceCents: 4800, compareAtCents: 6200, stock: 60 },
      {
        id: "set-plus-balm",
        label: "Gift set + oat balm",
        detail: "4 bars & 50 ml balm",
        priceCents: 5900,
        compareAtCents: 7600,
        stock: 24,
      },
    ],
    reviews: [
      {
        authorName: "Beatrice Okonjo",
        authorLocation: "Washington, DC",
        rating: 5,
        title: "Sent to six baby showers",
        body: "It arrives looking like something from a boutique, not a warehouse. Every recipient has messaged me about the seed-paper card.",
        daysAgo: 7,
        helpfulCount: 44,
      },
      {
        authorName: "Sam Whitaker",
        authorLocation: "Leeds, UK",
        rating: 5,
        title: "Best value in the shop",
        body: "You save about $14 versus buying the bars separately and the linen wrap is genuinely reusable. I've kept it as a keepsake box.",
        daysAgo: 18,
        helpfulCount: 15,
      },
      {
        authorName: "Lena Hoffmann",
        authorLocation: "Berlin, DE",
        rating: 4,
        title: "Lovely, shipping took a while",
        body: "The set itself is faultless. International delivery to Germany took nine days — worth planning ahead if it's for a specific date.",
        daysAgo: 40,
        verified: true,
        helpfulCount: 5,
      },
    ],
  },
  {
    slug: "bedtime-duo-set",
    name: "Bedtime Duo Set",
    subtitle: "Sleepy Moon + Chamomile Hush",
    collection: "gift-sets",
    priceCents: 2600,
    compareAtCents: 2900,
    scent: "Lavender & chamomile",
    ageRange: "6 months +",
    concerns: ["Bedtime", "Gift", "Sensitive skin"],
    summary:
      "The two bars that do the evening shift, wrapped together: lavender for the wind-down, chamomile for the skin that objects to it.",
    description:
      "A focused pair for families already through the newborn stage. Sleepy Moon handles the mood, Chamomile Hush handles the cheeks. Both bars are 100 g and ship in a slim recycled board sleeve.\n\nThis is the set our sleep-consultant partners recommend most, because it removes the decision from a tired parent at 7pm.",
    ingredients:
      "Contains: Sleepy Moon Lavender Bar 100 g, Chamomile Hush Bar 100 g. See each bar for full ingredient lists.",
    ritual:
      "Alternate by need: Sleepy Moon on ordinary nights, Chamomile Hush on nights when skin is flushed or the child has been unwell.",
    weightGrams: 200,
    stock: 95,
    featured: false,
    position: 11,
    images: [
      { url: img(7500295), alt: "Bedtime Duo bars wrapped with dried flowers" },
      { url: img(6187610), alt: "Lavender and bath essentials for the bedtime routine" },
      { url: img(6849447, 1000, 1000), alt: "Parent holding a baby wrapped in a towel after the evening bath" },
    ],
    variants: [
      { id: "duo", label: "Duo · 2 bars", detail: "200 g total", priceCents: 2600, compareAtCents: 2900, stock: 95 },
      { id: "duo-x2", label: "Two duos", detail: "4 bars", priceCents: 4800, compareAtCents: 5800, stock: 30 },
    ],
    reviews: [
      {
        authorName: "Aoife Byrne",
        authorLocation: "Dublin, IE",
        rating: 5,
        title: "Perfect for the grandparents to buy",
        body: "Cheap enough that relatives don't overthink it, nice enough that it doesn't feel like a token. Both bars are in rotation nightly.",
        daysAgo: 12,
        helpfulCount: 19,
      },
      {
        authorName: "Marcus Teale",
        authorLocation: "Manchester, UK",
        rating: 5,
        title: "Solved the 7pm panic",
        body: "One bar for calm skin, one for calm kid. Having both means I never stand there deciding. Lathers quickly which matters when you're holding a slippery baby.",
        daysAgo: 25,
        helpfulCount: 11,
      },
    ],
  },
  {
    slug: "travel-trio-minis",
    name: "Travel Trio Minis",
    subtitle: "Three 35 g bars in a cotton pouch",
    collection: "gift-sets",
    priceCents: 2400,
    scent: "Mixed range",
    ageRange: "Newborn 0m+",
    concerns: ["Travel", "Gift", "New parent"],
    badge: "Cabin-friendly",
    summary:
      "Three mini bars — First Light, Cloud Milk and Shea Silk — in a cotton drawstring pouch that gets through security without a liquids bag.",
    description:
      "The reason to travel with a bar is that it isn't a liquid. No 100 ml limit, no leaked bottle in a nappy bag, and no hotel body wash that leaves a toddler's skin squeaking.\n\nEach mini is 35 g, enough for roughly three weeks of use. The pouch is undyed organic cotton and doubles as a wet bag for the used bar.",
    ingredients:
      "Contains: First Light Newborn Bar 35 g, Cloud Milk Bath Bar 35 g, Shea Silk Body Bar 35 g. See each bar for full ingredient lists.",
    ritual:
      "Rinse the mini after use and let it dry in the open pouch before zipping it away. Refill with full-size bars at home.",
    weightGrams: 105,
    stock: 140,
    featured: false,
    position: 12,
    images: [
      { url: img(7500302), alt: "Travel trio mini bars held in hands" },
      { url: img(7500310), alt: "Mini soap bars in a cotton pouch" },
      { url: img(7500308), alt: "Travel-size handmade soap bar" },
    ],
    variants: [
      { id: "trio", label: "Trio · 3 minis", detail: "105 g total", priceCents: 2400, stock: 140 },
      { id: "trio-x2", label: "Two trios", detail: "6 minis", priceCents: 4300, compareAtCents: 4800, stock: 55 },
    ],
    reviews: [
      {
        authorName: "Camille Roche",
        authorLocation: "Lyon, FR",
        rating: 5,
        title: "Two flights, zero spills",
        body: "Went in the carry-on with no problem. The cotton pouch dried the bars out overnight which I didn't expect from a travel product.",
        daysAgo: 14,
        helpfulCount: 23,
      },
      {
        authorName: "Nathan Pryce",
        authorLocation: "Cardiff, UK",
        rating: 4,
        title: "Great, minis are small",
        body: "35 g is genuinely mini — about three weeks for one child. Fine for holidays, don't plan on it as your everyday supply.",
        daysAgo: 32,
        helpfulCount: 8,
      },
    ],
  },
];

const FOUNDER_ORDER = {
  orderNumber: "KAV-100248",
  email: "hello@example.com",
  customerName: "Amara Whitfield",
  phone: "+1 (415) 555-0139",
  shippingAddress: {
    address1: "1180 Fillmore Street",
    address2: "Apt 4B",
    city: "San Francisco",
    state: "CA",
    postalCode: "94115",
    country: "United States",
  },
  shippingMethod: "standard",
  promoCode: "WELCOME10",
  paymentBrand: "Visa",
  paymentLast4: "4242",
  status: "shipped",
  giftNote: "For Margot — welcome to the world. Love, Amara & Jo",
};

export async function seedDatabase({ force = false }: { force?: boolean } = {}) {
  const existing = await db.select({ count: sql<number>`count(*)::int` }).from(products);
  const productCount = existing[0]?.count ?? 0;
  if (productCount > 0 && !force) {
    return { seeded: false, productCount };
  }

  await db.delete(orderItems);
  await db.delete(orders);
  await db.delete(reviews);
  await db.delete(productImages);
  await db.delete(products);
  await db.delete(collections);

  const insertedCollections = await db.insert(collections).values(COLLECTIONS).returning();
  const collectionIdBySlug = new Map(insertedCollections.map((c) => [c.slug, c.id]));

  const reviewRows: (typeof reviews.$inferInsert)[] = [];

  for (const product of PRODUCTS) {
    const collectionId = collectionIdBySlug.get(product.collection);
    if (!collectionId) throw new Error(`Unknown collection slug: ${product.collection}`);

    const ratingSum = product.reviews.reduce((acc, r) => acc + r.rating, 0);
    const reviewCount = product.reviews.length;
    const average = reviewCount > 0 ? ratingSum / reviewCount : 0;

    const [inserted] = await db
      .insert(products)
      .values({
        slug: product.slug,
        name: product.name,
        subtitle: product.subtitle,
        collectionId,
        priceCents: product.priceCents,
        compareAtCents: product.compareAtCents ?? null,
        scent: product.scent,
        ageRange: product.ageRange,
        concerns: product.concerns,
        badge: product.badge ?? null,
        summary: product.summary,
        description: product.description,
        ingredients: product.ingredients,
        ritual: product.ritual,
        weightGrams: product.weightGrams,
        stock: product.stock,
        rating: average.toFixed(2),
        reviewCount,
        featured: product.featured,
        position: product.position,
        variants: product.variants,
        createdAt: daysAgo(120 - product.position * 3),
      })
      .returning();

    await db.insert(productImages).values(
      product.images.map((image, index) => ({
        productId: inserted.id,
        url: image.url,
        alt: image.alt,
        position: index,
      })),
    );

    for (const review of product.reviews) {
      reviewRows.push({
        productId: inserted.id,
        authorName: review.authorName,
        authorLocation: review.authorLocation,
        rating: review.rating,
        title: review.title,
        body: review.body,
        verified: review.verified ?? true,
        helpfulCount: review.helpfulCount ?? 0,
        createdAt: daysAgo(review.daysAgo),
      });
    }
  }

  if (reviewRows.length > 0) {
    await db.insert(reviews).values(reviewRows);
  }

  // A demo order so the confirmation & order-lookup surfaces have real data.
  const demoItems: { slug: string; quantity: number }[] = [
    { slug: "whole-ritual-gift-set", quantity: 1 },
    { slug: "first-light-newborn-bar", quantity: 2 },
    { slug: "sleepy-moon-lavender-bar", quantity: 1 },
  ];
  const orderedProducts = await db.select().from(products);
  const bySlug = new Map(orderedProducts.map((p) => [p.slug, p]));

  const chosen = demoItems
    .map((item) => ({ item, product: bySlug.get(item.slug) }))
    .filter((entry): entry is { item: { slug: string; quantity: number }; product: (typeof orderedProducts)[number] } =>
      Boolean(entry.product),
    );

  const subtotalCents = chosen.reduce((sum, { item, product }) => sum + product.priceCents * item.quantity, 0);
  const discountCents = Math.round(subtotalCents * 0.1);
  const shippingCents = 0;
  const taxCents = Math.round((subtotalCents - discountCents) * 0.0825);
  const totalCents = subtotalCents - discountCents + shippingCents + taxCents;

  const [order] = await db
    .insert(orders)
    .values({
      orderNumber: FOUNDER_ORDER.orderNumber,
      email: FOUNDER_ORDER.email,
      customerName: FOUNDER_ORDER.customerName,
      phone: FOUNDER_ORDER.phone,
      shippingAddress: FOUNDER_ORDER.shippingAddress,
      shippingMethod: FOUNDER_ORDER.shippingMethod,
      promoCode: FOUNDER_ORDER.promoCode,
      subtotalCents,
      discountCents,
      shippingCents,
      taxCents,
      totalCents,
      paymentBrand: FOUNDER_ORDER.paymentBrand,
      paymentLast4: FOUNDER_ORDER.paymentLast4,
      giftNote: FOUNDER_ORDER.giftNote,
      status: FOUNDER_ORDER.status,
      placedAt: daysAgo(2),
    })
    .returning();

  const imageRowsByProduct = await db.select().from(productImages);
  const firstImageByProduct = new Map<number, string>();
  for (const row of imageRowsByProduct) {
    if (!firstImageByProduct.has(row.productId)) firstImageByProduct.set(row.productId, row.url);
  }

  await db.insert(orderItems).values(
    chosen.map(({ item, product }) => ({
      orderId: order.id,
      productId: product.id,
      slug: product.slug,
      name: product.name,
      variantLabel: product.variants[0]?.label ?? "Single bar",
      imageUrl: firstImageByProduct.get(product.id) ?? null,
      unitPriceCents: product.priceCents,
      quantity: item.quantity,
    })),
  );

  return { seeded: true, productCount: PRODUCTS.length };
}
